 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 31002 -u -b 2725.124k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 31003 -u -b 13301.161k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 31005 -u -b 5916.991k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 31006 -u -b 12801.666k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 31007 -u -b 822.078k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 31009 -u -b 6907.070k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 31010 -u -b 1986.060k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 31011 -u -b 6905.364k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 31012 -u -b 5160.416k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 31013 -u -b 8359.675k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 31016 -u -b 1715.216k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 31017 -u -b 2104.453k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 31018 -u -b 9953.897k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 31019 -u -b 7745.835k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 31020 -u -b 5893.171k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 31021 -u -b 13295.043k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 31022 -u -b 10408.446k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 31023 -u -b 11549.397k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 31024 -u -b 4805.755k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 31027 -u -b 10669.571k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 31028 -u -b 11442.642k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 31029 -u -b 9701.981k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 31030 -u -b 4697.652k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 31034 -u -b 7973.123k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 31035 -u -b 440.318k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 31036 -u -b 6474.987k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 31037 -u -b 4912.936k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 31039 -u -b 9880.086k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 31040 -u -b 5633.195k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 31041 -u -b 597.949k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 31042 -u -b 8034.537k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 31043 -u -b 7866.103k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 31044 -u -b 9910.776k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 31045 -u -b 6147.741k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 31047 -u -b 5549.499k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 31048 -u -b 7806.149k -w 256k -t 30 &
sleep 0.4