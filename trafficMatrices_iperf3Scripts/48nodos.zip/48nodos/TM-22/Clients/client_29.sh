 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 29002 -u -b 2294.361k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 29003 -u -b 11198.634k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 29004 -u -b 793.537k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 29005 -u -b 4981.686k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 29007 -u -b 692.132k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 29008 -u -b 10678.893k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 29009 -u -b 5815.263k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 29010 -u -b 1672.122k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 29011 -u -b 5813.827k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 29012 -u -b 4344.704k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 29013 -u -b 7038.253k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 29015 -u -b 7128.832k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 29017 -u -b 1771.800k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 29018 -u -b 8380.475k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 29020 -u -b 4961.632k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 29021 -u -b 11193.482k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 29022 -u -b 8763.173k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 29023 -u -b 9723.773k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 29025 -u -b 2725.026k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 29026 -u -b 1049.947k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 29028 -u -b 9633.893k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 29030 -u -b 3955.090k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 29032 -u -b 6378.598k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 29034 -u -b 6712.803k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 29035 -u -b 370.717k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 29036 -u -b 5451.479k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 29037 -u -b 4136.344k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 29038 -u -b 9756.453k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 29040 -u -b 4742.751k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 29041 -u -b 503.431k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 29043 -u -b 6622.701k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 29044 -u -b 8344.170k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 29045 -u -b 5175.962k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 29046 -u -b 8196.497k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 29047 -u -b 4672.284k -w 256k -t 30 &
sleep 0.4