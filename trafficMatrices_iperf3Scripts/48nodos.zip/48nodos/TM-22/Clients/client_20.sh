 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 20001 -u -b 3806.772k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 20003 -u -b 6802.267k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 20004 -u -b 482.010k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 20005 -u -b 3025.972k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 20007 -u -b 420.414k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 20010 -u -b 1015.679k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 20012 -u -b 2639.057k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 20013 -u -b 4275.171k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 20014 -u -b 4958.532k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 20015 -u -b 4330.190k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 20016 -u -b 877.168k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 20018 -u -b 5090.462k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 20021 -u -b 6799.137k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 20023 -u -b 5906.407k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 20024 -u -b 2457.682k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 20025 -u -b 1655.234k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 20027 -u -b 5456.461k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 20028 -u -b 5851.813k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 20029 -u -b 4961.632k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 20030 -u -b 2402.398k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 20032 -u -b 3874.484k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 20035 -u -b 225.181k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 20037 -u -b 2512.495k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 20039 -u -b 5052.715k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 20040 -u -b 2880.838k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 20041 -u -b 305.794k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 20043 -u -b 4022.756k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 20044 -u -b 5068.410k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 20045 -u -b 3143.979k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 20047 -u -b 2838.036k -w 256k -t 30 &
sleep 0.4