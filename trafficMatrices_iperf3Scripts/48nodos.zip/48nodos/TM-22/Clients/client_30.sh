 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 30001 -u -b 3034.511k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 30002 -u -b 1110.918k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 30003 -u -b 5422.324k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 30005 -u -b 2412.108k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 30007 -u -b 335.127k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 30008 -u -b 5170.668k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 30011 -u -b 2815.027k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 30012 -u -b 2103.685k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 30014 -u -b 3952.619k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 30016 -u -b 699.222k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 30017 -u -b 857.897k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 30022 -u -b 4243.086k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 30023 -u -b 4708.203k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 30024 -u -b 1959.104k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 30025 -u -b 1319.444k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 30026 -u -b 508.379k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 30027 -u -b 4349.536k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 30028 -u -b 4664.684k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 30029 -u -b 3955.090k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 30033 -u -b 4984.281k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 30034 -u -b 3250.307k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 30036 -u -b 2639.580k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 30037 -u -b 2002.797k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 30038 -u -b 4724.027k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 30040 -u -b 2296.417k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 30041 -u -b 243.759k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 30042 -u -b 3275.343k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 30043 -u -b 3206.680k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 30044 -u -b 4040.207k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 30045 -u -b 2506.176k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 30047 -u -b 2262.297k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 30048 -u -b 3182.238k -w 256k -t 30 &
sleep 0.4