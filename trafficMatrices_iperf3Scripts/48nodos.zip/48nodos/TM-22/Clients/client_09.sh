 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 9001 -u -b 4461.714k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 9002 -u -b 1633.410k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 9004 -u -b 564.938k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 9006 -u -b 7673.180k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 9007 -u -b 492.745k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 9008 -u -b 7602.556k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 9010 -u -b 1190.423k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 9011 -u -b 4139.001k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 9012 -u -b 3093.098k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 9013 -u -b 5010.699k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 9014 -u -b 5811.630k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 9015 -u -b 5075.184k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 9018 -u -b 5966.258k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 9020 -u -b 3532.303k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 9021 -u -b 7968.905k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 9022 -u -b 6238.710k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 9023 -u -b 6922.584k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 9024 -u -b 2880.518k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 9026 -u -b 747.482k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 9028 -u -b 6858.596k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 9029 -u -b 5815.263k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 9030 -u -b 2815.722k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 9031 -u -b 6907.070k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 9033 -u -b 7328.508k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 9034 -u -b 4779.004k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 9035 -u -b 263.922k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 9036 -u -b 3881.037k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 9037 -u -b 2944.761k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 9038 -u -b 6945.850k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 9039 -u -b 5922.017k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 9040 -u -b 3376.476k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 9041 -u -b 358.404k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 9043 -u -b 4714.857k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 9045 -u -b 3684.890k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 9047 -u -b 3326.310k -w 256k -t 30 &
sleep 0.4