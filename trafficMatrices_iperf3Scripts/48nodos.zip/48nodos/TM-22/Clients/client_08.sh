 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 8002 -u -b 2999.522k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 8003 -u -b 14640.481k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 8004 -u -b 1037.427k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 8005 -u -b 6512.784k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 8006 -u -b 14090.691k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 8007 -u -b 904.855k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 8010 -u -b 2186.040k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 8011 -u -b 7600.679k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 8013 -u -b 9201.427k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 8014 -u -b 10672.221k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 8015 -u -b 9319.845k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 8016 -u -b 1887.925k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 8017 -u -b 2316.354k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 8018 -u -b 10956.174k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 8019 -u -b 8525.779k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 8020 -u -b 6486.566k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 8021 -u -b 14633.746k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 8022 -u -b 11456.493k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 8023 -u -b 12712.328k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 8024 -u -b 5289.656k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 8028 -u -b 12594.824k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 8029 -u -b 10678.893k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 8033 -u -b 13457.749k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 8034 -u -b 8775.952k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 8035 -u -b 484.655k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 8036 -u -b 7126.966k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 8038 -u -b 12755.053k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 8039 -u -b 10874.931k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 8040 -u -b 6200.412k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 8042 -u -b 8843.550k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 8043 -u -b 8658.157k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 8046 -u -b 10715.651k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 8047 -u -b 6108.289k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 8048 -u -b 8592.165k -w 256k -t 30 &
sleep 0.4