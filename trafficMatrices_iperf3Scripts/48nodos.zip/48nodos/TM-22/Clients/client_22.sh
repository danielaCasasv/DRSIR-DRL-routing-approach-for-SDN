 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 22002 -u -b 2461.428k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 22003 -u -b 12014.080k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 22005 -u -b 5344.435k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 22006 -u -b 11562.918k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 22007 -u -b 742.530k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 22008 -u -b 11456.493k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 22009 -u -b 6238.710k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 22010 -u -b 1793.880k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 22011 -u -b 6237.169k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 22012 -u -b 4661.071k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 22014 -u -b 8757.698k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 22016 -u -b 1549.244k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 22019 -u -b 6996.313k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 22021 -u -b 12008.553k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 22023 -u -b 10431.824k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 22025 -u -b 2923.453k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 22027 -u -b 9637.135k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 22029 -u -b 8763.173k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 22030 -u -b 4243.086k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 22031 -u -b 10408.446k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 22033 -u -b 11043.522k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 22034 -u -b 7201.607k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 22035 -u -b 397.711k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 22038 -u -b 10466.884k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 22040 -u -b 5088.101k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 22042 -u -b 7257.078k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 22043 -u -b 7104.943k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 22047 -u -b 5012.504k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 22048 -u -b 7050.790k -w 256k -t 30 &
sleep 0.4