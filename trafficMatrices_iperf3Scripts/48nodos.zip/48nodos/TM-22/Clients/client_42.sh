 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 42001 -u -b 5190.016k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 42003 -u -b 9273.965k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 42005 -u -b 4125.502k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 42007 -u -b 573.177k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 42008 -u -b 8843.550k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 42009 -u -b 4815.815k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 42010 -u -b 1384.740k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 42012 -u -b 3597.996k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 42013 -u -b 5828.614k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 42014 -u -b 6760.284k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 42017 -u -b 1467.287k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 42018 -u -b 6940.153k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 42019 -u -b 5400.627k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 42021 -u -b 9269.699k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 42022 -u -b 7257.078k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 42023 -u -b 8052.583k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 42024 -u -b 3350.715k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 42028 -u -b 7978.150k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 42029 -u -b 6764.510k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 42031 -u -b 8034.537k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 42032 -u -b 5282.332k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 42035 -u -b 307.003k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 42036 -u -b 4514.553k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 42037 -u -b 3425.445k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 42041 -u -b 416.908k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 42043 -u -b 5484.481k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 42044 -u -b 6910.088k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 42045 -u -b 4286.388k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 42047 -u -b 3869.276k -w 256k -t 30 &
sleep 0.4