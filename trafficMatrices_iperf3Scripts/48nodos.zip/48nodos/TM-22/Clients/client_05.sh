 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 5001 -u -b 3822.159k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 5003 -u -b 6829.761k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 5004 -u -b 483.958k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 5006 -u -b 6573.285k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 5007 -u -b 422.113k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 5008 -u -b 6512.784k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 5009 -u -b 3546.580k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 5012 -u -b 2649.724k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 5013 -u -b 4292.451k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 5016 -u -b 880.714k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 5017 -u -b 1080.575k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 5018 -u -b 5111.038k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 5019 -u -b 3977.262k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 5021 -u -b 6826.619k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 5022 -u -b 5344.435k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 5023 -u -b 5930.281k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 5024 -u -b 2467.616k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 5025 -u -b 1661.924k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 5026 -u -b 640.336k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 5027 -u -b 5478.516k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 5028 -u -b 5875.465k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 5029 -u -b 4981.686k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 5031 -u -b 5916.991k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 5034 -u -b 4093.967k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 5035 -u -b 226.091k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 5036 -u -b 3324.718k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 5037 -u -b 2522.650k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 5039 -u -b 5073.138k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 5040 -u -b 2892.482k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 5041 -u -b 307.030k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 5042 -u -b 4125.502k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 5043 -u -b 4039.016k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 5044 -u -b 5088.896k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 5045 -u -b 3156.687k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 5046 -u -b 4998.834k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 5047 -u -b 2849.507k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 5048 -u -b 4008.231k -w 256k -t 30 &
sleep 0.4