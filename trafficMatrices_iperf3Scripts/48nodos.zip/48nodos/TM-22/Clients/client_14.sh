 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.5 -p 14005 -u -b 4978.574k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 14006 -u -b 10771.361k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 14007 -u -b 691.699k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 14009 -u -b 5811.630k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 14011 -u -b 5810.194k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 14012 -u -b 4341.990k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 14013 -u -b 7033.856k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 14016 -u -b 1443.188k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 14017 -u -b 1770.693k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 14019 -u -b 6517.369k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 14021 -u -b 11186.489k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 14022 -u -b 8757.698k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 14023 -u -b 9717.698k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 14025 -u -b 2723.324k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 14027 -u -b 8977.410k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 14030 -u -b 3952.619k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 14031 -u -b 9695.920k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 14032 -u -b 6374.613k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 14033 -u -b 10287.521k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 14034 -u -b 6708.609k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 14035 -u -b 370.485k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 14037 -u -b 4133.759k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 14038 -u -b 9750.358k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 14039 -u -b 8313.134k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 14040 -u -b 4739.787k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 14041 -u -b 503.116k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 14042 -u -b 6760.284k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 14043 -u -b 6618.563k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 14044 -u -b 8338.957k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 14045 -u -b 5172.728k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 14046 -u -b 8191.376k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 14047 -u -b 4669.365k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 14048 -u -b 6568.117k -w 256k -t 30 &
sleep 0.4