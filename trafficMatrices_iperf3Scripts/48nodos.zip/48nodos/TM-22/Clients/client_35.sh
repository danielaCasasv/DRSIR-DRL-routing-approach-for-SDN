 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 35001 -u -b 284.429k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 35002 -u -b 104.128k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 35003 -u -b 508.243k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 35005 -u -b 226.091k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 35006 -u -b 489.157k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 35010 -u -b 75.888k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 35012 -u -b 197.182k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 35014 -u -b 370.485k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 35015 -u -b 323.538k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 35016 -u -b 65.539k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 35017 -u -b 80.412k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 35018 -u -b 380.343k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 35019 -u -b 295.972k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 35021 -u -b 508.009k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 35022 -u -b 397.711k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 35023 -u -b 441.307k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 35025 -u -b 123.674k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 35026 -u -b 47.651k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 35027 -u -b 407.689k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 35029 -u -b 370.717k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 35030 -u -b 179.499k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 35031 -u -b 440.318k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 35032 -u -b 289.489k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 35034 -u -b 304.656k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 35037 -u -b 187.725k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 35038 -u -b 442.790k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 35039 -u -b 377.522k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 35041 -u -b 22.848k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 35043 -u -b 300.567k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 35044 -u -b 378.695k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 35046 -u -b 371.993k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 35047 -u -b 212.049k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 35048 -u -b 298.276k -w 256k -t 30 &
sleep 0.4