 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 13001 -u -b 5400.043k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 13003 -u -b 9649.260k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 13005 -u -b 4292.451k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 13006 -u -b 9286.904k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 13008 -u -b 9201.427k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 13009 -u -b 5010.699k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 13010 -u -b 1440.777k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 13011 -u -b 5009.462k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 13012 -u -b 3743.598k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 13015 -u -b 6142.531k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 13016 -u -b 1244.295k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 13017 -u -b 1526.664k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 13018 -u -b 7221.004k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 13019 -u -b 5619.177k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 13021 -u -b 9644.821k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 13023 -u -b 8378.452k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 13024 -u -b 3486.311k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 13025 -u -b 2348.008k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 13026 -u -b 904.683k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 13027 -u -b 7740.187k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 13029 -u -b 7038.253k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 13030 -u -b 3407.888k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 13031 -u -b 8359.675k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 13032 -u -b 5496.095k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 13033 -u -b 8869.745k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 13034 -u -b 5784.061k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 13035 -u -b 319.427k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 13037 -u -b 3564.065k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 13040 -u -b 4086.573k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 13041 -u -b 433.779k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 13043 -u -b 5706.425k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 13045 -u -b 4459.848k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 13047 -u -b 4025.856k -w 256k -t 30 &
sleep 0.4