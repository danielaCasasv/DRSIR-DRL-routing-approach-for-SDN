 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 28001 -u -b 7391.527k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 28002 -u -b 2705.999k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 28004 -u -b 935.908k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 28005 -u -b 5875.465k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 28007 -u -b 816.309k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 28008 -u -b 12594.824k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 28009 -u -b 6858.596k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 28012 -u -b 5124.201k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 28013 -u -b 8301.007k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 28015 -u -b 8407.837k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 28016 -u -b 1703.179k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 28017 -u -b 2089.683k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 28019 -u -b 7691.475k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 28020 -u -b 5851.813k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 28022 -u -b 10335.399k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 28023 -u -b 11468.343k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 28024 -u -b 4772.028k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 28025 -u -b 3213.931k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 28026 -u -b 1238.321k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 28027 -u -b 10594.692k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 28029 -u -b 9633.893k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 28030 -u -b 4664.684k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 28031 -u -b 11442.642k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 28032 -u -b 7523.001k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 28034 -u -b 7917.167k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 28035 -u -b 437.228k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 28037 -u -b 4878.457k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 28039 -u -b 9810.747k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 28040 -u -b 5593.661k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 28042 -u -b 7978.150k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 28044 -u -b 9841.222k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 28045 -u -b 6104.597k -w 256k -t 30 &
sleep 0.4