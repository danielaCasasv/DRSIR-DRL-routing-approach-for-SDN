 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 44001 -u -b 6401.998k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 44003 -u -b 11439.638k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 44005 -u -b 5088.896k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 44008 -u -b 10908.711k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 44010 -u -b 1708.107k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 44014 -u -b 8338.957k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 44015 -u -b 7282.251k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 44016 -u -b 1475.169k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 44018 -u -b 8560.830k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 44019 -u -b 6661.791k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 44020 -u -b 5068.410k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 44022 -u -b 8951.764k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 44023 -u -b 9933.037k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 44024 -u -b 4133.180k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 44025 -u -b 2783.671k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 44026 -u -b 1072.543k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 44030 -u -b 4040.207k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 44031 -u -b 9910.776k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 44032 -u -b 6515.871k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 44033 -u -b 10515.487k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 44034 -u -b 6857.269k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 44035 -u -b 378.695k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 44036 -u -b 5568.800k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 44037 -u -b 4225.361k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 44039 -u -b 8497.349k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 44040 -u -b 4844.819k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 44042 -u -b 6910.088k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 44043 -u -b 6765.227k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 44045 -u -b 5287.353k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 44046 -u -b 8372.892k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 44047 -u -b 4772.836k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 44048 -u -b 6713.663k -w 256k -t 30 &
sleep 0.4