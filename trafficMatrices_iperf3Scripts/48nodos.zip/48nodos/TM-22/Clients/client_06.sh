 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 6002 -u -b 3027.386k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 6003 -u -b 14776.484k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 6004 -u -b 1047.064k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 6005 -u -b 6573.285k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 6007 -u -b 913.261k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 6009 -u -b 7673.180k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 6010 -u -b 2206.348k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 6012 -u -b 5732.794k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 6014 -u -b 10771.361k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 6015 -u -b 9406.422k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 6016 -u -b 1905.463k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 6017 -u -b 2337.872k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 6019 -u -b 8604.979k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 6020 -u -b 6546.823k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 6022 -u -b 11562.918k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 6023 -u -b 12830.420k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 6028 -u -b 12711.824k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 6031 -u -b 12801.666k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 6032 -u -b 8416.496k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 6036 -u -b 7193.172k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 6037 -u -b 5457.864k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 6041 -u -b 664.272k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 6042 -u -b 8925.702k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 6043 -u -b 8738.587k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 6045 -u -b 6829.630k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 6046 -u -b 10815.194k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 6047 -u -b 6165.032k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 6048 -u -b 8671.982k -w 256k -t 30 &
sleep 0.4