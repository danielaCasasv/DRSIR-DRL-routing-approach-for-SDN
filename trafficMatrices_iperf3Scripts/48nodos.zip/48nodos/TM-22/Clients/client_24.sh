 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 24001 -u -b 3104.341k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 24002 -u -b 1136.483k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 24003 -u -b 5547.103k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 24004 -u -b 393.069k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 24005 -u -b 2467.616k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 24006 -u -b 5338.794k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 24008 -u -b 5289.656k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 24009 -u -b 2880.518k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 24010 -u -b 828.265k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 24011 -u -b 2879.806k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 24012 -u -b 2152.095k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 24018 -u -b 4151.163k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 24021 -u -b 5544.551k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 24022 -u -b 4340.728k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 24023 -u -b 4816.549k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 24025 -u -b 1349.808k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 24026 -u -b 520.078k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 24027 -u -b 4449.627k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 24029 -u -b 4046.105k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 24030 -u -b 1959.104k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 24031 -u -b 4805.755k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 24032 -u -b 3159.559k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 24033 -u -b 5098.980k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 24034 -u -b 3325.103k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 24035 -u -b 183.630k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 24036 -u -b 2700.322k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 24037 -u -b 2048.886k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 24038 -u -b 4832.737k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 24040 -u -b 2349.262k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 24042 -u -b 3350.715k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 24043 -u -b 3280.472k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 24045 -u -b 2563.848k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 24046 -u -b 4060.032k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 24047 -u -b 2314.357k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 24048 -u -b 3255.468k -w 256k -t 30 &
sleep 0.4