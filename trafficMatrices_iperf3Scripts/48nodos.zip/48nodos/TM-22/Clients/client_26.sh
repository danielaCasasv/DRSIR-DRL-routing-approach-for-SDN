 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 26001 -u -b 805.564k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 26002 -u -b 294.913k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 26003 -u -b 1439.450k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 26005 -u -b 640.336k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 26006 -u -b 1385.395k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 26007 -u -b 88.965k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 26008 -u -b 1372.644k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 26010 -u -b 214.931k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 26012 -u -b 558.460k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 26015 -u -b 916.326k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 26016 -u -b 185.621k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 26017 -u -b 227.744k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 26018 -u -b 1077.210k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 26020 -u -b 637.758k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 26024 -u -b 520.078k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 26029 -u -b 1049.947k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 26030 -u -b 508.379k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 26031 -u -b 1247.073k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 26034 -u -b 862.850k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 26035 -u -b 47.651k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 26036 -u -b 700.722k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 26037 -u -b 531.677k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 26038 -u -b 1254.075k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 26045 -u -b 665.308k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 26047 -u -b 600.566k -w 256k -t 30 &
sleep 0.4