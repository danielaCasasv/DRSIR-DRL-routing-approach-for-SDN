 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 19001 -u -b 5003.525k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 19002 -u -b 1831.764k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 19003 -u -b 8940.728k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 19005 -u -b 3977.262k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 19006 -u -b 8604.979k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 19007 -u -b 552.582k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 19008 -u -b 8525.779k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 19010 -u -b 1334.983k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 19012 -u -b 3468.711k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 19013 -u -b 5619.177k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 19014 -u -b 6517.369k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 19015 -u -b 5691.493k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 19016 -u -b 1152.928k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 19017 -u -b 1414.564k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 19018 -u -b 6690.775k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 19020 -u -b 3961.251k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 19022 -u -b 6996.313k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 19023 -u -b 7763.233k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 19025 -u -b 2175.597k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 19026 -u -b 838.253k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 19027 -u -b 7171.835k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 19028 -u -b 7691.475k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 19032 -u -b 5092.524k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 19033 -u -b 8218.451k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 19034 -u -b 5359.346k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 19035 -u -b 295.972k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 19036 -u -b 4352.334k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 19037 -u -b 3302.360k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 19039 -u -b 6641.161k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 19041 -u -b 401.927k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 19042 -u -b 5400.627k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 19043 -u -b 5287.410k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 19044 -u -b 6661.791k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 19045 -u -b 4132.367k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 19046 -u -b 6543.892k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 19047 -u -b 3730.243k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 19048 -u -b 5247.110k -w 256k -t 30 &
sleep 0.4