 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 21001 -u -b 8588.109k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 21004 -u -b 1087.418k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 21005 -u -b 6826.619k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 21007 -u -b 948.458k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 21008 -u -b 14633.746k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 21009 -u -b 7968.905k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 21012 -u -b 5953.735k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 21013 -u -b 9644.821k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 21014 -u -b 11186.489k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 21015 -u -b 9768.945k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 21016 -u -b 1978.899k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 21017 -u -b 2427.973k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 21019 -u -b 8936.615k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 21020 -u -b 6799.137k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 21022 -u -b 12008.553k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 21023 -u -b 13324.904k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 21025 -u -b 3734.221k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 21027 -u -b 12309.822k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 21028 -u -b 13201.738k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 21030 -u -b 5419.830k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 21031 -u -b 13295.043k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 21032 -u -b 8740.868k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 21033 -u -b 14106.245k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 21034 -u -b 9198.843k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 21037 -u -b 5668.210k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 21038 -u -b 13369.688k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 21039 -u -b 11398.967k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 21040 -u -b 6499.195k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 21041 -u -b 689.873k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 21042 -u -b 9269.699k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 21043 -u -b 9075.372k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 21044 -u -b 11434.376k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 21045 -u -b 7092.844k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 21046 -u -b 11232.012k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 21047 -u -b 6402.632k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 21048 -u -b 9006.200k -w 256k -t 30 &
sleep 0.4