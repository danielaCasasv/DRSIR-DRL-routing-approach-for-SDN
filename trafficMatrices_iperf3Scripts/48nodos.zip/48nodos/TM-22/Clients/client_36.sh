 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 36001 -u -b 4182.604k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 36002 -u -b 1531.229k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 36003 -u -b 7473.835k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 36004 -u -b 529.597k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 36005 -u -b 3324.718k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 36006 -u -b 7193.172k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 36007 -u -b 461.920k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 36008 -u -b 7126.966k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 36010 -u -b 1115.954k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 36011 -u -b 3880.079k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 36014 -u -b 5448.073k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 36015 -u -b 4757.698k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 36018 -u -b 5593.029k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 36021 -u -b 7470.397k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 36022 -u -b 5848.437k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 36023 -u -b 6489.530k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 36024 -u -b 2700.322k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 36025 -u -b 1818.650k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 36026 -u -b 700.722k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 36027 -u -b 5995.162k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 36029 -u -b 5451.479k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 36030 -u -b 2639.580k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 36031 -u -b 6474.987k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 36032 -u -b 4257.000k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 36033 -u -b 6870.061k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 36034 -u -b 4480.045k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 36035 -u -b 247.412k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 36038 -u -b 6511.340k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 36039 -u -b 5551.555k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 36040 -u -b 3165.255k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 36041 -u -b 335.984k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 36042 -u -b 4514.553k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 36043 -u -b 4419.912k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 36044 -u -b 5568.800k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 36046 -u -b 5470.244k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 36047 -u -b 3118.227k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 36048 -u -b 4386.223k -w 256k -t 30 &
sleep 0.4