 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 7001 -u -b 531.032k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 7002 -u -b 194.408k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 7003 -u -b 948.894k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 7004 -u -b 67.239k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 7008 -u -b 904.855k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 7009 -u -b 492.745k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 7010 -u -b 141.684k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 7011 -u -b 492.623k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 7012 -u -b 368.140k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 7013 -u -b 596.373k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 7014 -u -b 691.699k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 7015 -u -b 604.048k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 7016 -u -b 122.362k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 7020 -u -b 420.414k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 7022 -u -b 742.530k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 7023 -u -b 823.925k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 7024 -u -b 342.839k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 7025 -u -b 230.900k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 7026 -u -b 88.965k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 7027 -u -b 761.159k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 7028 -u -b 816.309k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 7029 -u -b 692.132k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 7030 -u -b 335.127k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 7034 -u -b 568.796k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 7038 -u -b 826.694k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 7039 -u -b 704.837k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 7040 -u -b 401.868k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 7041 -u -b 42.657k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 7043 -u -b 561.162k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 7044 -u -b 707.027k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 7045 -u -b 438.575k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 7046 -u -b 694.514k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 7047 -u -b 395.897k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 7048 -u -b 556.884k -w 256k -t 30 &
sleep 0.4