 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 46001 -u -b 6288.696k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 46002 -u -b 2302.258k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 46003 -u -b 11237.181k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 46006 -u -b 10815.194k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 46007 -u -b 694.514k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 46008 -u -b 10715.651k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 46009 -u -b 5835.280k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 46010 -u -b 1677.877k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 46012 -u -b 4359.660k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 46014 -u -b 8191.376k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 46015 -u -b 7153.371k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 46017 -u -b 1777.899k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 46018 -u -b 8409.322k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 46019 -u -b 6543.892k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 46020 -u -b 4978.710k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 46022 -u -b 8793.337k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 46024 -u -b 4060.032k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 46027 -u -b 9013.943k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 46029 -u -b 8196.497k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 46030 -u -b 3968.704k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 46031 -u -b 9735.377k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 46033 -u -b 10329.386k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 46035 -u -b 371.993k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 46036 -u -b 5470.244k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 46038 -u -b 9790.037k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 46040 -u -b 4759.076k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 46041 -u -b 505.164k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 46044 -u -b 8372.892k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 46045 -u -b 5193.779k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 46047 -u -b 4688.367k -w 256k -t 30 &
sleep 0.4