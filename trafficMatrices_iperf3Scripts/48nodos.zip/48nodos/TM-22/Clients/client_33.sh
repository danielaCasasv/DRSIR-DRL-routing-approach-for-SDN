 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 33001 -u -b 7897.952k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 33002 -u -b 2891.398k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 33004 -u -b 1000.031k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 33005 -u -b 6278.018k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 33006 -u -b 13582.766k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 33007 -u -b 872.238k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 33008 -u -b 13457.749k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 33009 -u -b 7328.508k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 33010 -u -b 2107.241k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 33011 -u -b 7326.698k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 33012 -u -b 5475.282k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 33013 -u -b 8869.745k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 33014 -u -b 10287.521k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 33015 -u -b 8983.894k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 33016 -u -b 1819.871k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 33022 -u -b 11043.522k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 33023 -u -b 12254.089k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 33025 -u -b 3434.131k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 33027 -u -b 11320.580k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 33028 -u -b 12140.820k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 33029 -u -b 10293.952k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 33030 -u -b 4984.281k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 33034 -u -b 8459.606k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 33036 -u -b 6870.061k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 33037 -u -b 5212.701k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 33039 -u -b 10482.924k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 33041 -u -b 634.433k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 33044 -u -b 10515.487k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 33045 -u -b 6522.849k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 33046 -u -b 10329.386k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 33048 -u -b 8282.444k -w 256k -t 30 &
sleep 0.4