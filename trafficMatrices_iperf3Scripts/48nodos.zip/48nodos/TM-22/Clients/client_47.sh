 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 47001 -u -b 3584.773k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 47002 -u -b 1312.366k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 47004 -u -b 453.900k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 47005 -u -b 2849.507k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 47006 -u -b 6165.032k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 47008 -u -b 6108.289k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 47010 -u -b 956.448k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 47011 -u -b 3325.488k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 47012 -u -b 2485.156k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 47013 -u -b 4025.856k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 47014 -u -b 4669.365k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 47017 -u -b 1013.463k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 47020 -u -b 2838.036k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 47021 -u -b 6402.632k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 47023 -u -b 5561.964k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 47024 -u -b 2314.357k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 47025 -u -b 1558.705k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 47026 -u -b 600.566k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 47027 -u -b 5138.257k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 47028 -u -b 5510.553k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 47029 -u -b 4672.284k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 47030 -u -b 2262.297k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 47031 -u -b 5549.499k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 47032 -u -b 3648.536k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 47033 -u -b 5888.104k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 47037 -u -b 2365.974k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 47038 -u -b 5580.657k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 47039 -u -b 4758.056k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 47040 -u -b 2712.837k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 47041 -u -b 287.961k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 47043 -u -b 3788.162k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 47044 -u -b 4772.836k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 47045 -u -b 2960.632k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 47046 -u -b 4688.367k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 47048 -u -b 3759.288k -w 256k -t 30 &
sleep 0.4