 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 27001 -u -b 6892.152k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 27002 -u -b 2523.180k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 27004 -u -b 872.678k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 27007 -u -b 761.159k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 27008 -u -b 11743.911k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 27010 -u -b 1838.884k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 27011 -u -b 6393.646k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 27012 -u -b 4778.007k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 27013 -u -b 7740.187k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 27014 -u -b 8977.410k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 27015 -u -b 7839.799k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 27016 -u -b 1588.111k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 27019 -u -b 7171.835k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 27022 -u -b 9637.135k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 27023 -u -b 10693.536k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 27025 -u -b 2996.796k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 27026 -u -b 1154.660k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 27028 -u -b 10594.692k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 27029 -u -b 8983.022k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 27032 -u -b 7014.744k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 27033 -u -b 11320.580k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 27034 -u -b 7382.279k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 27035 -u -b 407.689k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 27037 -u -b 4548.866k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 27038 -u -b 10729.476k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 27039 -u -b 9147.928k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 27040 -u -b 5215.751k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 27041 -u -b 553.639k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 27042 -u -b 7439.142k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 27044 -u -b 9176.344k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 27045 -u -b 5692.167k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 27047 -u -b 5138.257k -w 256k -t 30 &
sleep 0.4