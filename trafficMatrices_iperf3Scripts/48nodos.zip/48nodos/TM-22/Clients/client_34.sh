 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 34001 -u -b 5150.345k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 34002 -u -b 1885.514k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 34004 -u -b 652.132k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 34006 -u -b 8857.476k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 34007 -u -b 568.796k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 34009 -u -b 4779.004k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 34010 -u -b 1374.156k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 34011 -u -b 4777.823k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 34014 -u -b 6708.609k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 34015 -u -b 5858.499k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 34018 -u -b 6887.104k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 34019 -u -b 5359.346k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 34021 -u -b 9198.843k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 34023 -u -b 7991.031k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 34024 -u -b 3325.103k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 34025 -u -b 2239.436k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 34027 -u -b 7382.279k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 34028 -u -b 7917.167k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 34029 -u -b 6712.803k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 34030 -u -b 3250.307k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 34032 -u -b 5241.955k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 34033 -u -b 8459.606k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 34036 -u -b 4480.045k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 34037 -u -b 3399.262k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 34040 -u -b 3897.609k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 34041 -u -b 413.721k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 34042 -u -b 5559.098k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 34045 -u -b 4253.624k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 34046 -u -b 6735.910k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 34047 -u -b 3839.700k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 34048 -u -b 5401.076k -w 256k -t 30 &
sleep 0.4