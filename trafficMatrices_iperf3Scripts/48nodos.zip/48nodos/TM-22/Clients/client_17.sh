 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 17001 -u -b 1359.399k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 17002 -u -b 497.669k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 17003 -u -b 2429.091k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 17004 -u -b 172.126k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 17005 -u -b 1080.575k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 17006 -u -b 2337.872k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 17007 -u -b 150.130k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 17010 -u -b 362.699k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 17011 -u -b 1261.075k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 17012 -u -b 942.408k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 17013 -u -b 1526.664k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 17014 -u -b 1770.693k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 17015 -u -b 1546.312k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 17018 -u -b 1817.805k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 17019 -u -b 1414.564k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 17020 -u -b 1076.225k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 17021 -u -b 2427.973k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 17022 -u -b 1900.816k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 17023 -u -b 2109.179k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 17025 -u -b 591.084k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 17026 -u -b 227.744k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 17027 -u -b 1948.503k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 17030 -u -b 857.897k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 17032 -u -b 1383.579k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 17033 -u -b 2232.857k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 17036 -u -b 1182.478k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 17038 -u -b 2116.268k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 17039 -u -b 1804.326k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 17041 -u -b 109.199k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 17042 -u -b 1467.287k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 17044 -u -b 1809.930k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 17045 -u -b 1122.716k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 17046 -u -b 1777.899k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 17047 -u -b 1013.463k -w 256k -t 30 &
sleep 0.4