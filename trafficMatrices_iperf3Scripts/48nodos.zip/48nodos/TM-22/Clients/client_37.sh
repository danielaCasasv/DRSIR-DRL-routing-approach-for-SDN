 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 37001 -u -b 3173.576k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 37002 -u -b 1161.830k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 37003 -u -b 5670.818k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 37004 -u -b 401.835k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 37006 -u -b 5457.864k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 37007 -u -b 350.485k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 37008 -u -b 5407.629k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 37009 -u -b 2944.761k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 37010 -u -b 846.737k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 37011 -u -b 2944.034k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 37012 -u -b 2200.092k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 37013 -u -b 3564.065k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 37015 -u -b 3609.933k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 37017 -u -b 897.213k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 37018 -u -b 4243.745k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 37019 -u -b 3302.360k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 37021 -u -b 5668.210k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 37022 -u -b 4437.538k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 37024 -u -b 2048.886k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 37025 -u -b 1379.912k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 37027 -u -b 4548.866k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 37028 -u -b 4878.457k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 37031 -u -b 4912.936k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 37032 -u -b 3230.026k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 37033 -u -b 5212.701k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 37034 -u -b 3399.262k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 37035 -u -b 187.725k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 37039 -u -b 4212.277k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 37040 -u -b 2401.657k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 37042 -u -b 3425.445k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 37043 -u -b 3353.635k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 37044 -u -b 4225.361k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 37045 -u -b 2621.029k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 37047 -u -b 2365.974k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 37048 -u -b 3328.074k -w 256k -t 30 &
sleep 0.4