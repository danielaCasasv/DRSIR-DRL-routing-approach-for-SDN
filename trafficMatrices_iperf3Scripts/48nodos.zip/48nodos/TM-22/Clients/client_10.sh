 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 10001 -u -b 1282.922k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 10004 -u -b 162.442k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 10005 -u -b 1019.784k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 10007 -u -b 141.684k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 10008 -u -b 2186.040k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 10009 -u -b 1190.423k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 10011 -u -b 1190.129k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 10012 -u -b 889.390k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 10013 -u -b 1440.777k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 10015 -u -b 1459.319k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 10016 -u -b 295.615k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 10018 -u -b 1715.539k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 10019 -u -b 1334.983k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 10020 -u -b 1015.679k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 10021 -u -b 2291.380k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 10023 -u -b 1990.521k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 10024 -u -b 828.265k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 10025 -u -b 557.831k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 10026 -u -b 214.931k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 10027 -u -b 1838.884k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 10028 -u -b 1972.122k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 10029 -u -b 1672.122k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 10030 -u -b 809.633k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 10032 -u -b 1305.742k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 10033 -u -b 2107.241k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 10037 -u -b 846.737k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 10038 -u -b 1997.211k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 10039 -u -b 1702.818k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 10040 -u -b 970.873k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 10041 -u -b 103.056k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 10042 -u -b 1384.740k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 10044 -u -b 1708.107k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 10045 -u -b 1059.554k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 10046 -u -b 1677.877k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 10047 -u -b 956.448k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 10048 -u -b 1345.378k -w 256k -t 30 &
sleep 0.4