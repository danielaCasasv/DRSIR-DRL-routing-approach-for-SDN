 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 43001 -u -b 5081.214k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 43002 -u -b 1860.206k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 43004 -u -b 643.378k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 43005 -u -b 4039.016k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 43007 -u -b 561.162k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 43010 -u -b 1355.711k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 43011 -u -b 4713.693k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 43012 -u -b 3522.569k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 43013 -u -b 5706.425k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 43014 -u -b 6618.563k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 43016 -u -b 1170.829k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 43017 -u -b 1436.527k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 43018 -u -b 6794.662k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 43019 -u -b 5287.410k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 43021 -u -b 9075.372k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 43022 -u -b 7104.943k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 43023 -u -b 7883.771k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 43025 -u -b 2209.377k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 43026 -u -b 851.269k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 43027 -u -b 7283.191k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 43028 -u -b 7810.899k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 43029 -u -b 6622.701k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 43030 -u -b 3206.680k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 43033 -u -b 8346.057k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 43034 -u -b 5442.559k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 43035 -u -b 300.567k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 43036 -u -b 4419.912k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 43037 -u -b 3353.635k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 43039 -u -b 6744.277k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 43040 -u -b 3845.294k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 43042 -u -b 5484.481k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 43044 -u -b 6765.227k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 43046 -u -b 6645.497k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 43047 -u -b 3788.162k -w 256k -t 30 &
sleep 0.4