 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 38002 -u -b 2740.424k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 38003 -u -b 13375.841k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 38004 -u -b 947.814k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 38005 -u -b 5950.212k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 38006 -u -b 12873.541k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 38007 -u -b 826.694k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 38008 -u -b 12755.053k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 38009 -u -b 6945.850k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 38012 -u -b 5189.390k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 38013 -u -b 8406.611k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 38014 -u -b 9750.358k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 38015 -u -b 8514.800k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 38016 -u -b 1724.846k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 38017 -u -b 2116.268k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 38020 -u -b 5926.258k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 38023 -u -b 11614.241k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 38026 -u -b 1254.075k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 38028 -u -b 11506.887k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 38029 -u -b 9756.453k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 38030 -u -b 4724.027k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 38032 -u -b 7618.708k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 38033 -u -b 12295.273k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 38034 -u -b 8017.888k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 38035 -u -b 442.790k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 38036 -u -b 6511.340k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 38037 -u -b 4940.520k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 38041 -u -b 601.306k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 38042 -u -b 8079.647k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 38044 -u -b 9966.420k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 38047 -u -b 5580.657k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 38048 -u -b 7849.976k -w 256k -t 30 &
sleep 0.4