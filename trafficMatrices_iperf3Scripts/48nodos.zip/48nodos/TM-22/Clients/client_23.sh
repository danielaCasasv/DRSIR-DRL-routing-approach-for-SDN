 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 23002 -u -b 2731.245k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 23003 -u -b 13331.037k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 23005 -u -b 5930.281k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 23009 -u -b 6922.584k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 23010 -u -b 1990.521k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 23011 -u -b 6920.874k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 23013 -u -b 8378.452k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 23014 -u -b 9717.698k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 23015 -u -b 8486.278k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 23016 -u -b 1719.069k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 23017 -u -b 2109.179k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 23018 -u -b 9976.254k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 23019 -u -b 7763.233k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 23020 -u -b 5906.407k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 23021 -u -b 13324.904k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 23022 -u -b 10431.824k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 23026 -u -b 1249.874k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 23027 -u -b 10693.536k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 23028 -u -b 11468.343k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 23029 -u -b 9723.773k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 23030 -u -b 4708.203k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 23032 -u -b 7593.188k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 23033 -u -b 12254.089k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 23034 -u -b 7991.031k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 23035 -u -b 441.307k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 23037 -u -b 4923.971k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 23038 -u -b 11614.241k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 23039 -u -b 9902.277k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 23041 -u -b 599.292k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 23042 -u -b 8052.583k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 23043 -u -b 7883.771k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 23044 -u -b 9933.037k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 23045 -u -b 6161.550k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 23046 -u -b 9757.244k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 23047 -u -b 5561.964k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 23048 -u -b 7823.682k -w 256k -t 30 &
sleep 0.4