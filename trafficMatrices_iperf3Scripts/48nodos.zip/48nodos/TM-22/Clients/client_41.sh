 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 41001 -u -b 386.253k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 41002 -u -b 141.405k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 41003 -u -b 690.190k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 41004 -u -b 48.907k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 41005 -u -b 307.030k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 41006 -u -b 664.272k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 41007 -u -b 42.657k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 41008 -u -b 658.158k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 41011 -u -b 358.316k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 41014 -u -b 503.116k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 41016 -u -b 89.002k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 41018 -u -b 516.503k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 41021 -u -b 689.873k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 41022 -u -b 540.089k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 41024 -u -b 249.368k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 41025 -u -b 167.948k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 41026 -u -b 64.710k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 41027 -u -b 553.639k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 41028 -u -b 593.753k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 41029 -u -b 503.431k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 41030 -u -b 243.759k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 41031 -u -b 597.949k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 41033 -u -b 634.433k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 41034 -u -b 413.721k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 41036 -u -b 335.984k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 41039 -u -b 512.673k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 41040 -u -b 292.304k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 41042 -u -b 416.908k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 41043 -u -b 408.168k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 41044 -u -b 514.265k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 41045 -u -b 319.003k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 41047 -u -b 287.961k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 41048 -u -b 405.057k -w 256k -t 30 &
sleep 0.4