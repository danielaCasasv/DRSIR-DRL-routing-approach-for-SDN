 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 16001 -u -b 1107.967k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 16002 -u -b 405.621k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 16003 -u -b 1979.810k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 16005 -u -b 880.714k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 16006 -u -b 1905.463k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 16008 -u -b 1887.925k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 16010 -u -b 295.615k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 16012 -u -b 768.102k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 16013 -u -b 1244.295k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 16014 -u -b 1443.188k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 16017 -u -b 313.237k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 16018 -u -b 1481.587k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 16020 -u -b 877.168k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 16021 -u -b 1978.899k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 16022 -u -b 1549.244k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 16026 -u -b 185.621k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 16027 -u -b 1588.111k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 16030 -u -b 699.222k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 16031 -u -b 1715.216k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 16032 -u -b 1127.674k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 16033 -u -b 1819.871k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 16034 -u -b 1186.759k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 16035 -u -b 65.539k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 16036 -u -b 963.769k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 16037 -u -b 731.266k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 16038 -u -b 1724.846k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 16040 -u -b 838.472k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 16042 -u -b 1195.900k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 16044 -u -b 1475.169k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 16045 -u -b 915.060k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 16046 -u -b 1449.061k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 16047 -u -b 826.015k -w 256k -t 30 &
sleep 0.4