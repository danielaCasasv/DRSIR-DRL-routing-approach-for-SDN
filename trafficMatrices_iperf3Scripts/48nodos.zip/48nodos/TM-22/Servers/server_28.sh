 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1028 -1 &
sleep 0.3
iperf3 -s -p 2028 -1 &
sleep 0.3
iperf3 -s -p 3028 -1 &
sleep 0.3
iperf3 -s -p 5028 -1 &
sleep 0.3
iperf3 -s -p 6028 -1 &
sleep 0.3
iperf3 -s -p 7028 -1 &
sleep 0.3
iperf3 -s -p 8028 -1 &
sleep 0.3
iperf3 -s -p 9028 -1 &
sleep 0.3
iperf3 -s -p 10028 -1 &
sleep 0.3
iperf3 -s -p 11028 -1 &
sleep 0.3
iperf3 -s -p 15028 -1 &
sleep 0.3
iperf3 -s -p 18028 -1 &
sleep 0.3
iperf3 -s -p 19028 -1 &
sleep 0.3
iperf3 -s -p 20028 -1 &
sleep 0.3
iperf3 -s -p 21028 -1 &
sleep 0.3
iperf3 -s -p 23028 -1 &
sleep 0.3
iperf3 -s -p 25028 -1 &
sleep 0.3
iperf3 -s -p 27028 -1 &
sleep 0.3
iperf3 -s -p 29028 -1 &
sleep 0.3
iperf3 -s -p 30028 -1 &
sleep 0.3
iperf3 -s -p 31028 -1 &
sleep 0.3
iperf3 -s -p 33028 -1 &
sleep 0.3
iperf3 -s -p 34028 -1 &
sleep 0.3
iperf3 -s -p 37028 -1 &
sleep 0.3
iperf3 -s -p 38028 -1 &
sleep 0.3
iperf3 -s -p 39028 -1 &
sleep 0.3
iperf3 -s -p 40028 -1 &
sleep 0.3
iperf3 -s -p 41028 -1 &
sleep 0.3
iperf3 -s -p 42028 -1 &
sleep 0.3
iperf3 -s -p 43028 -1 &
sleep 0.3
iperf3 -s -p 45028 -1 &
sleep 0.3
iperf3 -s -p 47028 -1 &
sleep 0.3
iperf3 -s -p 48028 -1 &
sleep 0.3