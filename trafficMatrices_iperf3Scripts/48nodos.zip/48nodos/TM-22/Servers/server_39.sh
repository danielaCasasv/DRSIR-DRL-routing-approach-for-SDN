 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 2039 -1 &
sleep 0.3
iperf3 -s -p 3039 -1 &
sleep 0.3
iperf3 -s -p 4039 -1 &
sleep 0.3
iperf3 -s -p 5039 -1 &
sleep 0.3
iperf3 -s -p 7039 -1 &
sleep 0.3
iperf3 -s -p 8039 -1 &
sleep 0.3
iperf3 -s -p 9039 -1 &
sleep 0.3
iperf3 -s -p 10039 -1 &
sleep 0.3
iperf3 -s -p 11039 -1 &
sleep 0.3
iperf3 -s -p 12039 -1 &
sleep 0.3
iperf3 -s -p 14039 -1 &
sleep 0.3
iperf3 -s -p 15039 -1 &
sleep 0.3
iperf3 -s -p 17039 -1 &
sleep 0.3
iperf3 -s -p 18039 -1 &
sleep 0.3
iperf3 -s -p 19039 -1 &
sleep 0.3
iperf3 -s -p 20039 -1 &
sleep 0.3
iperf3 -s -p 21039 -1 &
sleep 0.3
iperf3 -s -p 23039 -1 &
sleep 0.3
iperf3 -s -p 25039 -1 &
sleep 0.3
iperf3 -s -p 27039 -1 &
sleep 0.3
iperf3 -s -p 28039 -1 &
sleep 0.3
iperf3 -s -p 31039 -1 &
sleep 0.3
iperf3 -s -p 32039 -1 &
sleep 0.3
iperf3 -s -p 33039 -1 &
sleep 0.3
iperf3 -s -p 35039 -1 &
sleep 0.3
iperf3 -s -p 36039 -1 &
sleep 0.3
iperf3 -s -p 37039 -1 &
sleep 0.3
iperf3 -s -p 40039 -1 &
sleep 0.3
iperf3 -s -p 41039 -1 &
sleep 0.3
iperf3 -s -p 43039 -1 &
sleep 0.3
iperf3 -s -p 44039 -1 &
sleep 0.3
iperf3 -s -p 45039 -1 &
sleep 0.3
iperf3 -s -p 47039 -1 &
sleep 0.3
iperf3 -s -p 48039 -1 &
sleep 0.3