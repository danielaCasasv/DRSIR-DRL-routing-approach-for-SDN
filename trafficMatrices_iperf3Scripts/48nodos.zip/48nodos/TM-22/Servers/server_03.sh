 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1003 -1 &
sleep 0.3
iperf3 -s -p 5003 -1 &
sleep 0.3
iperf3 -s -p 6003 -1 &
sleep 0.3
iperf3 -s -p 7003 -1 &
sleep 0.3
iperf3 -s -p 8003 -1 &
sleep 0.3
iperf3 -s -p 12003 -1 &
sleep 0.3
iperf3 -s -p 13003 -1 &
sleep 0.3
iperf3 -s -p 15003 -1 &
sleep 0.3
iperf3 -s -p 16003 -1 &
sleep 0.3
iperf3 -s -p 17003 -1 &
sleep 0.3
iperf3 -s -p 18003 -1 &
sleep 0.3
iperf3 -s -p 19003 -1 &
sleep 0.3
iperf3 -s -p 20003 -1 &
sleep 0.3
iperf3 -s -p 22003 -1 &
sleep 0.3
iperf3 -s -p 23003 -1 &
sleep 0.3
iperf3 -s -p 24003 -1 &
sleep 0.3
iperf3 -s -p 25003 -1 &
sleep 0.3
iperf3 -s -p 26003 -1 &
sleep 0.3
iperf3 -s -p 29003 -1 &
sleep 0.3
iperf3 -s -p 30003 -1 &
sleep 0.3
iperf3 -s -p 31003 -1 &
sleep 0.3
iperf3 -s -p 32003 -1 &
sleep 0.3
iperf3 -s -p 35003 -1 &
sleep 0.3
iperf3 -s -p 36003 -1 &
sleep 0.3
iperf3 -s -p 37003 -1 &
sleep 0.3
iperf3 -s -p 38003 -1 &
sleep 0.3
iperf3 -s -p 39003 -1 &
sleep 0.3
iperf3 -s -p 40003 -1 &
sleep 0.3
iperf3 -s -p 41003 -1 &
sleep 0.3
iperf3 -s -p 42003 -1 &
sleep 0.3
iperf3 -s -p 44003 -1 &
sleep 0.3
iperf3 -s -p 45003 -1 &
sleep 0.3
iperf3 -s -p 46003 -1 &
sleep 0.3