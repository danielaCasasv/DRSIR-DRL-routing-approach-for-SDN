 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 3034 -1 &
sleep 0.3
iperf3 -s -p 5034 -1 &
sleep 0.3
iperf3 -s -p 7034 -1 &
sleep 0.3
iperf3 -s -p 8034 -1 &
sleep 0.3
iperf3 -s -p 9034 -1 &
sleep 0.3
iperf3 -s -p 12034 -1 &
sleep 0.3
iperf3 -s -p 13034 -1 &
sleep 0.3
iperf3 -s -p 14034 -1 &
sleep 0.3
iperf3 -s -p 16034 -1 &
sleep 0.3
iperf3 -s -p 19034 -1 &
sleep 0.3
iperf3 -s -p 21034 -1 &
sleep 0.3
iperf3 -s -p 22034 -1 &
sleep 0.3
iperf3 -s -p 23034 -1 &
sleep 0.3
iperf3 -s -p 24034 -1 &
sleep 0.3
iperf3 -s -p 26034 -1 &
sleep 0.3
iperf3 -s -p 27034 -1 &
sleep 0.3
iperf3 -s -p 28034 -1 &
sleep 0.3
iperf3 -s -p 29034 -1 &
sleep 0.3
iperf3 -s -p 30034 -1 &
sleep 0.3
iperf3 -s -p 31034 -1 &
sleep 0.3
iperf3 -s -p 32034 -1 &
sleep 0.3
iperf3 -s -p 33034 -1 &
sleep 0.3
iperf3 -s -p 35034 -1 &
sleep 0.3
iperf3 -s -p 36034 -1 &
sleep 0.3
iperf3 -s -p 37034 -1 &
sleep 0.3
iperf3 -s -p 38034 -1 &
sleep 0.3
iperf3 -s -p 39034 -1 &
sleep 0.3
iperf3 -s -p 41034 -1 &
sleep 0.3
iperf3 -s -p 43034 -1 &
sleep 0.3
iperf3 -s -p 44034 -1 &
sleep 0.3
iperf3 -s -p 48034 -1 &
sleep 0.3