 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1048 -1 &
sleep 0.3
iperf3 -s -p 3048 -1 &
sleep 0.3
iperf3 -s -p 4048 -1 &
sleep 0.3
iperf3 -s -p 5048 -1 &
sleep 0.3
iperf3 -s -p 6048 -1 &
sleep 0.3
iperf3 -s -p 7048 -1 &
sleep 0.3
iperf3 -s -p 8048 -1 &
sleep 0.3
iperf3 -s -p 10048 -1 &
sleep 0.3
iperf3 -s -p 11048 -1 &
sleep 0.3
iperf3 -s -p 12048 -1 &
sleep 0.3
iperf3 -s -p 14048 -1 &
sleep 0.3
iperf3 -s -p 15048 -1 &
sleep 0.3
iperf3 -s -p 18048 -1 &
sleep 0.3
iperf3 -s -p 19048 -1 &
sleep 0.3
iperf3 -s -p 21048 -1 &
sleep 0.3
iperf3 -s -p 22048 -1 &
sleep 0.3
iperf3 -s -p 23048 -1 &
sleep 0.3
iperf3 -s -p 24048 -1 &
sleep 0.3
iperf3 -s -p 25048 -1 &
sleep 0.3
iperf3 -s -p 30048 -1 &
sleep 0.3
iperf3 -s -p 31048 -1 &
sleep 0.3
iperf3 -s -p 33048 -1 &
sleep 0.3
iperf3 -s -p 34048 -1 &
sleep 0.3
iperf3 -s -p 35048 -1 &
sleep 0.3
iperf3 -s -p 36048 -1 &
sleep 0.3
iperf3 -s -p 37048 -1 &
sleep 0.3
iperf3 -s -p 38048 -1 &
sleep 0.3
iperf3 -s -p 39048 -1 &
sleep 0.3
iperf3 -s -p 40048 -1 &
sleep 0.3
iperf3 -s -p 41048 -1 &
sleep 0.3
iperf3 -s -p 44048 -1 &
sleep 0.3
iperf3 -s -p 45048 -1 &
sleep 0.3
iperf3 -s -p 47048 -1 &
sleep 0.3