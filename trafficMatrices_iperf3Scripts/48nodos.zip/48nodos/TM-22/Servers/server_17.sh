 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 2017 -1 &
sleep 0.3
iperf3 -s -p 4017 -1 &
sleep 0.3
iperf3 -s -p 5017 -1 &
sleep 0.3
iperf3 -s -p 6017 -1 &
sleep 0.3
iperf3 -s -p 8017 -1 &
sleep 0.3
iperf3 -s -p 11017 -1 &
sleep 0.3
iperf3 -s -p 12017 -1 &
sleep 0.3
iperf3 -s -p 13017 -1 &
sleep 0.3
iperf3 -s -p 14017 -1 &
sleep 0.3
iperf3 -s -p 15017 -1 &
sleep 0.3
iperf3 -s -p 16017 -1 &
sleep 0.3
iperf3 -s -p 18017 -1 &
sleep 0.3
iperf3 -s -p 19017 -1 &
sleep 0.3
iperf3 -s -p 21017 -1 &
sleep 0.3
iperf3 -s -p 23017 -1 &
sleep 0.3
iperf3 -s -p 26017 -1 &
sleep 0.3
iperf3 -s -p 28017 -1 &
sleep 0.3
iperf3 -s -p 29017 -1 &
sleep 0.3
iperf3 -s -p 30017 -1 &
sleep 0.3
iperf3 -s -p 31017 -1 &
sleep 0.3
iperf3 -s -p 32017 -1 &
sleep 0.3
iperf3 -s -p 35017 -1 &
sleep 0.3
iperf3 -s -p 37017 -1 &
sleep 0.3
iperf3 -s -p 38017 -1 &
sleep 0.3
iperf3 -s -p 40017 -1 &
sleep 0.3
iperf3 -s -p 42017 -1 &
sleep 0.3
iperf3 -s -p 43017 -1 &
sleep 0.3
iperf3 -s -p 45017 -1 &
sleep 0.3
iperf3 -s -p 46017 -1 &
sleep 0.3
iperf3 -s -p 47017 -1 &
sleep 0.3
iperf3 -s -p 48017 -1 &
sleep 0.3