 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1045 -1 &
sleep 0.3
iperf3 -s -p 4045 -1 &
sleep 0.3
iperf3 -s -p 5045 -1 &
sleep 0.3
iperf3 -s -p 6045 -1 &
sleep 0.3
iperf3 -s -p 7045 -1 &
sleep 0.3
iperf3 -s -p 9045 -1 &
sleep 0.3
iperf3 -s -p 10045 -1 &
sleep 0.3
iperf3 -s -p 11045 -1 &
sleep 0.3
iperf3 -s -p 12045 -1 &
sleep 0.3
iperf3 -s -p 13045 -1 &
sleep 0.3
iperf3 -s -p 14045 -1 &
sleep 0.3
iperf3 -s -p 16045 -1 &
sleep 0.3
iperf3 -s -p 17045 -1 &
sleep 0.3
iperf3 -s -p 19045 -1 &
sleep 0.3
iperf3 -s -p 20045 -1 &
sleep 0.3
iperf3 -s -p 21045 -1 &
sleep 0.3
iperf3 -s -p 23045 -1 &
sleep 0.3
iperf3 -s -p 24045 -1 &
sleep 0.3
iperf3 -s -p 26045 -1 &
sleep 0.3
iperf3 -s -p 27045 -1 &
sleep 0.3
iperf3 -s -p 28045 -1 &
sleep 0.3
iperf3 -s -p 29045 -1 &
sleep 0.3
iperf3 -s -p 30045 -1 &
sleep 0.3
iperf3 -s -p 31045 -1 &
sleep 0.3
iperf3 -s -p 33045 -1 &
sleep 0.3
iperf3 -s -p 34045 -1 &
sleep 0.3
iperf3 -s -p 37045 -1 &
sleep 0.3
iperf3 -s -p 40045 -1 &
sleep 0.3
iperf3 -s -p 41045 -1 &
sleep 0.3
iperf3 -s -p 42045 -1 &
sleep 0.3
iperf3 -s -p 44045 -1 &
sleep 0.3
iperf3 -s -p 46045 -1 &
sleep 0.3
iperf3 -s -p 47045 -1 &
sleep 0.3