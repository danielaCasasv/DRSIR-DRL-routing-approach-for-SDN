 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1002 -1 &
sleep 0.3
iperf3 -s -p 3002 -1 &
sleep 0.3
iperf3 -s -p 6002 -1 &
sleep 0.3
iperf3 -s -p 7002 -1 &
sleep 0.3
iperf3 -s -p 8002 -1 &
sleep 0.3
iperf3 -s -p 9002 -1 &
sleep 0.3
iperf3 -s -p 11002 -1 &
sleep 0.3
iperf3 -s -p 12002 -1 &
sleep 0.3
iperf3 -s -p 15002 -1 &
sleep 0.3
iperf3 -s -p 16002 -1 &
sleep 0.3
iperf3 -s -p 17002 -1 &
sleep 0.3
iperf3 -s -p 19002 -1 &
sleep 0.3
iperf3 -s -p 22002 -1 &
sleep 0.3
iperf3 -s -p 23002 -1 &
sleep 0.3
iperf3 -s -p 24002 -1 &
sleep 0.3
iperf3 -s -p 25002 -1 &
sleep 0.3
iperf3 -s -p 26002 -1 &
sleep 0.3
iperf3 -s -p 27002 -1 &
sleep 0.3
iperf3 -s -p 28002 -1 &
sleep 0.3
iperf3 -s -p 29002 -1 &
sleep 0.3
iperf3 -s -p 30002 -1 &
sleep 0.3
iperf3 -s -p 31002 -1 &
sleep 0.3
iperf3 -s -p 33002 -1 &
sleep 0.3
iperf3 -s -p 34002 -1 &
sleep 0.3
iperf3 -s -p 35002 -1 &
sleep 0.3
iperf3 -s -p 36002 -1 &
sleep 0.3
iperf3 -s -p 37002 -1 &
sleep 0.3
iperf3 -s -p 38002 -1 &
sleep 0.3
iperf3 -s -p 40002 -1 &
sleep 0.3
iperf3 -s -p 41002 -1 &
sleep 0.3
iperf3 -s -p 43002 -1 &
sleep 0.3
iperf3 -s -p 46002 -1 &
sleep 0.3
iperf3 -s -p 47002 -1 &
sleep 0.3
iperf3 -s -p 48002 -1 &
sleep 0.3