 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 3022 -1 &
sleep 0.3
iperf3 -s -p 4022 -1 &
sleep 0.3
iperf3 -s -p 5022 -1 &
sleep 0.3
iperf3 -s -p 6022 -1 &
sleep 0.3
iperf3 -s -p 7022 -1 &
sleep 0.3
iperf3 -s -p 8022 -1 &
sleep 0.3
iperf3 -s -p 9022 -1 &
sleep 0.3
iperf3 -s -p 11022 -1 &
sleep 0.3
iperf3 -s -p 14022 -1 &
sleep 0.3
iperf3 -s -p 15022 -1 &
sleep 0.3
iperf3 -s -p 16022 -1 &
sleep 0.3
iperf3 -s -p 17022 -1 &
sleep 0.3
iperf3 -s -p 18022 -1 &
sleep 0.3
iperf3 -s -p 19022 -1 &
sleep 0.3
iperf3 -s -p 21022 -1 &
sleep 0.3
iperf3 -s -p 23022 -1 &
sleep 0.3
iperf3 -s -p 24022 -1 &
sleep 0.3
iperf3 -s -p 25022 -1 &
sleep 0.3
iperf3 -s -p 27022 -1 &
sleep 0.3
iperf3 -s -p 28022 -1 &
sleep 0.3
iperf3 -s -p 29022 -1 &
sleep 0.3
iperf3 -s -p 30022 -1 &
sleep 0.3
iperf3 -s -p 31022 -1 &
sleep 0.3
iperf3 -s -p 33022 -1 &
sleep 0.3
iperf3 -s -p 35022 -1 &
sleep 0.3
iperf3 -s -p 36022 -1 &
sleep 0.3
iperf3 -s -p 37022 -1 &
sleep 0.3
iperf3 -s -p 39022 -1 &
sleep 0.3
iperf3 -s -p 41022 -1 &
sleep 0.3
iperf3 -s -p 42022 -1 &
sleep 0.3
iperf3 -s -p 43022 -1 &
sleep 0.3
iperf3 -s -p 44022 -1 &
sleep 0.3
iperf3 -s -p 46022 -1 &
sleep 0.3