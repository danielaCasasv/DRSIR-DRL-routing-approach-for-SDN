 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1024 -1 &
sleep 0.3
iperf3 -s -p 3024 -1 &
sleep 0.3
iperf3 -s -p 5024 -1 &
sleep 0.3
iperf3 -s -p 7024 -1 &
sleep 0.3
iperf3 -s -p 8024 -1 &
sleep 0.3
iperf3 -s -p 9024 -1 &
sleep 0.3
iperf3 -s -p 10024 -1 &
sleep 0.3
iperf3 -s -p 12024 -1 &
sleep 0.3
iperf3 -s -p 13024 -1 &
sleep 0.3
iperf3 -s -p 18024 -1 &
sleep 0.3
iperf3 -s -p 20024 -1 &
sleep 0.3
iperf3 -s -p 26024 -1 &
sleep 0.3
iperf3 -s -p 28024 -1 &
sleep 0.3
iperf3 -s -p 30024 -1 &
sleep 0.3
iperf3 -s -p 31024 -1 &
sleep 0.3
iperf3 -s -p 32024 -1 &
sleep 0.3
iperf3 -s -p 34024 -1 &
sleep 0.3
iperf3 -s -p 36024 -1 &
sleep 0.3
iperf3 -s -p 37024 -1 &
sleep 0.3
iperf3 -s -p 39024 -1 &
sleep 0.3
iperf3 -s -p 41024 -1 &
sleep 0.3
iperf3 -s -p 42024 -1 &
sleep 0.3
iperf3 -s -p 44024 -1 &
sleep 0.3
iperf3 -s -p 45024 -1 &
sleep 0.3
iperf3 -s -p 46024 -1 &
sleep 0.3
iperf3 -s -p 47024 -1 &
sleep 0.3
iperf3 -s -p 48024 -1 &
sleep 0.3