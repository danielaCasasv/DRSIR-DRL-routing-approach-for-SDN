 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 3021 -1 &
sleep 0.3
iperf3 -s -p 5021 -1 &
sleep 0.3
iperf3 -s -p 8021 -1 &
sleep 0.3
iperf3 -s -p 9021 -1 &
sleep 0.3
iperf3 -s -p 10021 -1 &
sleep 0.3
iperf3 -s -p 11021 -1 &
sleep 0.3
iperf3 -s -p 12021 -1 &
sleep 0.3
iperf3 -s -p 13021 -1 &
sleep 0.3
iperf3 -s -p 14021 -1 &
sleep 0.3
iperf3 -s -p 15021 -1 &
sleep 0.3
iperf3 -s -p 16021 -1 &
sleep 0.3
iperf3 -s -p 17021 -1 &
sleep 0.3
iperf3 -s -p 18021 -1 &
sleep 0.3
iperf3 -s -p 20021 -1 &
sleep 0.3
iperf3 -s -p 22021 -1 &
sleep 0.3
iperf3 -s -p 23021 -1 &
sleep 0.3
iperf3 -s -p 24021 -1 &
sleep 0.3
iperf3 -s -p 29021 -1 &
sleep 0.3
iperf3 -s -p 31021 -1 &
sleep 0.3
iperf3 -s -p 34021 -1 &
sleep 0.3
iperf3 -s -p 35021 -1 &
sleep 0.3
iperf3 -s -p 36021 -1 &
sleep 0.3
iperf3 -s -p 37021 -1 &
sleep 0.3
iperf3 -s -p 39021 -1 &
sleep 0.3
iperf3 -s -p 40021 -1 &
sleep 0.3
iperf3 -s -p 41021 -1 &
sleep 0.3
iperf3 -s -p 42021 -1 &
sleep 0.3
iperf3 -s -p 43021 -1 &
sleep 0.3
iperf3 -s -p 45021 -1 &
sleep 0.3
iperf3 -s -p 47021 -1 &
sleep 0.3
iperf3 -s -p 48021 -1 &
sleep 0.3