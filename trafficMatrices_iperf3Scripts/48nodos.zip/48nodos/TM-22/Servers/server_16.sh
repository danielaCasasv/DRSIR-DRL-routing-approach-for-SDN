 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 3016 -1 &
sleep 0.3
iperf3 -s -p 4016 -1 &
sleep 0.3
iperf3 -s -p 5016 -1 &
sleep 0.3
iperf3 -s -p 6016 -1 &
sleep 0.3
iperf3 -s -p 7016 -1 &
sleep 0.3
iperf3 -s -p 8016 -1 &
sleep 0.3
iperf3 -s -p 10016 -1 &
sleep 0.3
iperf3 -s -p 11016 -1 &
sleep 0.3
iperf3 -s -p 13016 -1 &
sleep 0.3
iperf3 -s -p 14016 -1 &
sleep 0.3
iperf3 -s -p 15016 -1 &
sleep 0.3
iperf3 -s -p 19016 -1 &
sleep 0.3
iperf3 -s -p 20016 -1 &
sleep 0.3
iperf3 -s -p 21016 -1 &
sleep 0.3
iperf3 -s -p 22016 -1 &
sleep 0.3
iperf3 -s -p 23016 -1 &
sleep 0.3
iperf3 -s -p 25016 -1 &
sleep 0.3
iperf3 -s -p 26016 -1 &
sleep 0.3
iperf3 -s -p 27016 -1 &
sleep 0.3
iperf3 -s -p 28016 -1 &
sleep 0.3
iperf3 -s -p 30016 -1 &
sleep 0.3
iperf3 -s -p 31016 -1 &
sleep 0.3
iperf3 -s -p 33016 -1 &
sleep 0.3
iperf3 -s -p 35016 -1 &
sleep 0.3
iperf3 -s -p 38016 -1 &
sleep 0.3
iperf3 -s -p 39016 -1 &
sleep 0.3
iperf3 -s -p 41016 -1 &
sleep 0.3
iperf3 -s -p 43016 -1 &
sleep 0.3
iperf3 -s -p 44016 -1 &
sleep 0.3
iperf3 -s -p 45016 -1 &
sleep 0.3
iperf3 -s -p 48016 -1 &
sleep 0.3