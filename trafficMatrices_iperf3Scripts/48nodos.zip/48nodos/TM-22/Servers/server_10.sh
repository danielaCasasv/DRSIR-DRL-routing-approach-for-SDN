 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1010 -1 &
sleep 0.3
iperf3 -s -p 2010 -1 &
sleep 0.3
iperf3 -s -p 3010 -1 &
sleep 0.3
iperf3 -s -p 4010 -1 &
sleep 0.3
iperf3 -s -p 6010 -1 &
sleep 0.3
iperf3 -s -p 7010 -1 &
sleep 0.3
iperf3 -s -p 8010 -1 &
sleep 0.3
iperf3 -s -p 9010 -1 &
sleep 0.3
iperf3 -s -p 11010 -1 &
sleep 0.3
iperf3 -s -p 13010 -1 &
sleep 0.3
iperf3 -s -p 15010 -1 &
sleep 0.3
iperf3 -s -p 16010 -1 &
sleep 0.3
iperf3 -s -p 17010 -1 &
sleep 0.3
iperf3 -s -p 18010 -1 &
sleep 0.3
iperf3 -s -p 19010 -1 &
sleep 0.3
iperf3 -s -p 20010 -1 &
sleep 0.3
iperf3 -s -p 22010 -1 &
sleep 0.3
iperf3 -s -p 23010 -1 &
sleep 0.3
iperf3 -s -p 24010 -1 &
sleep 0.3
iperf3 -s -p 25010 -1 &
sleep 0.3
iperf3 -s -p 26010 -1 &
sleep 0.3
iperf3 -s -p 27010 -1 &
sleep 0.3
iperf3 -s -p 29010 -1 &
sleep 0.3
iperf3 -s -p 31010 -1 &
sleep 0.3
iperf3 -s -p 32010 -1 &
sleep 0.3
iperf3 -s -p 33010 -1 &
sleep 0.3
iperf3 -s -p 34010 -1 &
sleep 0.3
iperf3 -s -p 35010 -1 &
sleep 0.3
iperf3 -s -p 36010 -1 &
sleep 0.3
iperf3 -s -p 37010 -1 &
sleep 0.3
iperf3 -s -p 40010 -1 &
sleep 0.3
iperf3 -s -p 42010 -1 &
sleep 0.3
iperf3 -s -p 43010 -1 &
sleep 0.3
iperf3 -s -p 44010 -1 &
sleep 0.3
iperf3 -s -p 45010 -1 &
sleep 0.3
iperf3 -s -p 46010 -1 &
sleep 0.3
iperf3 -s -p 47010 -1 &
sleep 0.3
iperf3 -s -p 48010 -1 &
sleep 0.3