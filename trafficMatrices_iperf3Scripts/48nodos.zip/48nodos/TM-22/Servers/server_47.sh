 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 2047 -1 &
sleep 0.3
iperf3 -s -p 3047 -1 &
sleep 0.3
iperf3 -s -p 4047 -1 &
sleep 0.3
iperf3 -s -p 5047 -1 &
sleep 0.3
iperf3 -s -p 6047 -1 &
sleep 0.3
iperf3 -s -p 7047 -1 &
sleep 0.3
iperf3 -s -p 8047 -1 &
sleep 0.3
iperf3 -s -p 9047 -1 &
sleep 0.3
iperf3 -s -p 10047 -1 &
sleep 0.3
iperf3 -s -p 12047 -1 &
sleep 0.3
iperf3 -s -p 13047 -1 &
sleep 0.3
iperf3 -s -p 14047 -1 &
sleep 0.3
iperf3 -s -p 15047 -1 &
sleep 0.3
iperf3 -s -p 16047 -1 &
sleep 0.3
iperf3 -s -p 17047 -1 &
sleep 0.3
iperf3 -s -p 19047 -1 &
sleep 0.3
iperf3 -s -p 20047 -1 &
sleep 0.3
iperf3 -s -p 21047 -1 &
sleep 0.3
iperf3 -s -p 22047 -1 &
sleep 0.3
iperf3 -s -p 23047 -1 &
sleep 0.3
iperf3 -s -p 24047 -1 &
sleep 0.3
iperf3 -s -p 25047 -1 &
sleep 0.3
iperf3 -s -p 26047 -1 &
sleep 0.3
iperf3 -s -p 27047 -1 &
sleep 0.3
iperf3 -s -p 29047 -1 &
sleep 0.3
iperf3 -s -p 30047 -1 &
sleep 0.3
iperf3 -s -p 31047 -1 &
sleep 0.3
iperf3 -s -p 32047 -1 &
sleep 0.3
iperf3 -s -p 34047 -1 &
sleep 0.3
iperf3 -s -p 35047 -1 &
sleep 0.3
iperf3 -s -p 36047 -1 &
sleep 0.3
iperf3 -s -p 37047 -1 &
sleep 0.3
iperf3 -s -p 38047 -1 &
sleep 0.3
iperf3 -s -p 39047 -1 &
sleep 0.3
iperf3 -s -p 40047 -1 &
sleep 0.3
iperf3 -s -p 41047 -1 &
sleep 0.3
iperf3 -s -p 42047 -1 &
sleep 0.3
iperf3 -s -p 43047 -1 &
sleep 0.3
iperf3 -s -p 44047 -1 &
sleep 0.3
iperf3 -s -p 45047 -1 &
sleep 0.3
iperf3 -s -p 46047 -1 &
sleep 0.3
iperf3 -s -p 48047 -1 &
sleep 0.3