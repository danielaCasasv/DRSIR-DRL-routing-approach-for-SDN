 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1006 -1 &
sleep 0.3
iperf3 -s -p 3006 -1 &
sleep 0.3
iperf3 -s -p 4006 -1 &
sleep 0.3
iperf3 -s -p 5006 -1 &
sleep 0.3
iperf3 -s -p 8006 -1 &
sleep 0.3
iperf3 -s -p 9006 -1 &
sleep 0.3
iperf3 -s -p 12006 -1 &
sleep 0.3
iperf3 -s -p 13006 -1 &
sleep 0.3
iperf3 -s -p 14006 -1 &
sleep 0.3
iperf3 -s -p 15006 -1 &
sleep 0.3
iperf3 -s -p 16006 -1 &
sleep 0.3
iperf3 -s -p 17006 -1 &
sleep 0.3
iperf3 -s -p 18006 -1 &
sleep 0.3
iperf3 -s -p 19006 -1 &
sleep 0.3
iperf3 -s -p 22006 -1 &
sleep 0.3
iperf3 -s -p 24006 -1 &
sleep 0.3
iperf3 -s -p 26006 -1 &
sleep 0.3
iperf3 -s -p 31006 -1 &
sleep 0.3
iperf3 -s -p 33006 -1 &
sleep 0.3
iperf3 -s -p 34006 -1 &
sleep 0.3
iperf3 -s -p 35006 -1 &
sleep 0.3
iperf3 -s -p 36006 -1 &
sleep 0.3
iperf3 -s -p 37006 -1 &
sleep 0.3
iperf3 -s -p 38006 -1 &
sleep 0.3
iperf3 -s -p 39006 -1 &
sleep 0.3
iperf3 -s -p 40006 -1 &
sleep 0.3
iperf3 -s -p 41006 -1 &
sleep 0.3
iperf3 -s -p 46006 -1 &
sleep 0.3
iperf3 -s -p 47006 -1 &
sleep 0.3
iperf3 -s -p 48006 -1 &
sleep 0.3