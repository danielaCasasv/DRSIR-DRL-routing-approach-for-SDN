 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1037 -1 &
sleep 0.3
iperf3 -s -p 2037 -1 &
sleep 0.3
iperf3 -s -p 3037 -1 &
sleep 0.3
iperf3 -s -p 4037 -1 &
sleep 0.3
iperf3 -s -p 5037 -1 &
sleep 0.3
iperf3 -s -p 6037 -1 &
sleep 0.3
iperf3 -s -p 9037 -1 &
sleep 0.3
iperf3 -s -p 10037 -1 &
sleep 0.3
iperf3 -s -p 11037 -1 &
sleep 0.3
iperf3 -s -p 13037 -1 &
sleep 0.3
iperf3 -s -p 14037 -1 &
sleep 0.3
iperf3 -s -p 15037 -1 &
sleep 0.3
iperf3 -s -p 16037 -1 &
sleep 0.3
iperf3 -s -p 19037 -1 &
sleep 0.3
iperf3 -s -p 20037 -1 &
sleep 0.3
iperf3 -s -p 21037 -1 &
sleep 0.3
iperf3 -s -p 23037 -1 &
sleep 0.3
iperf3 -s -p 24037 -1 &
sleep 0.3
iperf3 -s -p 25037 -1 &
sleep 0.3
iperf3 -s -p 26037 -1 &
sleep 0.3
iperf3 -s -p 27037 -1 &
sleep 0.3
iperf3 -s -p 28037 -1 &
sleep 0.3
iperf3 -s -p 29037 -1 &
sleep 0.3
iperf3 -s -p 30037 -1 &
sleep 0.3
iperf3 -s -p 31037 -1 &
sleep 0.3
iperf3 -s -p 33037 -1 &
sleep 0.3
iperf3 -s -p 34037 -1 &
sleep 0.3
iperf3 -s -p 35037 -1 &
sleep 0.3
iperf3 -s -p 38037 -1 &
sleep 0.3
iperf3 -s -p 39037 -1 &
sleep 0.3
iperf3 -s -p 42037 -1 &
sleep 0.3
iperf3 -s -p 43037 -1 &
sleep 0.3
iperf3 -s -p 44037 -1 &
sleep 0.3
iperf3 -s -p 45037 -1 &
sleep 0.3
iperf3 -s -p 47037 -1 &
sleep 0.3
iperf3 -s -p 48037 -1 &
sleep 0.3