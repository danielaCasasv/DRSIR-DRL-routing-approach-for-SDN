 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1038 -1 &
sleep 0.3
iperf3 -s -p 4038 -1 &
sleep 0.3
iperf3 -s -p 7038 -1 &
sleep 0.3
iperf3 -s -p 8038 -1 &
sleep 0.3
iperf3 -s -p 9038 -1 &
sleep 0.3
iperf3 -s -p 10038 -1 &
sleep 0.3
iperf3 -s -p 11038 -1 &
sleep 0.3
iperf3 -s -p 12038 -1 &
sleep 0.3
iperf3 -s -p 14038 -1 &
sleep 0.3
iperf3 -s -p 15038 -1 &
sleep 0.3
iperf3 -s -p 16038 -1 &
sleep 0.3
iperf3 -s -p 17038 -1 &
sleep 0.3
iperf3 -s -p 21038 -1 &
sleep 0.3
iperf3 -s -p 22038 -1 &
sleep 0.3
iperf3 -s -p 23038 -1 &
sleep 0.3
iperf3 -s -p 24038 -1 &
sleep 0.3
iperf3 -s -p 25038 -1 &
sleep 0.3
iperf3 -s -p 26038 -1 &
sleep 0.3
iperf3 -s -p 27038 -1 &
sleep 0.3
iperf3 -s -p 29038 -1 &
sleep 0.3
iperf3 -s -p 30038 -1 &
sleep 0.3
iperf3 -s -p 32038 -1 &
sleep 0.3
iperf3 -s -p 35038 -1 &
sleep 0.3
iperf3 -s -p 36038 -1 &
sleep 0.3
iperf3 -s -p 39038 -1 &
sleep 0.3
iperf3 -s -p 40038 -1 &
sleep 0.3
iperf3 -s -p 45038 -1 &
sleep 0.3
iperf3 -s -p 46038 -1 &
sleep 0.3
iperf3 -s -p 47038 -1 &
sleep 0.3