 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1020 -1 &
sleep 0.3
iperf3 -s -p 3020 -1 &
sleep 0.3
iperf3 -s -p 4020 -1 &
sleep 0.3
iperf3 -s -p 6020 -1 &
sleep 0.3
iperf3 -s -p 7020 -1 &
sleep 0.3
iperf3 -s -p 8020 -1 &
sleep 0.3
iperf3 -s -p 9020 -1 &
sleep 0.3
iperf3 -s -p 10020 -1 &
sleep 0.3
iperf3 -s -p 15020 -1 &
sleep 0.3
iperf3 -s -p 16020 -1 &
sleep 0.3
iperf3 -s -p 17020 -1 &
sleep 0.3
iperf3 -s -p 18020 -1 &
sleep 0.3
iperf3 -s -p 19020 -1 &
sleep 0.3
iperf3 -s -p 21020 -1 &
sleep 0.3
iperf3 -s -p 23020 -1 &
sleep 0.3
iperf3 -s -p 26020 -1 &
sleep 0.3
iperf3 -s -p 28020 -1 &
sleep 0.3
iperf3 -s -p 29020 -1 &
sleep 0.3
iperf3 -s -p 31020 -1 &
sleep 0.3
iperf3 -s -p 32020 -1 &
sleep 0.3
iperf3 -s -p 38020 -1 &
sleep 0.3
iperf3 -s -p 40020 -1 &
sleep 0.3
iperf3 -s -p 44020 -1 &
sleep 0.3
iperf3 -s -p 46020 -1 &
sleep 0.3
iperf3 -s -p 47020 -1 &
sleep 0.3
iperf3 -s -p 48020 -1 &
sleep 0.3