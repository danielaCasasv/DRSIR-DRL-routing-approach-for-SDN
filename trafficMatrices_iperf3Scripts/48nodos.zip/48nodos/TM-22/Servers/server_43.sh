 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1043 -1 &
sleep 0.3
iperf3 -s -p 2043 -1 &
sleep 0.3
iperf3 -s -p 3043 -1 &
sleep 0.3
iperf3 -s -p 4043 -1 &
sleep 0.3
iperf3 -s -p 5043 -1 &
sleep 0.3
iperf3 -s -p 6043 -1 &
sleep 0.3
iperf3 -s -p 7043 -1 &
sleep 0.3
iperf3 -s -p 8043 -1 &
sleep 0.3
iperf3 -s -p 9043 -1 &
sleep 0.3
iperf3 -s -p 11043 -1 &
sleep 0.3
iperf3 -s -p 13043 -1 &
sleep 0.3
iperf3 -s -p 14043 -1 &
sleep 0.3
iperf3 -s -p 15043 -1 &
sleep 0.3
iperf3 -s -p 18043 -1 &
sleep 0.3
iperf3 -s -p 19043 -1 &
sleep 0.3
iperf3 -s -p 20043 -1 &
sleep 0.3
iperf3 -s -p 21043 -1 &
sleep 0.3
iperf3 -s -p 22043 -1 &
sleep 0.3
iperf3 -s -p 23043 -1 &
sleep 0.3
iperf3 -s -p 24043 -1 &
sleep 0.3
iperf3 -s -p 29043 -1 &
sleep 0.3
iperf3 -s -p 30043 -1 &
sleep 0.3
iperf3 -s -p 31043 -1 &
sleep 0.3
iperf3 -s -p 35043 -1 &
sleep 0.3
iperf3 -s -p 36043 -1 &
sleep 0.3
iperf3 -s -p 37043 -1 &
sleep 0.3
iperf3 -s -p 40043 -1 &
sleep 0.3
iperf3 -s -p 41043 -1 &
sleep 0.3
iperf3 -s -p 42043 -1 &
sleep 0.3
iperf3 -s -p 44043 -1 &
sleep 0.3
iperf3 -s -p 47043 -1 &
sleep 0.3
iperf3 -s -p 48043 -1 &
sleep 0.3