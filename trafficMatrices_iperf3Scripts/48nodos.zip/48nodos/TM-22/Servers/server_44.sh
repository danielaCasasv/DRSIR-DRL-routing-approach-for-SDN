 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1044 -1 &
sleep 0.3
iperf3 -s -p 2044 -1 &
sleep 0.3
iperf3 -s -p 3044 -1 &
sleep 0.3
iperf3 -s -p 5044 -1 &
sleep 0.3
iperf3 -s -p 7044 -1 &
sleep 0.3
iperf3 -s -p 10044 -1 &
sleep 0.3
iperf3 -s -p 11044 -1 &
sleep 0.3
iperf3 -s -p 14044 -1 &
sleep 0.3
iperf3 -s -p 16044 -1 &
sleep 0.3
iperf3 -s -p 17044 -1 &
sleep 0.3
iperf3 -s -p 18044 -1 &
sleep 0.3
iperf3 -s -p 19044 -1 &
sleep 0.3
iperf3 -s -p 20044 -1 &
sleep 0.3
iperf3 -s -p 21044 -1 &
sleep 0.3
iperf3 -s -p 23044 -1 &
sleep 0.3
iperf3 -s -p 25044 -1 &
sleep 0.3
iperf3 -s -p 27044 -1 &
sleep 0.3
iperf3 -s -p 28044 -1 &
sleep 0.3
iperf3 -s -p 29044 -1 &
sleep 0.3
iperf3 -s -p 30044 -1 &
sleep 0.3
iperf3 -s -p 31044 -1 &
sleep 0.3
iperf3 -s -p 32044 -1 &
sleep 0.3
iperf3 -s -p 33044 -1 &
sleep 0.3
iperf3 -s -p 35044 -1 &
sleep 0.3
iperf3 -s -p 36044 -1 &
sleep 0.3
iperf3 -s -p 37044 -1 &
sleep 0.3
iperf3 -s -p 38044 -1 &
sleep 0.3
iperf3 -s -p 39044 -1 &
sleep 0.3
iperf3 -s -p 41044 -1 &
sleep 0.3
iperf3 -s -p 42044 -1 &
sleep 0.3
iperf3 -s -p 43044 -1 &
sleep 0.3
iperf3 -s -p 45044 -1 &
sleep 0.3
iperf3 -s -p 46044 -1 &
sleep 0.3
iperf3 -s -p 47044 -1 &
sleep 0.3