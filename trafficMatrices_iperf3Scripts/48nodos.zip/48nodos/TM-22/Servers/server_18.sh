 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1018 -1 &
sleep 0.3
iperf3 -s -p 2018 -1 &
sleep 0.3
iperf3 -s -p 3018 -1 &
sleep 0.3
iperf3 -s -p 5018 -1 &
sleep 0.3
iperf3 -s -p 8018 -1 &
sleep 0.3
iperf3 -s -p 9018 -1 &
sleep 0.3
iperf3 -s -p 10018 -1 &
sleep 0.3
iperf3 -s -p 11018 -1 &
sleep 0.3
iperf3 -s -p 12018 -1 &
sleep 0.3
iperf3 -s -p 13018 -1 &
sleep 0.3
iperf3 -s -p 15018 -1 &
sleep 0.3
iperf3 -s -p 16018 -1 &
sleep 0.3
iperf3 -s -p 17018 -1 &
sleep 0.3
iperf3 -s -p 19018 -1 &
sleep 0.3
iperf3 -s -p 20018 -1 &
sleep 0.3
iperf3 -s -p 23018 -1 &
sleep 0.3
iperf3 -s -p 24018 -1 &
sleep 0.3
iperf3 -s -p 25018 -1 &
sleep 0.3
iperf3 -s -p 26018 -1 &
sleep 0.3
iperf3 -s -p 29018 -1 &
sleep 0.3
iperf3 -s -p 31018 -1 &
sleep 0.3
iperf3 -s -p 32018 -1 &
sleep 0.3
iperf3 -s -p 34018 -1 &
sleep 0.3
iperf3 -s -p 35018 -1 &
sleep 0.3
iperf3 -s -p 36018 -1 &
sleep 0.3
iperf3 -s -p 37018 -1 &
sleep 0.3
iperf3 -s -p 39018 -1 &
sleep 0.3
iperf3 -s -p 40018 -1 &
sleep 0.3
iperf3 -s -p 41018 -1 &
sleep 0.3
iperf3 -s -p 42018 -1 &
sleep 0.3
iperf3 -s -p 43018 -1 &
sleep 0.3
iperf3 -s -p 44018 -1 &
sleep 0.3
iperf3 -s -p 45018 -1 &
sleep 0.3
iperf3 -s -p 46018 -1 &
sleep 0.3