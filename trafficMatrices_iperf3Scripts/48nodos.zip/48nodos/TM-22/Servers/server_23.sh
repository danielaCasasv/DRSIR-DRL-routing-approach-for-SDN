 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1023 -1 &
sleep 0.3
iperf3 -s -p 2023 -1 &
sleep 0.3
iperf3 -s -p 3023 -1 &
sleep 0.3
iperf3 -s -p 4023 -1 &
sleep 0.3
iperf3 -s -p 5023 -1 &
sleep 0.3
iperf3 -s -p 6023 -1 &
sleep 0.3
iperf3 -s -p 7023 -1 &
sleep 0.3
iperf3 -s -p 8023 -1 &
sleep 0.3
iperf3 -s -p 9023 -1 &
sleep 0.3
iperf3 -s -p 10023 -1 &
sleep 0.3
iperf3 -s -p 12023 -1 &
sleep 0.3
iperf3 -s -p 13023 -1 &
sleep 0.3
iperf3 -s -p 14023 -1 &
sleep 0.3
iperf3 -s -p 17023 -1 &
sleep 0.3
iperf3 -s -p 19023 -1 &
sleep 0.3
iperf3 -s -p 20023 -1 &
sleep 0.3
iperf3 -s -p 21023 -1 &
sleep 0.3
iperf3 -s -p 22023 -1 &
sleep 0.3
iperf3 -s -p 24023 -1 &
sleep 0.3
iperf3 -s -p 27023 -1 &
sleep 0.3
iperf3 -s -p 28023 -1 &
sleep 0.3
iperf3 -s -p 29023 -1 &
sleep 0.3
iperf3 -s -p 30023 -1 &
sleep 0.3
iperf3 -s -p 31023 -1 &
sleep 0.3
iperf3 -s -p 32023 -1 &
sleep 0.3
iperf3 -s -p 33023 -1 &
sleep 0.3
iperf3 -s -p 34023 -1 &
sleep 0.3
iperf3 -s -p 35023 -1 &
sleep 0.3
iperf3 -s -p 36023 -1 &
sleep 0.3
iperf3 -s -p 38023 -1 &
sleep 0.3
iperf3 -s -p 39023 -1 &
sleep 0.3
iperf3 -s -p 42023 -1 &
sleep 0.3
iperf3 -s -p 43023 -1 &
sleep 0.3
iperf3 -s -p 44023 -1 &
sleep 0.3
iperf3 -s -p 47023 -1 &
sleep 0.3
iperf3 -s -p 48023 -1 &
sleep 0.3