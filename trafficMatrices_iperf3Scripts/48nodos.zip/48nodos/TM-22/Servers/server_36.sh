 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1036 -1 &
sleep 0.3
iperf3 -s -p 2036 -1 &
sleep 0.3
iperf3 -s -p 3036 -1 &
sleep 0.3
iperf3 -s -p 4036 -1 &
sleep 0.3
iperf3 -s -p 5036 -1 &
sleep 0.3
iperf3 -s -p 6036 -1 &
sleep 0.3
iperf3 -s -p 8036 -1 &
sleep 0.3
iperf3 -s -p 9036 -1 &
sleep 0.3
iperf3 -s -p 11036 -1 &
sleep 0.3
iperf3 -s -p 12036 -1 &
sleep 0.3
iperf3 -s -p 16036 -1 &
sleep 0.3
iperf3 -s -p 17036 -1 &
sleep 0.3
iperf3 -s -p 19036 -1 &
sleep 0.3
iperf3 -s -p 24036 -1 &
sleep 0.3
iperf3 -s -p 25036 -1 &
sleep 0.3
iperf3 -s -p 26036 -1 &
sleep 0.3
iperf3 -s -p 29036 -1 &
sleep 0.3
iperf3 -s -p 30036 -1 &
sleep 0.3
iperf3 -s -p 31036 -1 &
sleep 0.3
iperf3 -s -p 32036 -1 &
sleep 0.3
iperf3 -s -p 33036 -1 &
sleep 0.3
iperf3 -s -p 34036 -1 &
sleep 0.3
iperf3 -s -p 38036 -1 &
sleep 0.3
iperf3 -s -p 39036 -1 &
sleep 0.3
iperf3 -s -p 40036 -1 &
sleep 0.3
iperf3 -s -p 41036 -1 &
sleep 0.3
iperf3 -s -p 42036 -1 &
sleep 0.3
iperf3 -s -p 43036 -1 &
sleep 0.3
iperf3 -s -p 44036 -1 &
sleep 0.3
iperf3 -s -p 45036 -1 &
sleep 0.3
iperf3 -s -p 46036 -1 &
sleep 0.3