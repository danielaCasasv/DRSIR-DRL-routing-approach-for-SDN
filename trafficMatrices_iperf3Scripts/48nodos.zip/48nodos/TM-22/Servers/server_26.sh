 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1026 -1 &
sleep 0.3
iperf3 -s -p 2026 -1 &
sleep 0.3
iperf3 -s -p 3026 -1 &
sleep 0.3
iperf3 -s -p 4026 -1 &
sleep 0.3
iperf3 -s -p 5026 -1 &
sleep 0.3
iperf3 -s -p 7026 -1 &
sleep 0.3
iperf3 -s -p 9026 -1 &
sleep 0.3
iperf3 -s -p 10026 -1 &
sleep 0.3
iperf3 -s -p 11026 -1 &
sleep 0.3
iperf3 -s -p 12026 -1 &
sleep 0.3
iperf3 -s -p 13026 -1 &
sleep 0.3
iperf3 -s -p 16026 -1 &
sleep 0.3
iperf3 -s -p 17026 -1 &
sleep 0.3
iperf3 -s -p 19026 -1 &
sleep 0.3
iperf3 -s -p 23026 -1 &
sleep 0.3
iperf3 -s -p 24026 -1 &
sleep 0.3
iperf3 -s -p 25026 -1 &
sleep 0.3
iperf3 -s -p 27026 -1 &
sleep 0.3
iperf3 -s -p 28026 -1 &
sleep 0.3
iperf3 -s -p 29026 -1 &
sleep 0.3
iperf3 -s -p 30026 -1 &
sleep 0.3
iperf3 -s -p 32026 -1 &
sleep 0.3
iperf3 -s -p 35026 -1 &
sleep 0.3
iperf3 -s -p 36026 -1 &
sleep 0.3
iperf3 -s -p 38026 -1 &
sleep 0.3
iperf3 -s -p 39026 -1 &
sleep 0.3
iperf3 -s -p 40026 -1 &
sleep 0.3
iperf3 -s -p 41026 -1 &
sleep 0.3
iperf3 -s -p 43026 -1 &
sleep 0.3
iperf3 -s -p 44026 -1 &
sleep 0.3
iperf3 -s -p 45026 -1 &
sleep 0.3
iperf3 -s -p 47026 -1 &
sleep 0.3
iperf3 -s -p 48026 -1 &
sleep 0.3