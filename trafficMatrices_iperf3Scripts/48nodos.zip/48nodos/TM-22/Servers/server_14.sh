 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1014 -1 &
sleep 0.3
iperf3 -s -p 2014 -1 &
sleep 0.3
iperf3 -s -p 3014 -1 &
sleep 0.3
iperf3 -s -p 6014 -1 &
sleep 0.3
iperf3 -s -p 7014 -1 &
sleep 0.3
iperf3 -s -p 8014 -1 &
sleep 0.3
iperf3 -s -p 9014 -1 &
sleep 0.3
iperf3 -s -p 12014 -1 &
sleep 0.3
iperf3 -s -p 15014 -1 &
sleep 0.3
iperf3 -s -p 16014 -1 &
sleep 0.3
iperf3 -s -p 17014 -1 &
sleep 0.3
iperf3 -s -p 18014 -1 &
sleep 0.3
iperf3 -s -p 19014 -1 &
sleep 0.3
iperf3 -s -p 20014 -1 &
sleep 0.3
iperf3 -s -p 21014 -1 &
sleep 0.3
iperf3 -s -p 22014 -1 &
sleep 0.3
iperf3 -s -p 23014 -1 &
sleep 0.3
iperf3 -s -p 27014 -1 &
sleep 0.3
iperf3 -s -p 30014 -1 &
sleep 0.3
iperf3 -s -p 32014 -1 &
sleep 0.3
iperf3 -s -p 33014 -1 &
sleep 0.3
iperf3 -s -p 34014 -1 &
sleep 0.3
iperf3 -s -p 35014 -1 &
sleep 0.3
iperf3 -s -p 36014 -1 &
sleep 0.3
iperf3 -s -p 38014 -1 &
sleep 0.3
iperf3 -s -p 39014 -1 &
sleep 0.3
iperf3 -s -p 40014 -1 &
sleep 0.3
iperf3 -s -p 41014 -1 &
sleep 0.3
iperf3 -s -p 42014 -1 &
sleep 0.3
iperf3 -s -p 43014 -1 &
sleep 0.3
iperf3 -s -p 44014 -1 &
sleep 0.3
iperf3 -s -p 45014 -1 &
sleep 0.3
iperf3 -s -p 46014 -1 &
sleep 0.3
iperf3 -s -p 47014 -1 &
sleep 0.3