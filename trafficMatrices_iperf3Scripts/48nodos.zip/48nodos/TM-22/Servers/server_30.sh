 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1030 -1 &
sleep 0.3
iperf3 -s -p 2030 -1 &
sleep 0.3
iperf3 -s -p 4030 -1 &
sleep 0.3
iperf3 -s -p 7030 -1 &
sleep 0.3
iperf3 -s -p 9030 -1 &
sleep 0.3
iperf3 -s -p 10030 -1 &
sleep 0.3
iperf3 -s -p 11030 -1 &
sleep 0.3
iperf3 -s -p 12030 -1 &
sleep 0.3
iperf3 -s -p 13030 -1 &
sleep 0.3
iperf3 -s -p 14030 -1 &
sleep 0.3
iperf3 -s -p 15030 -1 &
sleep 0.3
iperf3 -s -p 16030 -1 &
sleep 0.3
iperf3 -s -p 17030 -1 &
sleep 0.3
iperf3 -s -p 20030 -1 &
sleep 0.3
iperf3 -s -p 21030 -1 &
sleep 0.3
iperf3 -s -p 22030 -1 &
sleep 0.3
iperf3 -s -p 23030 -1 &
sleep 0.3
iperf3 -s -p 24030 -1 &
sleep 0.3
iperf3 -s -p 25030 -1 &
sleep 0.3
iperf3 -s -p 26030 -1 &
sleep 0.3
iperf3 -s -p 28030 -1 &
sleep 0.3
iperf3 -s -p 29030 -1 &
sleep 0.3
iperf3 -s -p 31030 -1 &
sleep 0.3
iperf3 -s -p 32030 -1 &
sleep 0.3
iperf3 -s -p 33030 -1 &
sleep 0.3
iperf3 -s -p 34030 -1 &
sleep 0.3
iperf3 -s -p 35030 -1 &
sleep 0.3
iperf3 -s -p 36030 -1 &
sleep 0.3
iperf3 -s -p 38030 -1 &
sleep 0.3
iperf3 -s -p 40030 -1 &
sleep 0.3
iperf3 -s -p 41030 -1 &
sleep 0.3
iperf3 -s -p 43030 -1 &
sleep 0.3
iperf3 -s -p 44030 -1 &
sleep 0.3
iperf3 -s -p 45030 -1 &
sleep 0.3
iperf3 -s -p 46030 -1 &
sleep 0.3
iperf3 -s -p 47030 -1 &
sleep 0.3
iperf3 -s -p 48030 -1 &
sleep 0.3