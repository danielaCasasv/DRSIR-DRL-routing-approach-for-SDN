 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1031 -1 &
sleep 0.3
iperf3 -s -p 2031 -1 &
sleep 0.3
iperf3 -s -p 3031 -1 &
sleep 0.3
iperf3 -s -p 4031 -1 &
sleep 0.3
iperf3 -s -p 5031 -1 &
sleep 0.3
iperf3 -s -p 6031 -1 &
sleep 0.3
iperf3 -s -p 9031 -1 &
sleep 0.3
iperf3 -s -p 11031 -1 &
sleep 0.3
iperf3 -s -p 12031 -1 &
sleep 0.3
iperf3 -s -p 13031 -1 &
sleep 0.3
iperf3 -s -p 14031 -1 &
sleep 0.3
iperf3 -s -p 16031 -1 &
sleep 0.3
iperf3 -s -p 18031 -1 &
sleep 0.3
iperf3 -s -p 21031 -1 &
sleep 0.3
iperf3 -s -p 22031 -1 &
sleep 0.3
iperf3 -s -p 24031 -1 &
sleep 0.3
iperf3 -s -p 26031 -1 &
sleep 0.3
iperf3 -s -p 28031 -1 &
sleep 0.3
iperf3 -s -p 32031 -1 &
sleep 0.3
iperf3 -s -p 35031 -1 &
sleep 0.3
iperf3 -s -p 36031 -1 &
sleep 0.3
iperf3 -s -p 37031 -1 &
sleep 0.3
iperf3 -s -p 39031 -1 &
sleep 0.3
iperf3 -s -p 41031 -1 &
sleep 0.3
iperf3 -s -p 42031 -1 &
sleep 0.3
iperf3 -s -p 44031 -1 &
sleep 0.3
iperf3 -s -p 45031 -1 &
sleep 0.3
iperf3 -s -p 46031 -1 &
sleep 0.3
iperf3 -s -p 47031 -1 &
sleep 0.3