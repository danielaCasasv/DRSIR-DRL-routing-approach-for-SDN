 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1032 -1 &
sleep 0.3
iperf3 -s -p 3032 -1 &
sleep 0.3
iperf3 -s -p 4032 -1 &
sleep 0.3
iperf3 -s -p 6032 -1 &
sleep 0.3
iperf3 -s -p 10032 -1 &
sleep 0.3
iperf3 -s -p 11032 -1 &
sleep 0.3
iperf3 -s -p 13032 -1 &
sleep 0.3
iperf3 -s -p 14032 -1 &
sleep 0.3
iperf3 -s -p 16032 -1 &
sleep 0.3
iperf3 -s -p 17032 -1 &
sleep 0.3
iperf3 -s -p 19032 -1 &
sleep 0.3
iperf3 -s -p 20032 -1 &
sleep 0.3
iperf3 -s -p 21032 -1 &
sleep 0.3
iperf3 -s -p 23032 -1 &
sleep 0.3
iperf3 -s -p 24032 -1 &
sleep 0.3
iperf3 -s -p 25032 -1 &
sleep 0.3
iperf3 -s -p 27032 -1 &
sleep 0.3
iperf3 -s -p 28032 -1 &
sleep 0.3
iperf3 -s -p 29032 -1 &
sleep 0.3
iperf3 -s -p 34032 -1 &
sleep 0.3
iperf3 -s -p 35032 -1 &
sleep 0.3
iperf3 -s -p 36032 -1 &
sleep 0.3
iperf3 -s -p 37032 -1 &
sleep 0.3
iperf3 -s -p 38032 -1 &
sleep 0.3
iperf3 -s -p 40032 -1 &
sleep 0.3
iperf3 -s -p 42032 -1 &
sleep 0.3
iperf3 -s -p 44032 -1 &
sleep 0.3
iperf3 -s -p 45032 -1 &
sleep 0.3
iperf3 -s -p 47032 -1 &
sleep 0.3
iperf3 -s -p 48032 -1 &
sleep 0.3