 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 2041 -1 &
sleep 0.3
iperf3 -s -p 4041 -1 &
sleep 0.3
iperf3 -s -p 5041 -1 &
sleep 0.3
iperf3 -s -p 6041 -1 &
sleep 0.3
iperf3 -s -p 7041 -1 &
sleep 0.3
iperf3 -s -p 9041 -1 &
sleep 0.3
iperf3 -s -p 10041 -1 &
sleep 0.3
iperf3 -s -p 11041 -1 &
sleep 0.3
iperf3 -s -p 13041 -1 &
sleep 0.3
iperf3 -s -p 14041 -1 &
sleep 0.3
iperf3 -s -p 17041 -1 &
sleep 0.3
iperf3 -s -p 18041 -1 &
sleep 0.3
iperf3 -s -p 19041 -1 &
sleep 0.3
iperf3 -s -p 20041 -1 &
sleep 0.3
iperf3 -s -p 21041 -1 &
sleep 0.3
iperf3 -s -p 23041 -1 &
sleep 0.3
iperf3 -s -p 27041 -1 &
sleep 0.3
iperf3 -s -p 29041 -1 &
sleep 0.3
iperf3 -s -p 30041 -1 &
sleep 0.3
iperf3 -s -p 31041 -1 &
sleep 0.3
iperf3 -s -p 32041 -1 &
sleep 0.3
iperf3 -s -p 33041 -1 &
sleep 0.3
iperf3 -s -p 34041 -1 &
sleep 0.3
iperf3 -s -p 35041 -1 &
sleep 0.3
iperf3 -s -p 36041 -1 &
sleep 0.3
iperf3 -s -p 38041 -1 &
sleep 0.3
iperf3 -s -p 39041 -1 &
sleep 0.3
iperf3 -s -p 40041 -1 &
sleep 0.3
iperf3 -s -p 42041 -1 &
sleep 0.3
iperf3 -s -p 45041 -1 &
sleep 0.3
iperf3 -s -p 46041 -1 &
sleep 0.3
iperf3 -s -p 47041 -1 &
sleep 0.3
iperf3 -s -p 48041 -1 &
sleep 0.3