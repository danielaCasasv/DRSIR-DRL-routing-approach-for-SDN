 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 2027 -1 &
sleep 0.3
iperf3 -s -p 3027 -1 &
sleep 0.3
iperf3 -s -p 5027 -1 &
sleep 0.3
iperf3 -s -p 7027 -1 &
sleep 0.3
iperf3 -s -p 10027 -1 &
sleep 0.3
iperf3 -s -p 11027 -1 &
sleep 0.3
iperf3 -s -p 12027 -1 &
sleep 0.3
iperf3 -s -p 13027 -1 &
sleep 0.3
iperf3 -s -p 14027 -1 &
sleep 0.3
iperf3 -s -p 15027 -1 &
sleep 0.3
iperf3 -s -p 16027 -1 &
sleep 0.3
iperf3 -s -p 17027 -1 &
sleep 0.3
iperf3 -s -p 19027 -1 &
sleep 0.3
iperf3 -s -p 20027 -1 &
sleep 0.3
iperf3 -s -p 21027 -1 &
sleep 0.3
iperf3 -s -p 22027 -1 &
sleep 0.3
iperf3 -s -p 23027 -1 &
sleep 0.3
iperf3 -s -p 24027 -1 &
sleep 0.3
iperf3 -s -p 25027 -1 &
sleep 0.3
iperf3 -s -p 28027 -1 &
sleep 0.3
iperf3 -s -p 30027 -1 &
sleep 0.3
iperf3 -s -p 31027 -1 &
sleep 0.3
iperf3 -s -p 32027 -1 &
sleep 0.3
iperf3 -s -p 33027 -1 &
sleep 0.3
iperf3 -s -p 34027 -1 &
sleep 0.3
iperf3 -s -p 35027 -1 &
sleep 0.3
iperf3 -s -p 36027 -1 &
sleep 0.3
iperf3 -s -p 37027 -1 &
sleep 0.3
iperf3 -s -p 40027 -1 &
sleep 0.3
iperf3 -s -p 41027 -1 &
sleep 0.3
iperf3 -s -p 43027 -1 &
sleep 0.3
iperf3 -s -p 45027 -1 &
sleep 0.3
iperf3 -s -p 46027 -1 &
sleep 0.3
iperf3 -s -p 47027 -1 &
sleep 0.3
iperf3 -s -p 48027 -1 &
sleep 0.3