 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1019 -1 &
sleep 0.3
iperf3 -s -p 2019 -1 &
sleep 0.3
iperf3 -s -p 5019 -1 &
sleep 0.3
iperf3 -s -p 6019 -1 &
sleep 0.3
iperf3 -s -p 8019 -1 &
sleep 0.3
iperf3 -s -p 10019 -1 &
sleep 0.3
iperf3 -s -p 11019 -1 &
sleep 0.3
iperf3 -s -p 13019 -1 &
sleep 0.3
iperf3 -s -p 14019 -1 &
sleep 0.3
iperf3 -s -p 15019 -1 &
sleep 0.3
iperf3 -s -p 17019 -1 &
sleep 0.3
iperf3 -s -p 21019 -1 &
sleep 0.3
iperf3 -s -p 22019 -1 &
sleep 0.3
iperf3 -s -p 23019 -1 &
sleep 0.3
iperf3 -s -p 25019 -1 &
sleep 0.3
iperf3 -s -p 27019 -1 &
sleep 0.3
iperf3 -s -p 28019 -1 &
sleep 0.3
iperf3 -s -p 31019 -1 &
sleep 0.3
iperf3 -s -p 34019 -1 &
sleep 0.3
iperf3 -s -p 35019 -1 &
sleep 0.3
iperf3 -s -p 37019 -1 &
sleep 0.3
iperf3 -s -p 40019 -1 &
sleep 0.3
iperf3 -s -p 42019 -1 &
sleep 0.3
iperf3 -s -p 43019 -1 &
sleep 0.3
iperf3 -s -p 44019 -1 &
sleep 0.3
iperf3 -s -p 45019 -1 &
sleep 0.3
iperf3 -s -p 46019 -1 &
sleep 0.3
iperf3 -s -p 48019 -1 &
sleep 0.3