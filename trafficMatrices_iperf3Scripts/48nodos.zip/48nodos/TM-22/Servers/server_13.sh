 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1013 -1 &
sleep 0.3
iperf3 -s -p 2013 -1 &
sleep 0.3
iperf3 -s -p 3013 -1 &
sleep 0.3
iperf3 -s -p 4013 -1 &
sleep 0.3
iperf3 -s -p 5013 -1 &
sleep 0.3
iperf3 -s -p 7013 -1 &
sleep 0.3
iperf3 -s -p 8013 -1 &
sleep 0.3
iperf3 -s -p 9013 -1 &
sleep 0.3
iperf3 -s -p 10013 -1 &
sleep 0.3
iperf3 -s -p 11013 -1 &
sleep 0.3
iperf3 -s -p 12013 -1 &
sleep 0.3
iperf3 -s -p 14013 -1 &
sleep 0.3
iperf3 -s -p 16013 -1 &
sleep 0.3
iperf3 -s -p 17013 -1 &
sleep 0.3
iperf3 -s -p 18013 -1 &
sleep 0.3
iperf3 -s -p 19013 -1 &
sleep 0.3
iperf3 -s -p 20013 -1 &
sleep 0.3
iperf3 -s -p 21013 -1 &
sleep 0.3
iperf3 -s -p 23013 -1 &
sleep 0.3
iperf3 -s -p 25013 -1 &
sleep 0.3
iperf3 -s -p 27013 -1 &
sleep 0.3
iperf3 -s -p 28013 -1 &
sleep 0.3
iperf3 -s -p 29013 -1 &
sleep 0.3
iperf3 -s -p 31013 -1 &
sleep 0.3
iperf3 -s -p 32013 -1 &
sleep 0.3
iperf3 -s -p 33013 -1 &
sleep 0.3
iperf3 -s -p 37013 -1 &
sleep 0.3
iperf3 -s -p 38013 -1 &
sleep 0.3
iperf3 -s -p 39013 -1 &
sleep 0.3
iperf3 -s -p 40013 -1 &
sleep 0.3
iperf3 -s -p 42013 -1 &
sleep 0.3
iperf3 -s -p 43013 -1 &
sleep 0.3
iperf3 -s -p 47013 -1 &
sleep 0.3