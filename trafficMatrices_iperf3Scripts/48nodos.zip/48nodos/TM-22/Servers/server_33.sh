 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1033 -1 &
sleep 0.3
iperf3 -s -p 4033 -1 &
sleep 0.3
iperf3 -s -p 8033 -1 &
sleep 0.3
iperf3 -s -p 9033 -1 &
sleep 0.3
iperf3 -s -p 10033 -1 &
sleep 0.3
iperf3 -s -p 11033 -1 &
sleep 0.3
iperf3 -s -p 12033 -1 &
sleep 0.3
iperf3 -s -p 13033 -1 &
sleep 0.3
iperf3 -s -p 14033 -1 &
sleep 0.3
iperf3 -s -p 15033 -1 &
sleep 0.3
iperf3 -s -p 16033 -1 &
sleep 0.3
iperf3 -s -p 17033 -1 &
sleep 0.3
iperf3 -s -p 18033 -1 &
sleep 0.3
iperf3 -s -p 19033 -1 &
sleep 0.3
iperf3 -s -p 21033 -1 &
sleep 0.3
iperf3 -s -p 22033 -1 &
sleep 0.3
iperf3 -s -p 23033 -1 &
sleep 0.3
iperf3 -s -p 24033 -1 &
sleep 0.3
iperf3 -s -p 25033 -1 &
sleep 0.3
iperf3 -s -p 27033 -1 &
sleep 0.3
iperf3 -s -p 30033 -1 &
sleep 0.3
iperf3 -s -p 34033 -1 &
sleep 0.3
iperf3 -s -p 36033 -1 &
sleep 0.3
iperf3 -s -p 37033 -1 &
sleep 0.3
iperf3 -s -p 38033 -1 &
sleep 0.3
iperf3 -s -p 39033 -1 &
sleep 0.3
iperf3 -s -p 41033 -1 &
sleep 0.3
iperf3 -s -p 43033 -1 &
sleep 0.3
iperf3 -s -p 44033 -1 &
sleep 0.3
iperf3 -s -p 46033 -1 &
sleep 0.3
iperf3 -s -p 47033 -1 &
sleep 0.3
iperf3 -s -p 48033 -1 &
sleep 0.3