 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 2001 -1 &
sleep 0.3
iperf3 -s -p 3001 -1 &
sleep 0.3
iperf3 -s -p 4001 -1 &
sleep 0.3
iperf3 -s -p 5001 -1 &
sleep 0.3
iperf3 -s -p 7001 -1 &
sleep 0.3
iperf3 -s -p 9001 -1 &
sleep 0.3
iperf3 -s -p 10001 -1 &
sleep 0.3
iperf3 -s -p 11001 -1 &
sleep 0.3
iperf3 -s -p 13001 -1 &
sleep 0.3
iperf3 -s -p 15001 -1 &
sleep 0.3
iperf3 -s -p 16001 -1 &
sleep 0.3
iperf3 -s -p 17001 -1 &
sleep 0.3
iperf3 -s -p 19001 -1 &
sleep 0.3
iperf3 -s -p 20001 -1 &
sleep 0.3
iperf3 -s -p 21001 -1 &
sleep 0.3
iperf3 -s -p 24001 -1 &
sleep 0.3
iperf3 -s -p 26001 -1 &
sleep 0.3
iperf3 -s -p 27001 -1 &
sleep 0.3
iperf3 -s -p 28001 -1 &
sleep 0.3
iperf3 -s -p 30001 -1 &
sleep 0.3
iperf3 -s -p 32001 -1 &
sleep 0.3
iperf3 -s -p 33001 -1 &
sleep 0.3
iperf3 -s -p 34001 -1 &
sleep 0.3
iperf3 -s -p 35001 -1 &
sleep 0.3
iperf3 -s -p 36001 -1 &
sleep 0.3
iperf3 -s -p 37001 -1 &
sleep 0.3
iperf3 -s -p 39001 -1 &
sleep 0.3
iperf3 -s -p 40001 -1 &
sleep 0.3
iperf3 -s -p 41001 -1 &
sleep 0.3
iperf3 -s -p 42001 -1 &
sleep 0.3
iperf3 -s -p 43001 -1 &
sleep 0.3
iperf3 -s -p 44001 -1 &
sleep 0.3
iperf3 -s -p 46001 -1 &
sleep 0.3
iperf3 -s -p 47001 -1 &
sleep 0.3
iperf3 -s -p 48001 -1 &
sleep 0.3