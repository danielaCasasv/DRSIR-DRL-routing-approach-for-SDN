 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 2042 -1 &
sleep 0.3
iperf3 -s -p 3042 -1 &
sleep 0.3
iperf3 -s -p 5042 -1 &
sleep 0.3
iperf3 -s -p 6042 -1 &
sleep 0.3
iperf3 -s -p 8042 -1 &
sleep 0.3
iperf3 -s -p 10042 -1 &
sleep 0.3
iperf3 -s -p 11042 -1 &
sleep 0.3
iperf3 -s -p 14042 -1 &
sleep 0.3
iperf3 -s -p 15042 -1 &
sleep 0.3
iperf3 -s -p 16042 -1 &
sleep 0.3
iperf3 -s -p 17042 -1 &
sleep 0.3
iperf3 -s -p 19042 -1 &
sleep 0.3
iperf3 -s -p 21042 -1 &
sleep 0.3
iperf3 -s -p 22042 -1 &
sleep 0.3
iperf3 -s -p 23042 -1 &
sleep 0.3
iperf3 -s -p 24042 -1 &
sleep 0.3
iperf3 -s -p 27042 -1 &
sleep 0.3
iperf3 -s -p 28042 -1 &
sleep 0.3
iperf3 -s -p 30042 -1 &
sleep 0.3
iperf3 -s -p 31042 -1 &
sleep 0.3
iperf3 -s -p 34042 -1 &
sleep 0.3
iperf3 -s -p 36042 -1 &
sleep 0.3
iperf3 -s -p 37042 -1 &
sleep 0.3
iperf3 -s -p 38042 -1 &
sleep 0.3
iperf3 -s -p 39042 -1 &
sleep 0.3
iperf3 -s -p 40042 -1 &
sleep 0.3
iperf3 -s -p 41042 -1 &
sleep 0.3
iperf3 -s -p 43042 -1 &
sleep 0.3
iperf3 -s -p 44042 -1 &
sleep 0.3
iperf3 -s -p 45042 -1 &
sleep 0.3