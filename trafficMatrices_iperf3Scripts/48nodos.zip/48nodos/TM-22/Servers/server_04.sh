 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1004 -1 &
sleep 0.3
iperf3 -s -p 5004 -1 &
sleep 0.3
iperf3 -s -p 6004 -1 &
sleep 0.3
iperf3 -s -p 7004 -1 &
sleep 0.3
iperf3 -s -p 8004 -1 &
sleep 0.3
iperf3 -s -p 9004 -1 &
sleep 0.3
iperf3 -s -p 10004 -1 &
sleep 0.3
iperf3 -s -p 11004 -1 &
sleep 0.3
iperf3 -s -p 12004 -1 &
sleep 0.3
iperf3 -s -p 17004 -1 &
sleep 0.3
iperf3 -s -p 18004 -1 &
sleep 0.3
iperf3 -s -p 20004 -1 &
sleep 0.3
iperf3 -s -p 21004 -1 &
sleep 0.3
iperf3 -s -p 24004 -1 &
sleep 0.3
iperf3 -s -p 27004 -1 &
sleep 0.3
iperf3 -s -p 28004 -1 &
sleep 0.3
iperf3 -s -p 29004 -1 &
sleep 0.3
iperf3 -s -p 32004 -1 &
sleep 0.3
iperf3 -s -p 33004 -1 &
sleep 0.3
iperf3 -s -p 34004 -1 &
sleep 0.3
iperf3 -s -p 36004 -1 &
sleep 0.3
iperf3 -s -p 37004 -1 &
sleep 0.3
iperf3 -s -p 38004 -1 &
sleep 0.3
iperf3 -s -p 39004 -1 &
sleep 0.3
iperf3 -s -p 41004 -1 &
sleep 0.3
iperf3 -s -p 43004 -1 &
sleep 0.3
iperf3 -s -p 45004 -1 &
sleep 0.3
iperf3 -s -p 47004 -1 &
sleep 0.3
iperf3 -s -p 48004 -1 &
sleep 0.3