 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1009 -1 &
sleep 0.3
iperf3 -s -p 3009 -1 &
sleep 0.3
iperf3 -s -p 4009 -1 &
sleep 0.3
iperf3 -s -p 5009 -1 &
sleep 0.3
iperf3 -s -p 6009 -1 &
sleep 0.3
iperf3 -s -p 7009 -1 &
sleep 0.3
iperf3 -s -p 10009 -1 &
sleep 0.3
iperf3 -s -p 11009 -1 &
sleep 0.3
iperf3 -s -p 12009 -1 &
sleep 0.3
iperf3 -s -p 13009 -1 &
sleep 0.3
iperf3 -s -p 14009 -1 &
sleep 0.3
iperf3 -s -p 15009 -1 &
sleep 0.3
iperf3 -s -p 18009 -1 &
sleep 0.3
iperf3 -s -p 21009 -1 &
sleep 0.3
iperf3 -s -p 22009 -1 &
sleep 0.3
iperf3 -s -p 23009 -1 &
sleep 0.3
iperf3 -s -p 24009 -1 &
sleep 0.3
iperf3 -s -p 25009 -1 &
sleep 0.3
iperf3 -s -p 28009 -1 &
sleep 0.3
iperf3 -s -p 29009 -1 &
sleep 0.3
iperf3 -s -p 31009 -1 &
sleep 0.3
iperf3 -s -p 33009 -1 &
sleep 0.3
iperf3 -s -p 34009 -1 &
sleep 0.3
iperf3 -s -p 37009 -1 &
sleep 0.3
iperf3 -s -p 38009 -1 &
sleep 0.3
iperf3 -s -p 40009 -1 &
sleep 0.3
iperf3 -s -p 42009 -1 &
sleep 0.3
iperf3 -s -p 46009 -1 &
sleep 0.3
iperf3 -s -p 48009 -1 &
sleep 0.3