 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1040 -1 &
sleep 0.3
iperf3 -s -p 3040 -1 &
sleep 0.3
iperf3 -s -p 4040 -1 &
sleep 0.3
iperf3 -s -p 5040 -1 &
sleep 0.3
iperf3 -s -p 7040 -1 &
sleep 0.3
iperf3 -s -p 8040 -1 &
sleep 0.3
iperf3 -s -p 9040 -1 &
sleep 0.3
iperf3 -s -p 10040 -1 &
sleep 0.3
iperf3 -s -p 12040 -1 &
sleep 0.3
iperf3 -s -p 13040 -1 &
sleep 0.3
iperf3 -s -p 14040 -1 &
sleep 0.3
iperf3 -s -p 16040 -1 &
sleep 0.3
iperf3 -s -p 18040 -1 &
sleep 0.3
iperf3 -s -p 20040 -1 &
sleep 0.3
iperf3 -s -p 21040 -1 &
sleep 0.3
iperf3 -s -p 22040 -1 &
sleep 0.3
iperf3 -s -p 24040 -1 &
sleep 0.3
iperf3 -s -p 25040 -1 &
sleep 0.3
iperf3 -s -p 27040 -1 &
sleep 0.3
iperf3 -s -p 28040 -1 &
sleep 0.3
iperf3 -s -p 29040 -1 &
sleep 0.3
iperf3 -s -p 30040 -1 &
sleep 0.3
iperf3 -s -p 31040 -1 &
sleep 0.3
iperf3 -s -p 32040 -1 &
sleep 0.3
iperf3 -s -p 34040 -1 &
sleep 0.3
iperf3 -s -p 36040 -1 &
sleep 0.3
iperf3 -s -p 37040 -1 &
sleep 0.3
iperf3 -s -p 39040 -1 &
sleep 0.3
iperf3 -s -p 41040 -1 &
sleep 0.3
iperf3 -s -p 43040 -1 &
sleep 0.3
iperf3 -s -p 44040 -1 &
sleep 0.3
iperf3 -s -p 46040 -1 &
sleep 0.3
iperf3 -s -p 47040 -1 &
sleep 0.3