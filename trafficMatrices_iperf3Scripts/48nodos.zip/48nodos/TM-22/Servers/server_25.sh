 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 2025 -1 &
sleep 0.3
iperf3 -s -p 4025 -1 &
sleep 0.3
iperf3 -s -p 5025 -1 &
sleep 0.3
iperf3 -s -p 7025 -1 &
sleep 0.3
iperf3 -s -p 10025 -1 &
sleep 0.3
iperf3 -s -p 12025 -1 &
sleep 0.3
iperf3 -s -p 13025 -1 &
sleep 0.3
iperf3 -s -p 14025 -1 &
sleep 0.3
iperf3 -s -p 15025 -1 &
sleep 0.3
iperf3 -s -p 17025 -1 &
sleep 0.3
iperf3 -s -p 18025 -1 &
sleep 0.3
iperf3 -s -p 19025 -1 &
sleep 0.3
iperf3 -s -p 20025 -1 &
sleep 0.3
iperf3 -s -p 21025 -1 &
sleep 0.3
iperf3 -s -p 22025 -1 &
sleep 0.3
iperf3 -s -p 24025 -1 &
sleep 0.3
iperf3 -s -p 27025 -1 &
sleep 0.3
iperf3 -s -p 28025 -1 &
sleep 0.3
iperf3 -s -p 29025 -1 &
sleep 0.3
iperf3 -s -p 30025 -1 &
sleep 0.3
iperf3 -s -p 32025 -1 &
sleep 0.3
iperf3 -s -p 33025 -1 &
sleep 0.3
iperf3 -s -p 34025 -1 &
sleep 0.3
iperf3 -s -p 35025 -1 &
sleep 0.3
iperf3 -s -p 36025 -1 &
sleep 0.3
iperf3 -s -p 37025 -1 &
sleep 0.3
iperf3 -s -p 40025 -1 &
sleep 0.3
iperf3 -s -p 41025 -1 &
sleep 0.3
iperf3 -s -p 43025 -1 &
sleep 0.3
iperf3 -s -p 44025 -1 &
sleep 0.3
iperf3 -s -p 45025 -1 &
sleep 0.3
iperf3 -s -p 47025 -1 &
sleep 0.3
iperf3 -s -p 48025 -1 &
sleep 0.3