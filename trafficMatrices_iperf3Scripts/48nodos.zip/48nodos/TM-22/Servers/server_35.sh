 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 4035 -1 &
sleep 0.3
iperf3 -s -p 5035 -1 &
sleep 0.3
iperf3 -s -p 8035 -1 &
sleep 0.3
iperf3 -s -p 9035 -1 &
sleep 0.3
iperf3 -s -p 12035 -1 &
sleep 0.3
iperf3 -s -p 13035 -1 &
sleep 0.3
iperf3 -s -p 14035 -1 &
sleep 0.3
iperf3 -s -p 15035 -1 &
sleep 0.3
iperf3 -s -p 16035 -1 &
sleep 0.3
iperf3 -s -p 18035 -1 &
sleep 0.3
iperf3 -s -p 19035 -1 &
sleep 0.3
iperf3 -s -p 20035 -1 &
sleep 0.3
iperf3 -s -p 22035 -1 &
sleep 0.3
iperf3 -s -p 23035 -1 &
sleep 0.3
iperf3 -s -p 24035 -1 &
sleep 0.3
iperf3 -s -p 26035 -1 &
sleep 0.3
iperf3 -s -p 27035 -1 &
sleep 0.3
iperf3 -s -p 28035 -1 &
sleep 0.3
iperf3 -s -p 29035 -1 &
sleep 0.3
iperf3 -s -p 31035 -1 &
sleep 0.3
iperf3 -s -p 32035 -1 &
sleep 0.3
iperf3 -s -p 36035 -1 &
sleep 0.3
iperf3 -s -p 37035 -1 &
sleep 0.3
iperf3 -s -p 38035 -1 &
sleep 0.3
iperf3 -s -p 42035 -1 &
sleep 0.3
iperf3 -s -p 43035 -1 &
sleep 0.3
iperf3 -s -p 44035 -1 &
sleep 0.3
iperf3 -s -p 45035 -1 &
sleep 0.3
iperf3 -s -p 46035 -1 &
sleep 0.3
iperf3 -s -p 48035 -1 &
sleep 0.3