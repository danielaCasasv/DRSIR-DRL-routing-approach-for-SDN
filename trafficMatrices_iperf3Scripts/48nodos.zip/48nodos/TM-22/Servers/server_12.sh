 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 2012 -1 &
sleep 0.3
iperf3 -s -p 5012 -1 &
sleep 0.3
iperf3 -s -p 6012 -1 &
sleep 0.3
iperf3 -s -p 7012 -1 &
sleep 0.3
iperf3 -s -p 9012 -1 &
sleep 0.3
iperf3 -s -p 10012 -1 &
sleep 0.3
iperf3 -s -p 11012 -1 &
sleep 0.3
iperf3 -s -p 13012 -1 &
sleep 0.3
iperf3 -s -p 14012 -1 &
sleep 0.3
iperf3 -s -p 15012 -1 &
sleep 0.3
iperf3 -s -p 16012 -1 &
sleep 0.3
iperf3 -s -p 17012 -1 &
sleep 0.3
iperf3 -s -p 19012 -1 &
sleep 0.3
iperf3 -s -p 20012 -1 &
sleep 0.3
iperf3 -s -p 21012 -1 &
sleep 0.3
iperf3 -s -p 22012 -1 &
sleep 0.3
iperf3 -s -p 24012 -1 &
sleep 0.3
iperf3 -s -p 25012 -1 &
sleep 0.3
iperf3 -s -p 26012 -1 &
sleep 0.3
iperf3 -s -p 27012 -1 &
sleep 0.3
iperf3 -s -p 28012 -1 &
sleep 0.3
iperf3 -s -p 29012 -1 &
sleep 0.3
iperf3 -s -p 30012 -1 &
sleep 0.3
iperf3 -s -p 31012 -1 &
sleep 0.3
iperf3 -s -p 33012 -1 &
sleep 0.3
iperf3 -s -p 35012 -1 &
sleep 0.3
iperf3 -s -p 37012 -1 &
sleep 0.3
iperf3 -s -p 38012 -1 &
sleep 0.3
iperf3 -s -p 39012 -1 &
sleep 0.3
iperf3 -s -p 40012 -1 &
sleep 0.3
iperf3 -s -p 42012 -1 &
sleep 0.3
iperf3 -s -p 43012 -1 &
sleep 0.3
iperf3 -s -p 45012 -1 &
sleep 0.3
iperf3 -s -p 46012 -1 &
sleep 0.3
iperf3 -s -p 47012 -1 &
sleep 0.3