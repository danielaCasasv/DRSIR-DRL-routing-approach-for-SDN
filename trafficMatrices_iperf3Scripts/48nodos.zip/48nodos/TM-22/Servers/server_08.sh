 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1008 -1 &
sleep 0.3
iperf3 -s -p 3008 -1 &
sleep 0.3
iperf3 -s -p 5008 -1 &
sleep 0.3
iperf3 -s -p 7008 -1 &
sleep 0.3
iperf3 -s -p 9008 -1 &
sleep 0.3
iperf3 -s -p 10008 -1 &
sleep 0.3
iperf3 -s -p 11008 -1 &
sleep 0.3
iperf3 -s -p 12008 -1 &
sleep 0.3
iperf3 -s -p 13008 -1 &
sleep 0.3
iperf3 -s -p 15008 -1 &
sleep 0.3
iperf3 -s -p 16008 -1 &
sleep 0.3
iperf3 -s -p 18008 -1 &
sleep 0.3
iperf3 -s -p 19008 -1 &
sleep 0.3
iperf3 -s -p 21008 -1 &
sleep 0.3
iperf3 -s -p 22008 -1 &
sleep 0.3
iperf3 -s -p 24008 -1 &
sleep 0.3
iperf3 -s -p 26008 -1 &
sleep 0.3
iperf3 -s -p 27008 -1 &
sleep 0.3
iperf3 -s -p 28008 -1 &
sleep 0.3
iperf3 -s -p 29008 -1 &
sleep 0.3
iperf3 -s -p 30008 -1 &
sleep 0.3
iperf3 -s -p 32008 -1 &
sleep 0.3
iperf3 -s -p 33008 -1 &
sleep 0.3
iperf3 -s -p 36008 -1 &
sleep 0.3
iperf3 -s -p 37008 -1 &
sleep 0.3
iperf3 -s -p 38008 -1 &
sleep 0.3
iperf3 -s -p 39008 -1 &
sleep 0.3
iperf3 -s -p 40008 -1 &
sleep 0.3
iperf3 -s -p 41008 -1 &
sleep 0.3
iperf3 -s -p 42008 -1 &
sleep 0.3
iperf3 -s -p 44008 -1 &
sleep 0.3
iperf3 -s -p 45008 -1 &
sleep 0.3
iperf3 -s -p 46008 -1 &
sleep 0.3
iperf3 -s -p 47008 -1 &
sleep 0.3