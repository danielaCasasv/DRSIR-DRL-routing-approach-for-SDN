 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1005 -1 &
sleep 0.3
iperf3 -s -p 2005 -1 &
sleep 0.3
iperf3 -s -p 3005 -1 &
sleep 0.3
iperf3 -s -p 4005 -1 &
sleep 0.3
iperf3 -s -p 6005 -1 &
sleep 0.3
iperf3 -s -p 8005 -1 &
sleep 0.3
iperf3 -s -p 10005 -1 &
sleep 0.3
iperf3 -s -p 11005 -1 &
sleep 0.3
iperf3 -s -p 12005 -1 &
sleep 0.3
iperf3 -s -p 13005 -1 &
sleep 0.3
iperf3 -s -p 14005 -1 &
sleep 0.3
iperf3 -s -p 16005 -1 &
sleep 0.3
iperf3 -s -p 17005 -1 &
sleep 0.3
iperf3 -s -p 18005 -1 &
sleep 0.3
iperf3 -s -p 19005 -1 &
sleep 0.3
iperf3 -s -p 20005 -1 &
sleep 0.3
iperf3 -s -p 21005 -1 &
sleep 0.3
iperf3 -s -p 22005 -1 &
sleep 0.3
iperf3 -s -p 23005 -1 &
sleep 0.3
iperf3 -s -p 24005 -1 &
sleep 0.3
iperf3 -s -p 25005 -1 &
sleep 0.3
iperf3 -s -p 26005 -1 &
sleep 0.3
iperf3 -s -p 28005 -1 &
sleep 0.3
iperf3 -s -p 29005 -1 &
sleep 0.3
iperf3 -s -p 30005 -1 &
sleep 0.3
iperf3 -s -p 31005 -1 &
sleep 0.3
iperf3 -s -p 33005 -1 &
sleep 0.3
iperf3 -s -p 35005 -1 &
sleep 0.3
iperf3 -s -p 36005 -1 &
sleep 0.3
iperf3 -s -p 38005 -1 &
sleep 0.3
iperf3 -s -p 39005 -1 &
sleep 0.3
iperf3 -s -p 40005 -1 &
sleep 0.3
iperf3 -s -p 41005 -1 &
sleep 0.3
iperf3 -s -p 42005 -1 &
sleep 0.3
iperf3 -s -p 43005 -1 &
sleep 0.3
iperf3 -s -p 44005 -1 &
sleep 0.3
iperf3 -s -p 47005 -1 &
sleep 0.3