 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1029 -1 &
sleep 0.3
iperf3 -s -p 2029 -1 &
sleep 0.3
iperf3 -s -p 3029 -1 &
sleep 0.3
iperf3 -s -p 4029 -1 &
sleep 0.3
iperf3 -s -p 5029 -1 &
sleep 0.3
iperf3 -s -p 7029 -1 &
sleep 0.3
iperf3 -s -p 8029 -1 &
sleep 0.3
iperf3 -s -p 9029 -1 &
sleep 0.3
iperf3 -s -p 10029 -1 &
sleep 0.3
iperf3 -s -p 11029 -1 &
sleep 0.3
iperf3 -s -p 13029 -1 &
sleep 0.3
iperf3 -s -p 18029 -1 &
sleep 0.3
iperf3 -s -p 20029 -1 &
sleep 0.3
iperf3 -s -p 22029 -1 &
sleep 0.3
iperf3 -s -p 23029 -1 &
sleep 0.3
iperf3 -s -p 24029 -1 &
sleep 0.3
iperf3 -s -p 26029 -1 &
sleep 0.3
iperf3 -s -p 27029 -1 &
sleep 0.3
iperf3 -s -p 28029 -1 &
sleep 0.3
iperf3 -s -p 30029 -1 &
sleep 0.3
iperf3 -s -p 31029 -1 &
sleep 0.3
iperf3 -s -p 32029 -1 &
sleep 0.3
iperf3 -s -p 33029 -1 &
sleep 0.3
iperf3 -s -p 34029 -1 &
sleep 0.3
iperf3 -s -p 35029 -1 &
sleep 0.3
iperf3 -s -p 36029 -1 &
sleep 0.3
iperf3 -s -p 38029 -1 &
sleep 0.3
iperf3 -s -p 40029 -1 &
sleep 0.3
iperf3 -s -p 41029 -1 &
sleep 0.3
iperf3 -s -p 42029 -1 &
sleep 0.3
iperf3 -s -p 43029 -1 &
sleep 0.3
iperf3 -s -p 45029 -1 &
sleep 0.3
iperf3 -s -p 46029 -1 &
sleep 0.3
iperf3 -s -p 47029 -1 &
sleep 0.3
iperf3 -s -p 48029 -1 &
sleep 0.3