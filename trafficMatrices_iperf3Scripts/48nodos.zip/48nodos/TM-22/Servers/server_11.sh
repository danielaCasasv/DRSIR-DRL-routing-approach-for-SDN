 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1011 -1 &
sleep 0.3
iperf3 -s -p 2011 -1 &
sleep 0.3
iperf3 -s -p 4011 -1 &
sleep 0.3
iperf3 -s -p 7011 -1 &
sleep 0.3
iperf3 -s -p 8011 -1 &
sleep 0.3
iperf3 -s -p 9011 -1 &
sleep 0.3
iperf3 -s -p 10011 -1 &
sleep 0.3
iperf3 -s -p 12011 -1 &
sleep 0.3
iperf3 -s -p 13011 -1 &
sleep 0.3
iperf3 -s -p 14011 -1 &
sleep 0.3
iperf3 -s -p 15011 -1 &
sleep 0.3
iperf3 -s -p 17011 -1 &
sleep 0.3
iperf3 -s -p 18011 -1 &
sleep 0.3
iperf3 -s -p 22011 -1 &
sleep 0.3
iperf3 -s -p 23011 -1 &
sleep 0.3
iperf3 -s -p 24011 -1 &
sleep 0.3
iperf3 -s -p 25011 -1 &
sleep 0.3
iperf3 -s -p 27011 -1 &
sleep 0.3
iperf3 -s -p 29011 -1 &
sleep 0.3
iperf3 -s -p 30011 -1 &
sleep 0.3
iperf3 -s -p 31011 -1 &
sleep 0.3
iperf3 -s -p 32011 -1 &
sleep 0.3
iperf3 -s -p 33011 -1 &
sleep 0.3
iperf3 -s -p 34011 -1 &
sleep 0.3
iperf3 -s -p 36011 -1 &
sleep 0.3
iperf3 -s -p 37011 -1 &
sleep 0.3
iperf3 -s -p 40011 -1 &
sleep 0.3
iperf3 -s -p 41011 -1 &
sleep 0.3
iperf3 -s -p 43011 -1 &
sleep 0.3
iperf3 -s -p 45011 -1 &
sleep 0.3
iperf3 -s -p 47011 -1 &
sleep 0.3
iperf3 -s -p 48011 -1 &
sleep 0.3