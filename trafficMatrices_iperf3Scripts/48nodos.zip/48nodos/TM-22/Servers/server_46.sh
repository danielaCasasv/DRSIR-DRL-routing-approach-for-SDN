 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1046 -1 &
sleep 0.3
iperf3 -s -p 2046 -1 &
sleep 0.3
iperf3 -s -p 3046 -1 &
sleep 0.3
iperf3 -s -p 5046 -1 &
sleep 0.3
iperf3 -s -p 6046 -1 &
sleep 0.3
iperf3 -s -p 7046 -1 &
sleep 0.3
iperf3 -s -p 8046 -1 &
sleep 0.3
iperf3 -s -p 10046 -1 &
sleep 0.3
iperf3 -s -p 11046 -1 &
sleep 0.3
iperf3 -s -p 12046 -1 &
sleep 0.3
iperf3 -s -p 14046 -1 &
sleep 0.3
iperf3 -s -p 15046 -1 &
sleep 0.3
iperf3 -s -p 16046 -1 &
sleep 0.3
iperf3 -s -p 17046 -1 &
sleep 0.3
iperf3 -s -p 18046 -1 &
sleep 0.3
iperf3 -s -p 19046 -1 &
sleep 0.3
iperf3 -s -p 21046 -1 &
sleep 0.3
iperf3 -s -p 23046 -1 &
sleep 0.3
iperf3 -s -p 24046 -1 &
sleep 0.3
iperf3 -s -p 25046 -1 &
sleep 0.3
iperf3 -s -p 29046 -1 &
sleep 0.3
iperf3 -s -p 33046 -1 &
sleep 0.3
iperf3 -s -p 34046 -1 &
sleep 0.3
iperf3 -s -p 35046 -1 &
sleep 0.3
iperf3 -s -p 36046 -1 &
sleep 0.3
iperf3 -s -p 39046 -1 &
sleep 0.3
iperf3 -s -p 40046 -1 &
sleep 0.3
iperf3 -s -p 43046 -1 &
sleep 0.3
iperf3 -s -p 44046 -1 &
sleep 0.3
iperf3 -s -p 45046 -1 &
sleep 0.3
iperf3 -s -p 47046 -1 &
sleep 0.3
iperf3 -s -p 48046 -1 &
sleep 0.3