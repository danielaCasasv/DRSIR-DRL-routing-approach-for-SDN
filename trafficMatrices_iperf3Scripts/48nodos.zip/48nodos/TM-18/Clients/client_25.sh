 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 25002 -u -b 688.873k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 25003 -u -b 3362.345k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 25005 -u -b 1495.732k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 25007 -u -b 207.810k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 25009 -u -b 1746.010k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 25010 -u -b 502.048k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 25011 -u -b 1745.578k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 25012 -u -b 1304.480k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 25013 -u -b 2113.208k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 25016 -u -b 433.582k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 25018 -u -b 2516.204k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 25019 -u -b 1958.038k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 25022 -u -b 2631.108k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 25026 -u -b 315.243k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 25027 -u -b 2697.117k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 25028 -u -b 2892.538k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 25030 -u -b 1187.500k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 25032 -u -b 1915.149k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 25033 -u -b 3090.718k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 25036 -u -b 1636.785k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 25037 -u -b 1241.921k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 25038 -u -b 2929.336k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 25039 -u -b 2497.546k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 25040 -u -b 1423.992k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 25044 -u -b 2505.304k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 25046 -u -b 2460.966k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 25047 -u -b 1402.835k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 25048 -u -b 1973.284k -w 256k -t 30 &
sleep 0.4