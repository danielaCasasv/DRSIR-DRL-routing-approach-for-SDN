 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 48001 -u -b 4538.237k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 48002 -u -b 1661.424k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 48004 -u -b 574.627k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 48006 -u -b 7804.784k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 48007 -u -b 501.196k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 48009 -u -b 4211.029k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 48010 -u -b 1210.840k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 48011 -u -b 4209.989k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 48016 -u -b 1045.715k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 48017 -u -b 1283.020k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 48019 -u -b 4722.399k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 48020 -u -b 3592.886k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 48021 -u -b 8105.580k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 48023 -u -b 7041.314k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 48024 -u -b 2929.921k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 48025 -u -b 1973.284k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 48026 -u -b 760.302k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 48027 -u -b 6504.911k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 48028 -u -b 6976.228k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 48029 -u -b 5915.001k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 48030 -u -b 2864.015k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 48032 -u -b 4618.959k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 48033 -u -b 7454.200k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 48034 -u -b 4860.969k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 48035 -u -b 268.449k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 48037 -u -b 2995.267k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 48039 -u -b 6023.586k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 48041 -u -b 364.551k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 48043 -u -b 4795.722k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 48046 -u -b 5935.361k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 48047 -u -b 3383.360k -w 256k -t 30 &
sleep 0.4