 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 4001 -u -b 547.951k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 4005 -u -b 435.562k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 4006 -u -b 942.358k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 4007 -u -b 60.515k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 4009 -u -b 508.444k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 4010 -u -b 146.198k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 4011 -u -b 508.319k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 4013 -u -b 615.373k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 4016 -u -b 126.261k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 4017 -u -b 154.913k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 4020 -u -b 433.809k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 4022 -u -b 766.188k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 4023 -u -b 850.176k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 4025 -u -b 238.256k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 4026 -u -b 91.800k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 4029 -u -b 714.183k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 4030 -u -b 345.804k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 4031 -u -b 848.270k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 4032 -u -b 557.698k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 4033 -u -b 900.028k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 4035 -u -b 32.413k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 4036 -u -b 476.637k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 4037 -u -b 361.652k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 4038 -u -b 853.033k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 4039 -u -b 727.294k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 4040 -u -b 414.671k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 4041 -u -b 44.016k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 4043 -u -b 579.041k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 4045 -u -b 452.548k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 4047 -u -b 408.510k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 4048 -u -b 574.627k -w 256k -t 30 &
sleep 0.4