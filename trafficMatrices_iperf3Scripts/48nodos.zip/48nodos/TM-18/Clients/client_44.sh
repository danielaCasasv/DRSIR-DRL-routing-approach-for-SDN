 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 44001 -u -b 5761.798k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 44003 -u -b 10295.674k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 44005 -u -b 4580.007k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 44008 -u -b 9817.840k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 44010 -u -b 1537.297k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 44014 -u -b 7505.061k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 44015 -u -b 6554.026k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 44016 -u -b 1327.652k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 44018 -u -b 7704.747k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 44019 -u -b 5995.612k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 44020 -u -b 4561.569k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 44022 -u -b 8056.587k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 44023 -u -b 8939.733k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 44024 -u -b 3719.862k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 44025 -u -b 2505.304k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 44026 -u -b 965.289k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 44030 -u -b 3636.186k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 44031 -u -b 8919.699k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 44032 -u -b 5864.284k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 44033 -u -b 9463.938k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 44034 -u -b 6171.542k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 44035 -u -b 340.825k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 44036 -u -b 5011.920k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 44037 -u -b 3802.825k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 44039 -u -b 7647.614k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 44040 -u -b 4360.337k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 44042 -u -b 6219.079k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 44043 -u -b 6088.704k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 44045 -u -b 4758.618k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 44046 -u -b 7535.603k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 44047 -u -b 4295.552k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 44048 -u -b 6042.297k -w 256k -t 30 &
sleep 0.4