 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 11001 -u -b 4014.551k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 11002 -u -b 1469.706k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 11004 -u -b 508.319k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 11005 -u -b 3191.134k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 11007 -u -b 443.361k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 11008 -u -b 6840.611k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 11009 -u -b 3725.101k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 11010 -u -b 1071.116k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 11012 -u -b 2783.101k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 11013 -u -b 4508.515k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 11016 -u -b 925.045k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 11017 -u -b 1134.967k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 11018 -u -b 5368.306k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 11019 -u -b 4177.461k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 11021 -u -b 7170.243k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 11022 -u -b 5613.452k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 11026 -u -b 672.568k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 11027 -u -b 5754.282k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 11028 -u -b 6171.212k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 11029 -u -b 5232.444k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 11030 -u -b 2533.524k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 11031 -u -b 6214.828k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 11032 -u -b 4085.958k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 11033 -u -b 6594.028k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 11036 -u -b 3492.071k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 11037 -u -b 2649.630k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 11038 -u -b 6249.721k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 11039 -u -b 5328.499k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 11041 -u -b 322.484k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 11042 -u -b 4333.163k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 11043 -u -b 4242.324k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 11044 -u -b 5345.051k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 11045 -u -b 3315.582k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 11046 -u -b 5250.455k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 11048 -u -b 4209.989k -w 256k -t 30 &
sleep 0.4