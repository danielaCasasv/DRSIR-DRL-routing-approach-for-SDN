 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.3 -p 18003 -u -b 10340.469k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 18004 -u -b 732.727k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 18005 -u -b 4599.934k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 18006 -u -b 9952.156k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 18007 -u -b 639.093k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 18008 -u -b 9860.557k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 18009 -u -b 5369.632k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 18010 -u -b 1543.985k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 18011 -u -b 5368.306k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 18013 -u -b 6498.904k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 18014 -u -b 7537.715k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 18015 -u -b 6582.541k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 18017 -u -b 1636.025k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 18020 -u -b 4581.416k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 18021 -u -b 10335.713k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 18022 -u -b 8091.641k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 18024 -u -b 3736.047k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 18025 -u -b 2516.204k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 18028 -u -b 8895.636k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 18029 -u -b 7542.427k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 18031 -u -b 8958.507k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 18033 -u -b 9505.114k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 18035 -u -b 342.308k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 18039 -u -b 7680.888k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 18040 -u -b 4379.308k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 18041 -u -b 464.852k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 18043 -u -b 6115.196k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 18044 -u -b 7704.747k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 18046 -u -b 7568.390k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 18048 -u -b 6068.586k -w 256k -t 30 &
sleep 0.4