 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 20001 -u -b 3426.095k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 20003 -u -b 6122.040k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 20004 -u -b 433.809k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 20005 -u -b 2723.375k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 20007 -u -b 378.373k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 20010 -u -b 914.111k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 20012 -u -b 2375.152k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 20013 -u -b 3847.654k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 20014 -u -b 4462.679k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 20015 -u -b 3897.171k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 20016 -u -b 789.452k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 20018 -u -b 4581.416k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 20021 -u -b 6119.224k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 20023 -u -b 5315.767k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 20024 -u -b 2211.914k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 20025 -u -b 1489.710k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 20027 -u -b 4910.815k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 20028 -u -b 5266.631k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 20029 -u -b 4465.468k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 20030 -u -b 2162.158k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 20032 -u -b 3487.035k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 20035 -u -b 202.662k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 20037 -u -b 2261.246k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 20039 -u -b 4547.444k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 20040 -u -b 2592.754k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 20041 -u -b 275.214k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 20043 -u -b 3620.481k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 20044 -u -b 4561.569k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 20045 -u -b 2829.581k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 20047 -u -b 2554.232k -w 256k -t 30 &
sleep 0.4