 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 41001 -u -b 347.628k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 41002 -u -b 127.265k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 41003 -u -b 621.171k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 41004 -u -b 44.016k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 41005 -u -b 276.327k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 41006 -u -b 597.845k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 41007 -u -b 38.391k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 41008 -u -b 592.342k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 41011 -u -b 322.484k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 41014 -u -b 452.805k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 41016 -u -b 80.102k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 41018 -u -b 464.852k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 41021 -u -b 620.886k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 41022 -u -b 486.080k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 41024 -u -b 224.431k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 41025 -u -b 151.153k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 41026 -u -b 58.239k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 41027 -u -b 498.275k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 41028 -u -b 534.377k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 41029 -u -b 453.088k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 41030 -u -b 219.383k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 41031 -u -b 538.154k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 41033 -u -b 570.990k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 41034 -u -b 372.349k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 41036 -u -b 302.385k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 41039 -u -b 461.405k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 41040 -u -b 263.073k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 41042 -u -b 375.217k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 41043 -u -b 367.351k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 41044 -u -b 462.839k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 41045 -u -b 287.103k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 41047 -u -b 259.165k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 41048 -u -b 364.551k -w 256k -t 30 &
sleep 0.4