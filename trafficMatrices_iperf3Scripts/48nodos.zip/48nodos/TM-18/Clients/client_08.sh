 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 8002 -u -b 2699.570k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 8003 -u -b 13176.433k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 8004 -u -b 933.684k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 8005 -u -b 5861.506k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 8006 -u -b 12681.622k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 8007 -u -b 814.370k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 8010 -u -b 1967.436k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 8011 -u -b 6840.611k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 8013 -u -b 8281.284k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 8014 -u -b 9604.999k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 8015 -u -b 8387.860k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 8016 -u -b 1699.132k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 8017 -u -b 2084.719k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 8018 -u -b 9860.557k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 8019 -u -b 7673.201k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 8020 -u -b 5837.909k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 8021 -u -b 13170.371k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 8022 -u -b 10310.843k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 8023 -u -b 11441.096k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 8024 -u -b 4760.690k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 8028 -u -b 11335.342k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 8029 -u -b 9611.003k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 8033 -u -b 12111.974k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 8034 -u -b 7898.357k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 8035 -u -b 436.189k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 8036 -u -b 6414.269k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 8038 -u -b 11479.548k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 8039 -u -b 9787.438k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 8040 -u -b 5580.371k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 8042 -u -b 7959.195k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 8043 -u -b 7792.341k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 8046 -u -b 9644.086k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 8047 -u -b 5497.460k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 8048 -u -b 7732.948k -w 256k -t 30 &
sleep 0.4