 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 6002 -u -b 2724.647k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 6003 -u -b 13298.836k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 6004 -u -b 942.358k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 6005 -u -b 5915.956k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 6007 -u -b 821.935k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 6009 -u -b 6905.862k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 6010 -u -b 1985.713k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 6012 -u -b 5159.514k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 6014 -u -b 9694.224k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 6015 -u -b 8465.780k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 6016 -u -b 1714.917k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 6017 -u -b 2104.085k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 6019 -u -b 7744.481k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 6020 -u -b 5892.140k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 6022 -u -b 10406.626k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 6023 -u -b 11547.378k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 6028 -u -b 11440.642k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 6031 -u -b 11521.500k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 6032 -u -b 7574.846k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 6036 -u -b 6473.855k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 6037 -u -b 4912.077k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 6041 -u -b 597.845k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 6042 -u -b 8033.132k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 6043 -u -b 7864.728k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 6045 -u -b 6146.667k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 6046 -u -b 9733.675k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 6047 -u -b 5548.529k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 6048 -u -b 7804.784k -w 256k -t 30 &
sleep 0.4