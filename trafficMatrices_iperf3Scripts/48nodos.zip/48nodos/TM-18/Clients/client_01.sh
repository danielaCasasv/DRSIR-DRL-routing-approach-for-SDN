 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 1002 -u -b 1584.297k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 1003 -u -b 7732.856k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 1004 -u -b 547.951k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 1005 -u -b 3439.943k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 1006 -u -b 7442.466k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 1007 -u -b 477.929k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 1008 -u -b 7373.965k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 1009 -u -b 4015.542k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 1010 -u -b 1154.630k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 1011 -u -b 4014.551k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 1013 -u -b 4860.039k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 1014 -u -b 5636.887k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 1015 -u -b 4922.585k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 1018 -u -b 5786.867k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 1019 -u -b 4503.173k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 1020 -u -b 3426.095k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 1023 -u -b 6714.438k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 1024 -u -b 2793.907k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 1026 -u -b 725.007k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 1028 -u -b 6652.374k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 1029 -u -b 5640.411k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 1030 -u -b 2731.060k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 1031 -u -b 6699.391k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 1032 -u -b 4404.536k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 1033 -u -b 7108.157k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 1036 -u -b 3764.343k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 1037 -u -b 2856.219k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 1038 -u -b 6737.004k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 1040 -u -b 3274.954k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 1043 -u -b 4573.093k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 1044 -u -b 5761.798k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 1045 -u -b 3574.094k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 1046 -u -b 5659.827k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 1048 -u -b 4538.237k -w 256k -t 30 &
sleep 0.4