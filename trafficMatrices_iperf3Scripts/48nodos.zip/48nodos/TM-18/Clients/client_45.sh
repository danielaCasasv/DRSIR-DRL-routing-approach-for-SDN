 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.3 -p 45003 -u -b 6386.497k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 45004 -u -b 452.548k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 45007 -u -b 394.717k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 45008 -u -b 6090.093k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 45010 -u -b 953.599k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 45011 -u -b 3315.582k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 45012 -u -b 2477.752k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 45014 -u -b 4655.455k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 45015 -u -b 4065.520k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 45016 -u -b 823.554k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 45017 -u -b 1010.444k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 45018 -u -b 4779.322k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 45019 -u -b 3719.131k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 45021 -u -b 6383.559k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 45024 -u -b 2307.463k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 45025 -u -b 1554.062k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 45026 -u -b 598.777k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 45027 -u -b 5122.950k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 45028 -u -b 5494.137k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 45029 -u -b 4658.366k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 45030 -u -b 2255.558k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 45031 -u -b 5532.967k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 45032 -u -b 3637.667k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 45035 -u -b 211.417k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 45036 -u -b 3108.938k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 45037 -u -b 2358.926k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 45038 -u -b 5564.032k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 45039 -u -b 4743.882k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 45041 -u -b 287.103k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 45042 -u -b 3857.749k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 45044 -u -b 4758.618k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 45046 -u -b 4674.401k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 45047 -u -b 2664.569k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 45048 -u -b 3748.090k -w 256k -t 30 &
sleep 0.4