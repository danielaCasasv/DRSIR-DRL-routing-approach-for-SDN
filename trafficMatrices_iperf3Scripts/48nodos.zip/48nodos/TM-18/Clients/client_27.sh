 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 27001 -u -b 6202.936k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 27002 -u -b 2270.862k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 27004 -u -b 785.410k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 27007 -u -b 685.043k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 27008 -u -b 10569.520k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 27010 -u -b 1654.996k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 27011 -u -b 5754.282k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 27012 -u -b 4300.206k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 27013 -u -b 6966.168k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 27014 -u -b 8079.669k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 27015 -u -b 7055.819k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 27016 -u -b 1429.300k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 27019 -u -b 6454.652k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 27022 -u -b 8673.421k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 27023 -u -b 9624.183k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 27025 -u -b 2697.117k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 27026 -u -b 1039.194k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 27028 -u -b 9535.223k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 27029 -u -b 8084.720k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 27032 -u -b 6313.269k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 27033 -u -b 10188.522k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 27034 -u -b 6644.051k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 27035 -u -b 366.920k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 27037 -u -b 4093.980k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 27038 -u -b 9656.528k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 27039 -u -b 8233.135k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 27040 -u -b 4694.176k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 27041 -u -b 498.275k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 27042 -u -b 6695.228k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 27044 -u -b 8258.710k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 27045 -u -b 5122.950k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 27047 -u -b 4624.431k -w 256k -t 30 &
sleep 0.4