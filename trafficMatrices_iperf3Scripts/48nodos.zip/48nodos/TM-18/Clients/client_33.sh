 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 33001 -u -b 7108.157k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 33002 -u -b 2602.258k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 33004 -u -b 900.028k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 33005 -u -b 5650.217k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 33006 -u -b 12224.489k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 33007 -u -b 785.014k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 33008 -u -b 12111.974k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 33009 -u -b 6595.657k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 33010 -u -b 1896.517k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 33011 -u -b 6594.028k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 33012 -u -b 4927.753k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 33013 -u -b 7982.770k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 33014 -u -b 9258.769k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 33015 -u -b 8085.504k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 33016 -u -b 1637.884k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 33022 -u -b 9939.170k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 33023 -u -b 11028.680k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 33025 -u -b 3090.718k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 33027 -u -b 10188.522k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 33028 -u -b 10926.738k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 33029 -u -b 9264.557k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 33030 -u -b 4485.853k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 33034 -u -b 7613.646k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 33036 -u -b 6183.055k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 33037 -u -b 4691.431k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 33039 -u -b 9434.631k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 33041 -u -b 570.990k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 33044 -u -b 9463.938k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 33045 -u -b 5870.564k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 33046 -u -b 9296.447k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 33048 -u -b 7454.200k -w 256k -t 30 &
sleep 0.4