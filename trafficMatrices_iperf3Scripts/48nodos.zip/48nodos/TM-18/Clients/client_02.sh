 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 2001 -u -b 1584.297k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 2005 -u -b 1259.345k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 2010 -u -b 422.704k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 2011 -u -b 1469.706k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 2012 -u -b 1098.319k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 2013 -u -b 1779.234k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 2014 -u -b 2063.635k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 2015 -u -b 1802.132k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 2017 -u -b 447.902k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 2018 -u -b 2118.541k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 2019 -u -b 1648.588k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 2023 -u -b 2458.120k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 2025 -u -b 688.873k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 2026 -u -b 265.421k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 2027 -u -b 2270.862k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 2028 -u -b 2435.399k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 2029 -u -b 2064.925k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 2030 -u -b 999.826k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 2031 -u -b 2452.611k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 2036 -u -b 1378.106k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 2037 -u -b 1045.647k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 2039 -u -b 2102.832k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 2041 -u -b 127.265k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 2042 -u -b 1710.034k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 2043 -u -b 1674.185k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 2044 -u -b 2109.364k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 2046 -u -b 2072.032k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 2047 -u -b 1181.130k -w 256k -t 30 &
sleep 0.4