 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 46001 -u -b 5659.827k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 46002 -u -b 2072.032k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 46003 -u -b 10113.463k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 46006 -u -b 9733.675k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 46007 -u -b 625.063k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 46008 -u -b 9644.086k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 46009 -u -b 5251.752k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 46010 -u -b 1510.090k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 46012 -u -b 3923.694k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 46014 -u -b 7372.238k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 46015 -u -b 6438.034k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 46017 -u -b 1600.109k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 46018 -u -b 7568.390k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 46019 -u -b 5889.502k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 46020 -u -b 4480.839k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 46022 -u -b 7914.004k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 46024 -u -b 3654.029k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 46027 -u -b 8112.549k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 46029 -u -b 7376.847k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 46030 -u -b 3571.833k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 46031 -u -b 8761.839k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 46033 -u -b 9296.447k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 46035 -u -b 334.794k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 46036 -u -b 4923.220k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 46038 -u -b 8811.033k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 46040 -u -b 4283.168k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 46041 -u -b 454.647k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 46044 -u -b 7535.603k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 46045 -u -b 4674.401k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 46047 -u -b 4219.530k -w 256k -t 30 &
sleep 0.4