 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 43001 -u -b 4573.093k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 43002 -u -b 1674.185k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 43004 -u -b 579.041k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 43005 -u -b 3635.115k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 43007 -u -b 505.045k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 43010 -u -b 1220.140k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 43011 -u -b 4242.324k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 43012 -u -b 3170.312k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 43013 -u -b 5135.782k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 43014 -u -b 5956.707k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 43016 -u -b 1053.746k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 43017 -u -b 1292.874k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 43018 -u -b 6115.196k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 43019 -u -b 4758.669k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 43021 -u -b 8167.835k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 43022 -u -b 6394.449k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 43023 -u -b 7095.394k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 43025 -u -b 1988.440k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 43026 -u -b 766.142k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 43027 -u -b 6554.872k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 43028 -u -b 7029.809k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 43029 -u -b 5960.431k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 43030 -u -b 2886.012k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 43033 -u -b 7511.452k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 43034 -u -b 4898.303k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 43035 -u -b 270.510k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 43036 -u -b 3977.920k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 43037 -u -b 3018.272k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 43039 -u -b 6069.850k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 43040 -u -b 3460.764k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 43042 -u -b 4936.033k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 43044 -u -b 6088.704k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 43046 -u -b 5980.948k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 43047 -u -b 3409.345k -w 256k -t 30 &
sleep 0.4