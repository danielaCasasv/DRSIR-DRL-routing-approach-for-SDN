 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 7001 -u -b 477.929k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 7002 -u -b 174.967k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 7003 -u -b 854.005k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 7004 -u -b 60.515k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 7008 -u -b 814.370k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 7009 -u -b 443.470k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 7010 -u -b 127.516k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 7011 -u -b 443.361k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 7012 -u -b 331.326k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 7013 -u -b 536.735k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 7014 -u -b 622.529k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 7015 -u -b 543.643k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 7016 -u -b 110.126k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 7020 -u -b 378.373k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 7022 -u -b 668.277k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 7023 -u -b 741.532k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 7024 -u -b 308.555k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 7025 -u -b 207.810k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 7026 -u -b 80.069k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 7027 -u -b 685.043k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 7028 -u -b 734.678k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 7029 -u -b 622.918k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 7030 -u -b 301.614k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 7034 -u -b 511.917k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 7038 -u -b 744.025k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 7039 -u -b 634.354k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 7040 -u -b 361.681k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 7041 -u -b 38.391k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 7043 -u -b 505.045k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 7044 -u -b 636.324k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 7045 -u -b 394.717k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 7046 -u -b 625.063k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 7047 -u -b 356.307k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 7048 -u -b 501.196k -w 256k -t 30 &
sleep 0.4