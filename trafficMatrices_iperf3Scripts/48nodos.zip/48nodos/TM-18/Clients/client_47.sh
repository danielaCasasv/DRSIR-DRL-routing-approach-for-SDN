 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 47001 -u -b 3226.295k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 47002 -u -b 1181.130k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 47004 -u -b 408.510k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 47005 -u -b 2564.556k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 47006 -u -b 5548.529k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 47008 -u -b 5497.460k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 47010 -u -b 860.803k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 47011 -u -b 2992.939k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 47012 -u -b 2236.640k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 47013 -u -b 3623.270k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 47014 -u -b 4202.429k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 47017 -u -b 912.117k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 47020 -u -b 2554.232k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 47021 -u -b 5762.369k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 47023 -u -b 5005.767k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 47024 -u -b 2082.922k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 47025 -u -b 1402.835k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 47026 -u -b 540.510k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 47027 -u -b 4624.431k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 47028 -u -b 4959.497k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 47029 -u -b 4205.056k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 47030 -u -b 2036.068k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 47031 -u -b 4994.549k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 47032 -u -b 3283.682k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 47033 -u -b 5299.294k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 47037 -u -b 2129.377k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 47038 -u -b 5022.591k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 47039 -u -b 4282.250k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 47040 -u -b 2441.553k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 47041 -u -b 259.165k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 47043 -u -b 3409.345k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 47044 -u -b 4295.552k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 47045 -u -b 2664.569k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 47046 -u -b 4219.530k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 47048 -u -b 3383.360k -w 256k -t 30 &
sleep 0.4