 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 5001 -u -b 3439.943k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 5003 -u -b 6146.785k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 5004 -u -b 435.562k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 5006 -u -b 5915.956k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 5007 -u -b 379.902k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 5008 -u -b 5861.506k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 5009 -u -b 3191.922k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 5012 -u -b 2384.752k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 5013 -u -b 3863.206k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 5016 -u -b 792.643k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 5017 -u -b 972.518k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 5018 -u -b 4599.934k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 5019 -u -b 3579.536k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 5021 -u -b 6143.957k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 5022 -u -b 4809.992k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 5023 -u -b 5337.253k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 5024 -u -b 2220.854k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 5025 -u -b 1495.732k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 5026 -u -b 576.302k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 5027 -u -b 4930.664k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 5028 -u -b 5287.919k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 5029 -u -b 4483.518k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 5031 -u -b 5325.292k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 5034 -u -b 3684.571k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 5035 -u -b 203.482k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 5036 -u -b 2992.246k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 5037 -u -b 2270.385k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 5039 -u -b 4565.824k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 5040 -u -b 2603.234k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 5041 -u -b 276.327k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 5042 -u -b 3712.952k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 5043 -u -b 3635.115k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 5044 -u -b 4580.007k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 5045 -u -b 2841.018k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 5046 -u -b 4498.951k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 5047 -u -b 2564.556k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 5048 -u -b 3607.408k -w 256k -t 30 &
sleep 0.4