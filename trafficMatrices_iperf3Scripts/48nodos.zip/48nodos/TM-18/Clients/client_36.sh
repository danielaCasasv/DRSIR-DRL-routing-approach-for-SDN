 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 36001 -u -b 3764.343k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 36002 -u -b 1378.106k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 36003 -u -b 6726.451k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 36004 -u -b 476.637k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 36005 -u -b 2992.246k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 36006 -u -b 6473.855k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 36007 -u -b 415.728k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 36008 -u -b 6414.269k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 36010 -u -b 1004.359k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 36011 -u -b 3492.071k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 36014 -u -b 4903.266k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 36015 -u -b 4281.928k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 36018 -u -b 5033.726k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 36021 -u -b 6723.357k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 36022 -u -b 5263.593k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 36023 -u -b 5840.577k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 36024 -u -b 2430.290k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 36025 -u -b 1636.785k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 36026 -u -b 630.650k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 36027 -u -b 5395.646k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 36029 -u -b 4906.331k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 36030 -u -b 2375.622k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 36031 -u -b 5827.488k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 36032 -u -b 3831.300k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 36033 -u -b 6183.055k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 36034 -u -b 4032.040k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 36035 -u -b 222.671k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 36038 -u -b 5860.206k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 36039 -u -b 4996.400k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 36040 -u -b 2848.730k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 36041 -u -b 302.385k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 36042 -u -b 4063.098k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 36043 -u -b 3977.920k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 36044 -u -b 5011.920k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 36046 -u -b 4923.220k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 36047 -u -b 2806.404k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 36048 -u -b 3947.601k -w 256k -t 30 &
sleep 0.4