 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 19001 -u -b 4503.173k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 19002 -u -b 1648.588k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 19003 -u -b 8046.655k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 19005 -u -b 3579.536k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 19006 -u -b 7744.481k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 19007 -u -b 497.324k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 19008 -u -b 7673.201k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 19010 -u -b 1201.485k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 19012 -u -b 3121.840k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 19013 -u -b 5057.259k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 19014 -u -b 5865.632k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 19015 -u -b 5122.344k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 19016 -u -b 1037.635k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 19017 -u -b 1273.107k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 19018 -u -b 6021.698k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 19020 -u -b 3565.126k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 19022 -u -b 6296.681k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 19023 -u -b 6986.910k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 19025 -u -b 1958.038k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 19026 -u -b 754.428k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 19027 -u -b 6454.652k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 19028 -u -b 6922.328k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 19032 -u -b 4583.272k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 19033 -u -b 7396.606k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 19034 -u -b 4823.411k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 19035 -u -b 266.374k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 19036 -u -b 3917.100k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 19037 -u -b 2972.124k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 19039 -u -b 5977.045k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 19041 -u -b 361.735k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 19042 -u -b 4860.564k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 19043 -u -b 4758.669k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 19044 -u -b 5995.612k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 19045 -u -b 3719.131k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 19046 -u -b 5889.502k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 19047 -u -b 3357.218k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 19048 -u -b 4722.399k -w 256k -t 30 &
sleep 0.4