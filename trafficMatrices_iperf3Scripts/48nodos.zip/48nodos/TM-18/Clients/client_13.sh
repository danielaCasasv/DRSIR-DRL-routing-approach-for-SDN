 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 13001 -u -b 4860.039k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 13003 -u -b 8684.334k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 13005 -u -b 3863.206k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 13006 -u -b 8358.214k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 13008 -u -b 8281.284k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 13009 -u -b 4509.629k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 13010 -u -b 1296.700k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 13011 -u -b 4508.515k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 13012 -u -b 3369.238k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 13015 -u -b 5528.278k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 13016 -u -b 1119.866k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 13017 -u -b 1373.998k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 13018 -u -b 6498.904k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 13019 -u -b 5057.259k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 13021 -u -b 8680.339k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 13023 -u -b 7540.607k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 13024 -u -b 3137.679k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 13025 -u -b 2113.208k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 13026 -u -b 814.215k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 13027 -u -b 6966.168k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 13029 -u -b 6334.428k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 13030 -u -b 3067.099k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 13031 -u -b 7523.708k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 13032 -u -b 4946.485k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 13033 -u -b 7982.770k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 13034 -u -b 5205.655k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 13035 -u -b 287.484k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 13037 -u -b 3207.658k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 13040 -u -b 3677.916k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 13041 -u -b 390.401k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 13043 -u -b 5135.782k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 13045 -u -b 4013.863k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 13047 -u -b 3623.270k -w 256k -t 30 &
sleep 0.4