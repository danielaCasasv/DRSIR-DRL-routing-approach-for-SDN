 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 26001 -u -b 725.007k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 26002 -u -b 265.421k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 26003 -u -b 1295.505k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 26005 -u -b 576.302k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 26006 -u -b 1246.855k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 26007 -u -b 80.069k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 26008 -u -b 1235.379k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 26010 -u -b 193.438k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 26012 -u -b 502.614k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 26015 -u -b 824.693k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 26016 -u -b 167.058k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 26017 -u -b 204.969k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 26018 -u -b 969.489k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 26020 -u -b 573.982k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 26024 -u -b 468.070k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 26029 -u -b 944.953k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 26030 -u -b 457.541k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 26031 -u -b 1122.366k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 26034 -u -b 776.565k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 26035 -u -b 42.886k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 26036 -u -b 630.650k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 26037 -u -b 478.510k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 26038 -u -b 1128.668k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 26045 -u -b 598.777k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 26047 -u -b 540.510k -w 256k -t 30 &
sleep 0.4