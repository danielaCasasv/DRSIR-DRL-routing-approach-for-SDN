 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 16001 -u -b 997.170k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 16002 -u -b 365.059k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 16003 -u -b 1781.829k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 16005 -u -b 792.643k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 16006 -u -b 1714.917k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 16008 -u -b 1699.132k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 16010 -u -b 266.053k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 16012 -u -b 691.292k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 16013 -u -b 1119.866k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 16014 -u -b 1298.869k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 16017 -u -b 281.913k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 16018 -u -b 1333.428k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 16020 -u -b 789.452k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 16021 -u -b 1781.009k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 16022 -u -b 1394.320k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 16026 -u -b 167.058k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 16027 -u -b 1429.300k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 16030 -u -b 629.299k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 16031 -u -b 1543.695k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 16032 -u -b 1014.907k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 16033 -u -b 1637.884k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 16034 -u -b 1068.083k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 16035 -u -b 58.985k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 16036 -u -b 867.392k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 16037 -u -b 658.139k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 16038 -u -b 1552.362k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 16040 -u -b 754.625k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 16042 -u -b 1076.310k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 16044 -u -b 1327.652k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 16045 -u -b 823.554k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 16046 -u -b 1304.155k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 16047 -u -b 743.413k -w 256k -t 30 &
sleep 0.4