 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 22002 -u -b 2215.285k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 22003 -u -b 10812.672k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 22005 -u -b 4809.992k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 22006 -u -b 10406.626k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 22007 -u -b 668.277k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 22008 -u -b 10310.843k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 22009 -u -b 5614.839k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 22010 -u -b 1614.492k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 22011 -u -b 5613.452k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 22012 -u -b 4194.964k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 22014 -u -b 7881.928k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 22016 -u -b 1394.320k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 22019 -u -b 6296.681k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 22021 -u -b 10807.698k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 22023 -u -b 9388.642k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 22025 -u -b 2631.108k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 22027 -u -b 8673.421k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 22029 -u -b 7886.856k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 22030 -u -b 3818.777k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 22031 -u -b 9367.601k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 22033 -u -b 9939.170k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 22034 -u -b 6481.446k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 22035 -u -b 357.940k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 22038 -u -b 9420.196k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 22040 -u -b 4579.291k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 22042 -u -b 6531.370k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 22043 -u -b 6394.449k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 22047 -u -b 4511.254k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 22048 -u -b 6345.711k -w 256k -t 30 &
sleep 0.4