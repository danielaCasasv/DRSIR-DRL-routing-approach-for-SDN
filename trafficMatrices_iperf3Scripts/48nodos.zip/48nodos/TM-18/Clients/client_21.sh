 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 21001 -u -b 7729.299k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 21004 -u -b 978.676k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 21005 -u -b 6143.957k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 21007 -u -b 853.612k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 21008 -u -b 13170.371k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 21009 -u -b 7172.014k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 21012 -u -b 5358.362k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 21013 -u -b 8680.339k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 21014 -u -b 10067.840k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 21015 -u -b 8792.051k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 21016 -u -b 1781.009k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 21017 -u -b 2185.176k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 21019 -u -b 8042.953k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 21020 -u -b 6119.224k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 21022 -u -b 10807.698k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 21023 -u -b 11992.414k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 21025 -u -b 3360.799k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 21027 -u -b 11078.839k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 21028 -u -b 11881.564k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 21030 -u -b 4877.847k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 21031 -u -b 11965.538k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 21032 -u -b 7866.781k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 21033 -u -b 12695.621k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 21034 -u -b 8278.959k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 21037 -u -b 5101.389k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 21038 -u -b 12032.719k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 21039 -u -b 10259.070k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 21040 -u -b 5849.276k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 21041 -u -b 620.886k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 21042 -u -b 8342.729k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 21043 -u -b 8167.835k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 21044 -u -b 10290.938k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 21045 -u -b 6383.559k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 21046 -u -b 10108.811k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 21047 -u -b 5762.369k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 21048 -u -b 8105.580k -w 256k -t 30 &
sleep 0.4