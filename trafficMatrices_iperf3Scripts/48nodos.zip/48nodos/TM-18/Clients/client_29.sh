 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 29002 -u -b 2064.925k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 29003 -u -b 10078.770k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 29004 -u -b 714.183k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 29005 -u -b 4483.518k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 29007 -u -b 622.918k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 29008 -u -b 9611.003k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 29009 -u -b 5233.737k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 29010 -u -b 1504.910k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 29011 -u -b 5232.444k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 29012 -u -b 3910.234k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 29013 -u -b 6334.428k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 29015 -u -b 6415.949k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 29017 -u -b 1594.620k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 29018 -u -b 7542.427k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 29020 -u -b 4465.468k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 29021 -u -b 10074.134k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 29022 -u -b 7886.856k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 29023 -u -b 8751.396k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 29025 -u -b 2452.524k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 29026 -u -b 944.953k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 29028 -u -b 8670.503k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 29030 -u -b 3559.581k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 29032 -u -b 5740.739k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 29034 -u -b 6041.523k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 29035 -u -b 333.645k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 29036 -u -b 4906.331k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 29037 -u -b 3722.709k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 29038 -u -b 8780.808k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 29040 -u -b 4268.476k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 29041 -u -b 453.088k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 29043 -u -b 5960.431k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 29044 -u -b 7509.753k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 29045 -u -b 4658.366k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 29046 -u -b 7376.847k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 29047 -u -b 4205.056k -w 256k -t 30 &
sleep 0.4