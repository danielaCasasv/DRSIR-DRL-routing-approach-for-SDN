 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 12002 -u -b 1098.319k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 12003 -u -b 5360.828k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 12004 -u -b 379.869k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 12005 -u -b 2384.752k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 12006 -u -b 5159.514k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 12007 -u -b 331.326k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 12008 -u -b 5112.026k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 12009 -u -b 2783.788k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 12011 -u -b 2783.101k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 12013 -u -b 3369.238k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 12014 -u -b 3907.791k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 12015 -u -b 3412.599k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 12017 -u -b 848.167k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 12018 -u -b 4011.765k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 12021 -u -b 5358.362k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 12023 -u -b 4654.806k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 12024 -u -b 1936.885k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 12025 -u -b 1304.480k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 12026 -u -b 502.614k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 12027 -u -b 4300.206k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 12030 -u -b 1893.316k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 12031 -u -b 4644.375k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 12033 -u -b 4927.753k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 12034 -u -b 3213.444k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 12035 -u -b 177.464k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 12036 -u -b 2609.644k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 12038 -u -b 4670.451k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 12039 -u -b 3982.016k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 12040 -u -b 2270.372k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 12045 -u -b 2477.752k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 12046 -u -b 3923.694k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 12047 -u -b 2236.640k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 12048 -u -b 3146.148k -w 256k -t 30 &
sleep 0.4