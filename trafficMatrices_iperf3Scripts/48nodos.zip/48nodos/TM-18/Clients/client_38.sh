 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 38002 -u -b 2466.382k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 38003 -u -b 12038.257k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 38004 -u -b 853.033k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 38005 -u -b 5355.190k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 38006 -u -b 11586.187k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 38007 -u -b 744.025k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 38008 -u -b 11479.548k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 38009 -u -b 6251.265k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 38012 -u -b 4670.451k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 38013 -u -b 7565.950k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 38014 -u -b 8775.322k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 38015 -u -b 7663.320k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 38016 -u -b 1552.362k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 38017 -u -b 1904.641k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 38020 -u -b 5333.632k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 38023 -u -b 10452.817k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 38026 -u -b 1128.668k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 38028 -u -b 10356.198k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 38029 -u -b 8780.808k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 38030 -u -b 4251.624k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 38032 -u -b 6856.837k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 38033 -u -b 11065.746k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 38034 -u -b 7216.099k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 38035 -u -b 398.511k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 38036 -u -b 5860.206k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 38037 -u -b 4446.468k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 38041 -u -b 541.176k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 38042 -u -b 7271.682k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 38044 -u -b 8969.778k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 38047 -u -b 5022.591k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 38048 -u -b 7064.979k -w 256k -t 30 &
sleep 0.4