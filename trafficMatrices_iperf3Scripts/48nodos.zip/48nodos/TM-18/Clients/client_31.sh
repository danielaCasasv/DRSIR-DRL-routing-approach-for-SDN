 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 31002 -u -b 2452.611k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 31003 -u -b 11971.045k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 31005 -u -b 5325.292k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 31006 -u -b 11521.500k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 31007 -u -b 739.871k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 31009 -u -b 6216.363k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 31010 -u -b 1787.454k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 31011 -u -b 6214.828k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 31012 -u -b 4644.375k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 31013 -u -b 7523.708k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 31016 -u -b 1543.695k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 31017 -u -b 1894.007k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 31018 -u -b 8958.507k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 31019 -u -b 6971.252k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 31020 -u -b 5303.854k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 31021 -u -b 11965.538k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 31022 -u -b 9367.601k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 31023 -u -b 10394.458k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 31024 -u -b 4325.179k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 31027 -u -b 9602.614k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 31028 -u -b 10298.378k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 31029 -u -b 8731.783k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 31030 -u -b 4227.887k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 31034 -u -b 7175.810k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 31035 -u -b 396.286k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 31036 -u -b 5827.488k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 31037 -u -b 4421.643k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 31039 -u -b 8892.077k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 31040 -u -b 5069.876k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 31041 -u -b 538.154k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 31042 -u -b 7231.083k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 31043 -u -b 7079.493k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 31044 -u -b 8919.699k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 31045 -u -b 5532.967k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 31047 -u -b 4994.549k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 31048 -u -b 7025.534k -w 256k -t 30 &
sleep 0.4