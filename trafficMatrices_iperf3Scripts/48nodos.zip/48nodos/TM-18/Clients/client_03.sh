 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 3001 -u -b 7732.856k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 3002 -u -b 2830.957k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 3005 -u -b 6146.785k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 3006 -u -b 13298.836k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 3007 -u -b 854.005k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 3008 -u -b 13176.433k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 3009 -u -b 7175.315k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 3010 -u -b 2063.191k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 3013 -u -b 8684.334k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 3014 -u -b 10072.473k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 3015 -u -b 8796.097k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 3016 -u -b 1781.829k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 3018 -u -b 10340.469k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 3020 -u -b 6122.040k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 3021 -u -b 13811.373k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 3022 -u -b 10812.672k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 3023 -u -b 11997.933k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 3024 -u -b 4992.393k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 3026 -u -b 1295.505k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 3027 -u -b 11083.938k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 3028 -u -b 11887.032k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 3029 -u -b 10078.770k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 3031 -u -b 11971.045k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 3032 -u -b 7870.402k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 3034 -u -b 8282.769k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 3036 -u -b 6726.451k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 3037 -u -b 5103.737k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 3039 -u -b 10263.792k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 3040 -u -b 5851.968k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 3042 -u -b 8346.569k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 3043 -u -b 8171.594k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 3044 -u -b 10295.674k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 3046 -u -b 10113.463k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 3047 -u -b 5765.021k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 3048 -u -b 8109.311k -w 256k -t 30 &
sleep 0.4