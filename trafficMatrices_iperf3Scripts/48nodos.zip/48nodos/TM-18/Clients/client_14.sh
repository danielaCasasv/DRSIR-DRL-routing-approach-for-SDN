 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.5 -p 14005 -u -b 4480.716k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 14006 -u -b 9694.224k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 14007 -u -b 622.529k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 14009 -u -b 5230.467k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 14011 -u -b 5229.175k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 14012 -u -b 3907.791k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 14013 -u -b 6330.470k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 14016 -u -b 1298.869k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 14017 -u -b 1593.623k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 14019 -u -b 5865.632k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 14021 -u -b 10067.840k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 14022 -u -b 7881.928k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 14023 -u -b 8745.928k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 14025 -u -b 2450.991k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 14027 -u -b 8079.669k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 14030 -u -b 3557.357k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 14031 -u -b 8726.328k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 14032 -u -b 5737.152k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 14033 -u -b 9258.769k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 14034 -u -b 6037.748k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 14035 -u -b 333.437k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 14037 -u -b 3720.383k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 14038 -u -b 8775.322k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 14039 -u -b 7481.821k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 14040 -u -b 4265.809k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 14041 -u -b 452.805k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 14042 -u -b 6084.255k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 14043 -u -b 5956.707k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 14044 -u -b 7505.061k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 14045 -u -b 4655.455k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 14046 -u -b 7372.238k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 14047 -u -b 4202.429k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 14048 -u -b 5911.305k -w 256k -t 30 &
sleep 0.4