 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 35001 -u -b 255.987k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 35002 -u -b 93.715k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 35003 -u -b 457.419k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 35005 -u -b 203.482k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 35006 -u -b 440.241k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 35010 -u -b 68.299k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 35012 -u -b 177.464k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 35014 -u -b 333.437k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 35015 -u -b 291.184k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 35016 -u -b 58.985k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 35017 -u -b 72.371k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 35018 -u -b 342.308k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 35019 -u -b 266.374k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 35021 -u -b 457.208k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 35022 -u -b 357.940k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 35023 -u -b 397.177k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 35025 -u -b 111.306k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 35026 -u -b 42.886k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 35027 -u -b 366.920k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 35029 -u -b 333.645k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 35030 -u -b 161.549k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 35031 -u -b 396.286k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 35032 -u -b 260.540k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 35034 -u -b 274.191k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 35037 -u -b 168.953k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 35038 -u -b 398.511k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 35039 -u -b 339.770k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 35041 -u -b 20.563k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 35043 -u -b 270.510k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 35044 -u -b 340.825k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 35046 -u -b 334.794k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 35047 -u -b 190.844k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 35048 -u -b 268.449k -w 256k -t 30 &
sleep 0.4