 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 23002 -u -b 2458.120k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 23003 -u -b 11997.933k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 23005 -u -b 5337.253k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 23009 -u -b 6230.326k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 23010 -u -b 1791.469k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 23011 -u -b 6228.787k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 23013 -u -b 7540.607k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 23014 -u -b 8745.928k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 23015 -u -b 7637.650k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 23016 -u -b 1547.162k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 23017 -u -b 1898.261k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 23018 -u -b 8978.629k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 23019 -u -b 6986.910k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 23020 -u -b 5315.767k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 23021 -u -b 11992.414k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 23022 -u -b 9388.642k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 23026 -u -b 1124.887k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 23027 -u -b 9624.183k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 23028 -u -b 10321.509k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 23029 -u -b 8751.396k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 23030 -u -b 4237.383k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 23032 -u -b 6833.869k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 23033 -u -b 11028.680k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 23034 -u -b 7191.928k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 23035 -u -b 397.177k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 23037 -u -b 4431.574k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 23038 -u -b 10452.817k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 23039 -u -b 8912.050k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 23041 -u -b 539.363k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 23042 -u -b 7247.325k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 23043 -u -b 7095.394k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 23044 -u -b 8939.733k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 23045 -u -b 5545.395k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 23046 -u -b 8781.519k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 23047 -u -b 5005.767k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 23048 -u -b 7041.314k -w 256k -t 30 &
sleep 0.4