 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 24001 -u -b 2793.907k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 24002 -u -b 1022.835k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 24003 -u -b 4992.393k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 24004 -u -b 353.762k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 24005 -u -b 2220.854k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 24006 -u -b 4804.915k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 24008 -u -b 4760.690k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 24009 -u -b 2592.466k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 24010 -u -b 745.438k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 24011 -u -b 2591.826k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 24012 -u -b 1936.885k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 24018 -u -b 3736.047k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 24021 -u -b 4990.096k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 24022 -u -b 3906.655k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 24023 -u -b 4334.894k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 24025 -u -b 1214.827k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 24026 -u -b 468.070k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 24027 -u -b 4004.665k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 24029 -u -b 3641.494k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 24030 -u -b 1763.194k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 24031 -u -b 4325.179k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 24032 -u -b 2843.603k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 24033 -u -b 4589.082k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 24034 -u -b 2992.593k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 24035 -u -b 165.267k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 24036 -u -b 2430.290k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 24037 -u -b 1843.997k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 24038 -u -b 4349.463k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 24040 -u -b 2114.336k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 24042 -u -b 3015.644k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 24043 -u -b 2952.425k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 24045 -u -b 2307.463k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 24046 -u -b 3654.029k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 24047 -u -b 2082.922k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 24048 -u -b 2929.921k -w 256k -t 30 &
sleep 0.4