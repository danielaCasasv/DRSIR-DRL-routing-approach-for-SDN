 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 42001 -u -b 4671.014k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 42003 -u -b 8346.569k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 42005 -u -b 3712.952k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 42007 -u -b 515.860k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 42008 -u -b 7959.195k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 42009 -u -b 4334.233k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 42010 -u -b 1246.266k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 42012 -u -b 3238.196k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 42013 -u -b 5245.753k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 42014 -u -b 6084.255k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 42017 -u -b 1320.558k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 42018 -u -b 6246.138k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 42019 -u -b 4860.564k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 42021 -u -b 8342.729k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 42022 -u -b 6531.370k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 42023 -u -b 7247.325k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 42024 -u -b 3015.644k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 42028 -u -b 7180.335k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 42029 -u -b 6088.059k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 42031 -u -b 7231.083k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 42032 -u -b 4754.099k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 42035 -u -b 276.303k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 42036 -u -b 4063.098k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 42037 -u -b 3082.901k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 42041 -u -b 375.217k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 42043 -u -b 4936.033k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 42044 -u -b 6219.079k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 42045 -u -b 3857.749k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 42047 -u -b 3482.348k -w 256k -t 30 &
sleep 0.4