 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 5001 -u -b 3719.744k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 5003 -u -b 6646.758k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 5004 -u -b 470.990k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 5006 -u -b 6397.154k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 5007 -u -b 410.803k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 5008 -u -b 6338.274k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 5009 -u -b 3451.550k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 5012 -u -b 2578.725k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 5013 -u -b 4177.435k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 5016 -u -b 857.115k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 5017 -u -b 1051.621k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 5018 -u -b 4974.088k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 5019 -u -b 3870.692k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 5021 -u -b 6643.700k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 5022 -u -b 5201.232k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 5023 -u -b 5771.379k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 5024 -u -b 2401.496k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 5025 -u -b 1617.393k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 5026 -u -b 623.178k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 5027 -u -b 5331.719k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 5028 -u -b 5718.033k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 5029 -u -b 4848.202k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 5031 -u -b 5758.445k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 5034 -u -b 3984.270k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 5035 -u -b 220.033k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 5036 -u -b 3235.632k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 5037 -u -b 2455.056k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 5039 -u -b 4937.203k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 5040 -u -b 2814.979k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 5041 -u -b 298.803k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 5042 -u -b 4014.959k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 5043 -u -b 3930.791k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 5044 -u -b 4952.540k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 5045 -u -b 3072.104k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 5046 -u -b 4864.891k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 5047 -u -b 2773.155k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 5048 -u -b 3900.831k -w 256k -t 30 &
sleep 0.4