 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 33001 -u -b 7686.327k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 33002 -u -b 2813.924k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 33004 -u -b 973.235k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 33005 -u -b 6109.799k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 33006 -u -b 13218.816k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 33007 -u -b 848.866k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 33008 -u -b 13097.150k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 33009 -u -b 7132.141k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 33010 -u -b 2050.777k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 33011 -u -b 7130.380k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 33012 -u -b 5328.572k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 33013 -u -b 8632.080k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 33014 -u -b 10011.867k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 33015 -u -b 8743.171k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 33016 -u -b 1771.108k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 33022 -u -b 10747.612k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 33023 -u -b 11925.741k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 33025 -u -b 3342.114k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 33027 -u -b 11017.246k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 33028 -u -b 11815.508k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 33029 -u -b 10018.126k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 33030 -u -b 4850.728k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 33034 -u -b 8232.932k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 33036 -u -b 6685.978k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 33037 -u -b 5073.027k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 33039 -u -b 10202.035k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 33041 -u -b 617.434k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 33044 -u -b 10233.725k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 33045 -u -b 6348.069k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 33046 -u -b 10052.610k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 33048 -u -b 8060.517k -w 256k -t 30 &
sleep 0.4