 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.5 -p 14005 -u -b 4845.173k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 14006 -u -b 10482.743k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 14007 -u -b 673.165k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 14009 -u -b 5655.907k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 14011 -u -b 5654.511k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 14012 -u -b 4225.647k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 14013 -u -b 6845.384k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 14016 -u -b 1404.518k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 14017 -u -b 1723.247k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 14019 -u -b 6342.737k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 14021 -u -b 10886.748k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 14022 -u -b 8523.036k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 14023 -u -b 9457.313k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 14025 -u -b 2650.352k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 14027 -u -b 8736.861k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 14030 -u -b 3846.709k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 14031 -u -b 9436.118k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 14032 -u -b 6203.806k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 14033 -u -b 10011.867k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 14034 -u -b 6528.853k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 14035 -u -b 360.558k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 14037 -u -b 4022.996k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 14038 -u -b 9489.097k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 14039 -u -b 8090.384k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 14040 -u -b 4612.785k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 14041 -u -b 489.635k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 14042 -u -b 6579.142k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 14043 -u -b 6441.219k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 14044 -u -b 8115.515k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 14045 -u -b 5034.125k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 14046 -u -b 7971.888k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 14047 -u -b 4544.250k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 14048 -u -b 6392.125k -w 256k -t 30 &
sleep 0.4