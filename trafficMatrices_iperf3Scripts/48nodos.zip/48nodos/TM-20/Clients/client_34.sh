 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 34001 -u -b 5012.341k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 34002 -u -b 1834.992k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 34004 -u -b 634.658k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 34006 -u -b 8620.141k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 34007 -u -b 553.555k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 34009 -u -b 4650.951k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 34010 -u -b 1337.335k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 34011 -u -b 4649.802k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 34014 -u -b 6528.853k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 34015 -u -b 5701.521k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 34018 -u -b 6702.564k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 34019 -u -b 5215.742k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 34021 -u -b 8952.361k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 34023 -u -b 7776.912k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 34024 -u -b 3236.007k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 34025 -u -b 2179.431k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 34027 -u -b 7184.472k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 34028 -u -b 7705.027k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 34029 -u -b 6532.934k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 34030 -u -b 3163.215k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 34032 -u -b 5101.497k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 34033 -u -b 8232.932k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 34036 -u -b 4360.003k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 34037 -u -b 3308.179k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 34040 -u -b 3793.173k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 34041 -u -b 402.636k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 34042 -u -b 5410.143k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 34045 -u -b 4139.648k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 34046 -u -b 6555.422k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 34047 -u -b 3736.815k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 34048 -u -b 5256.355k -w 256k -t 30 &
sleep 0.4