 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 21001 -u -b 8357.992k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 21004 -u -b 1058.281k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 21005 -u -b 6643.700k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 21007 -u -b 923.044k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 21008 -u -b 14241.636k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 21009 -u -b 7755.379k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 21012 -u -b 5794.206k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 21013 -u -b 9386.389k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 21014 -u -b 10886.748k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 21015 -u -b 9507.187k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 21016 -u -b 1925.875k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 21017 -u -b 2362.916k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 21019 -u -b 8697.159k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 21020 -u -b 6616.955k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 21022 -u -b 11686.785k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 21023 -u -b 12967.865k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 21025 -u -b 3634.163k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 21027 -u -b 11979.981k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 21028 -u -b 12847.998k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 21030 -u -b 5274.606k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 21031 -u -b 12938.803k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 21032 -u -b 8506.657k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 21033 -u -b 13728.270k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 21034 -u -b 8952.361k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 21037 -u -b 5516.331k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 21038 -u -b 13011.448k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 21039 -u -b 11093.533k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 21040 -u -b 6325.050k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 21041 -u -b 671.388k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 21042 -u -b 9021.318k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 21043 -u -b 8832.198k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 21044 -u -b 11127.992k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 21045 -u -b 6902.791k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 21046 -u -b 10931.051k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 21047 -u -b 6231.074k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 21048 -u -b 8764.880k -w 256k -t 30 &
sleep 0.4