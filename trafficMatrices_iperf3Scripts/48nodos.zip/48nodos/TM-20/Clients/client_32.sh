 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 32001 -u -b 4762.796k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 32003 -u -b 8510.572k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 32004 -u -b 603.061k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 32008 -u -b 8115.587k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 32010 -u -b 1270.754k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 32011 -u -b 4418.306k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 32013 -u -b 5348.828k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 32014 -u -b 6203.806k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 32015 -u -b 5417.664k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 32017 -u -b 1346.506k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 32018 -u -b 6368.869k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 32020 -u -b 3770.667k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 32023 -u -b 7389.729k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 32024 -u -b 3074.899k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 32025 -u -b 2070.925k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 32026 -u -b 797.923k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 32027 -u -b 6826.784k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 32029 -u -b 6207.684k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 32030 -u -b 3005.731k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 32031 -u -b 7373.168k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 32034 -u -b 5101.497k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 32035 -u -b 281.732k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 32036 -u -b 4142.934k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 32038 -u -b 7414.565k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 32039 -u -b 6321.642k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 32040 -u -b 3604.325k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 32041 -u -b 382.590k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 32044 -u -b 6341.279k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 32047 -u -b 3550.774k -w 256k -t 30 &
sleep 0.4