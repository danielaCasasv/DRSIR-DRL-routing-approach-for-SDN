 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 20001 -u -b 3704.770k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 20003 -u -b 6620.000k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 20004 -u -b 469.094k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 20005 -u -b 2944.892k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 20007 -u -b 409.149k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 20010 -u -b 988.464k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 20012 -u -b 2568.344k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 20013 -u -b 4160.618k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 20014 -u -b 4825.668k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 20015 -u -b 4214.163k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 20016 -u -b 853.665k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 20018 -u -b 4954.064k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 20021 -u -b 6616.955k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 20023 -u -b 5748.146k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 20024 -u -b 2391.829k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 20025 -u -b 1610.882k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 20027 -u -b 5310.256k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 20028 -u -b 5695.014k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 20029 -u -b 4828.685k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 20030 -u -b 2338.026k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 20032 -u -b 3770.667k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 20035 -u -b 219.147k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 20037 -u -b 2445.173k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 20039 -u -b 4917.328k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 20040 -u -b 2803.646k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 20041 -u -b 297.600k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 20043 -u -b 3914.967k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 20044 -u -b 4932.603k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 20045 -u -b 3059.737k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 20047 -u -b 2761.991k -w 256k -t 30 &
sleep 0.4