 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 4001 -u -b 592.521k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 4005 -u -b 470.990k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 4006 -u -b 1019.008k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 4007 -u -b 65.437k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 4009 -u -b 549.800k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 4010 -u -b 158.090k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 4011 -u -b 549.665k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 4013 -u -b 665.427k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 4016 -u -b 136.531k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 4017 -u -b 167.514k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 4020 -u -b 469.094k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 4022 -u -b 828.509k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 4023 -u -b 919.328k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 4025 -u -b 257.636k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 4026 -u -b 99.267k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 4029 -u -b 772.274k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 4030 -u -b 373.931k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 4031 -u -b 917.268k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 4032 -u -b 603.061k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 4033 -u -b 973.235k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 4035 -u -b 35.049k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 4036 -u -b 515.407k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 4037 -u -b 391.068k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 4038 -u -b 922.418k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 4039 -u -b 786.451k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 4040 -u -b 448.400k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 4041 -u -b 47.597k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 4043 -u -b 626.139k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 4045 -u -b 489.358k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 4047 -u -b 441.738k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 4048 -u -b 621.367k -w 256k -t 30 &
sleep 0.4