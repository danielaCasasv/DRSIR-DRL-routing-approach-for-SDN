 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 27001 -u -b 6707.477k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 27002 -u -b 2455.572k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 27004 -u -b 849.294k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 27007 -u -b 740.764k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 27008 -u -b 11429.234k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 27010 -u -b 1789.612k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 27011 -u -b 6222.329k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 27012 -u -b 4649.981k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 27013 -u -b 7532.789k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 27014 -u -b 8736.861k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 27015 -u -b 7629.732k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 27016 -u -b 1545.558k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 27019 -u -b 6979.666k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 27022 -u -b 9378.908k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 27023 -u -b 10407.004k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 27025 -u -b 2916.497k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 27026 -u -b 1123.721k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 27028 -u -b 10310.808k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 27029 -u -b 8742.323k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 27032 -u -b 6826.784k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 27033 -u -b 11017.246k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 27034 -u -b 7184.472k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 27035 -u -b 396.765k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 27037 -u -b 4426.980k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 27038 -u -b 10441.980k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 27039 -u -b 8902.810k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 27040 -u -b 5075.995k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 27041 -u -b 538.804k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 27042 -u -b 7239.811k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 27044 -u -b 8930.465k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 27045 -u -b 5539.646k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 27047 -u -b 5000.578k -w 256k -t 30 &
sleep 0.4