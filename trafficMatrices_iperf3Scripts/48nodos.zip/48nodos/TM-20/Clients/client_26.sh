 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 26001 -u -b 783.979k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 26002 -u -b 287.010k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 26003 -u -b 1400.880k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 26005 -u -b 623.178k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 26006 -u -b 1348.273k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 26007 -u -b 86.581k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 26008 -u -b 1335.864k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 26010 -u -b 209.172k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 26012 -u -b 543.496k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 26015 -u -b 891.773k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 26016 -u -b 180.647k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 26017 -u -b 221.641k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 26018 -u -b 1048.346k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 26020 -u -b 620.670k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 26024 -u -b 506.143k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 26029 -u -b 1021.814k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 26030 -u -b 494.757k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 26031 -u -b 1213.658k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 26034 -u -b 839.730k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 26035 -u -b 46.374k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 26036 -u -b 681.947k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 26037 -u -b 517.431k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 26038 -u -b 1220.472k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 26045 -u -b 647.481k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 26047 -u -b 584.474k -w 256k -t 30 &
sleep 0.4