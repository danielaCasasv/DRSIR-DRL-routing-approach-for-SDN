 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 28001 -u -b 7193.471k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 28002 -u -b 2633.492k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 28004 -u -b 910.830k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 28005 -u -b 5718.033k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 28007 -u -b 794.436k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 28008 -u -b 12257.347k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 28009 -u -b 6674.821k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 28012 -u -b 4986.898k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 28013 -u -b 8078.582k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 28015 -u -b 8182.549k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 28016 -u -b 1657.542k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 28017 -u -b 2033.691k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 28019 -u -b 7485.383k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 28020 -u -b 5695.014k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 28022 -u -b 10058.463k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 28023 -u -b 11161.050k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 28024 -u -b 4644.162k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 28025 -u -b 3127.814k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 28026 -u -b 1205.141k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 28027 -u -b 10310.808k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 28029 -u -b 9375.753k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 28030 -u -b 4539.694k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 28031 -u -b 11136.038k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 28032 -u -b 7321.423k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 28034 -u -b 7705.027k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 28035 -u -b 425.513k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 28037 -u -b 4747.739k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 28039 -u -b 9547.869k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 28040 -u -b 5443.780k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 28042 -u -b 7764.376k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 28044 -u -b 9577.527k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 28045 -u -b 5941.024k -w 256k -t 30 &
sleep 0.4