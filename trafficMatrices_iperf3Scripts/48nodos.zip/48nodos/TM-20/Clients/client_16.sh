 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 16001 -u -b 1078.279k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 16002 -u -b 394.752k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 16003 -u -b 1926.761k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 16005 -u -b 857.115k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 16006 -u -b 1854.406k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 16008 -u -b 1837.338k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 16010 -u -b 287.694k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 16012 -u -b 747.520k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 16013 -u -b 1210.954k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 16014 -u -b 1404.518k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 16017 -u -b 304.844k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 16018 -u -b 1441.888k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 16020 -u -b 853.665k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 16021 -u -b 1925.875k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 16022 -u -b 1507.732k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 16026 -u -b 180.647k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 16027 -u -b 1545.558k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 16030 -u -b 680.486k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 16031 -u -b 1669.257k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 16032 -u -b 1097.459k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 16033 -u -b 1771.108k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 16034 -u -b 1154.960k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 16035 -u -b 63.783k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 16036 -u -b 937.945k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 16037 -u -b 711.671k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 16038 -u -b 1678.629k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 16040 -u -b 816.006k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 16042 -u -b 1163.856k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 16044 -u -b 1435.642k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 16045 -u -b 890.541k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 16046 -u -b 1410.234k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 16047 -u -b 803.882k -w 256k -t 30 &
sleep 0.4