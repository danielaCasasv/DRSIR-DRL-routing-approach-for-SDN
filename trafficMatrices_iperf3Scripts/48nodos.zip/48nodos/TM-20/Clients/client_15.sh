 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 15001 -u -b 5322.983k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 15002 -u -b 1948.716k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 15003 -u -b 9511.563k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 15006 -u -b 9154.378k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 15007 -u -b 587.862k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 15008 -u -b 9070.120k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 15009 -u -b 4939.195k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 15010 -u -b 1420.217k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 15011 -u -b 4937.975k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 15012 -u -b 3690.176k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 15014 -u -b 6933.481k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 15016 -u -b 1226.539k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 15017 -u -b 1504.879k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 15018 -u -b 7117.959k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 15019 -u -b 5538.990k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 15020 -u -b 4214.163k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 15021 -u -b 9507.187k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 15022 -u -b 7443.003k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 15025 -u -b 2314.502k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 15027 -u -b 7629.732k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 15028 -u -b 8182.549k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 15030 -u -b 3359.257k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 15033 -u -b 8743.171k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 15035 -u -b 314.868k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 15037 -u -b 3513.205k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 15038 -u -b 8286.646k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 15039 -u -b 7065.177k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 15042 -u -b 5745.438k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 15043 -u -b 5624.993k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 15046 -u -b 6961.697k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 15047 -u -b 3968.406k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 15048 -u -b 5582.120k -w 256k -t 30 &
sleep 0.4