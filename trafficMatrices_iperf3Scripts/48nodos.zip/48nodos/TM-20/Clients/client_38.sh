 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 38002 -u -b 2666.994k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 38003 -u -b 13017.436k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 38004 -u -b 922.418k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 38005 -u -b 5790.776k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 38006 -u -b 12528.596k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 38007 -u -b 804.543k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 38008 -u -b 12413.282k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 38009 -u -b 6759.736k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 38012 -u -b 5050.340k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 38013 -u -b 8181.356k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 38014 -u -b 9489.097k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 38015 -u -b 8286.646k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 38016 -u -b 1678.629k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 38017 -u -b 2059.563k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 38020 -u -b 5767.465k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 38023 -u -b 11303.039k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 38026 -u -b 1220.472k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 38028 -u -b 11198.561k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 38029 -u -b 9495.030k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 38030 -u -b 4597.447k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 38032 -u -b 7414.565k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 38033 -u -b 11965.822k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 38034 -u -b 7803.049k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 38035 -u -b 430.926k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 38036 -u -b 6336.870k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 38037 -u -b 4808.139k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 38041 -u -b 585.194k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 38042 -u -b 7863.153k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 38044 -u -b 9699.371k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 38047 -u -b 5431.124k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 38048 -u -b 7639.637k -w 256k -t 30 &
sleep 0.4