 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 10001 -u -b 1248.546k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 10004 -u -b 158.090k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 10005 -u -b 992.459k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 10007 -u -b 137.888k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 10008 -u -b 2127.466k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 10009 -u -b 1158.526k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 10011 -u -b 1158.240k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 10012 -u -b 865.559k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 10013 -u -b 1402.172k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 10015 -u -b 1420.217k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 10016 -u -b 287.694k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 10018 -u -b 1669.571k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 10019 -u -b 1299.212k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 10020 -u -b 988.464k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 10021 -u -b 2229.983k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 10023 -u -b 1937.185k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 10024 -u -b 806.071k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 10025 -u -b 542.884k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 10026 -u -b 209.172k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 10027 -u -b 1789.612k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 10028 -u -b 1919.279k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 10029 -u -b 1627.317k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 10030 -u -b 787.939k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 10032 -u -b 1270.754k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 10033 -u -b 2050.777k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 10037 -u -b 824.049k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 10038 -u -b 1943.696k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 10039 -u -b 1657.191k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 10040 -u -b 944.858k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 10041 -u -b 100.294k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 10042 -u -b 1347.636k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 10044 -u -b 1662.339k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 10045 -u -b 1031.163k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 10046 -u -b 1632.919k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 10047 -u -b 930.820k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 10048 -u -b 1309.329k -w 256k -t 30 &
sleep 0.4