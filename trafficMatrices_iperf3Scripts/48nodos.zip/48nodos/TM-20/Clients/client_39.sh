 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 39001 -u -b 6211.163k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 39003 -u -b 11098.638k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 39004 -u -b 786.451k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 39005 -u -b 4937.203k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 39006 -u -b 10681.854k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 39007 -u -b 685.951k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 39008 -u -b 10583.538k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 39012 -u -b 4305.909k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 39013 -u -b 6975.407k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 39014 -u -b 8090.384k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 39016 -u -b 1431.196k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 39018 -u -b 8305.643k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 39021 -u -b 11093.533k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 39022 -u -b 8684.924k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 39023 -u -b 9636.947k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 39024 -u -b 4009.976k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 39026 -u -b 1040.572k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 39028 -u -b 9547.869k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 39031 -u -b 9615.350k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 39033 -u -b 10202.035k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 39034 -u -b 6652.863k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 39036 -u -b 5402.802k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 39037 -u -b 4099.409k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 39038 -u -b 9669.335k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 39040 -u -b 4700.401k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 39041 -u -b 498.936k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 39042 -u -b 6704.108k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 39044 -u -b 8269.663k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 39046 -u -b 8123.308k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 39047 -u -b 4630.564k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 39048 -u -b 6513.538k -w 256k -t 30 &
sleep 0.4