 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 41001 -u -b 375.904k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 41002 -u -b 137.616k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 41003 -u -b 671.697k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 41004 -u -b 47.597k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 41005 -u -b 298.803k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 41006 -u -b 646.473k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 41007 -u -b 41.514k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 41008 -u -b 640.523k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 41011 -u -b 348.715k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 41014 -u -b 489.635k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 41016 -u -b 86.617k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 41018 -u -b 502.663k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 41021 -u -b 671.388k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 41022 -u -b 525.617k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 41024 -u -b 242.686k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 41025 -u -b 163.448k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 41026 -u -b 62.976k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 41027 -u -b 538.804k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 41028 -u -b 577.843k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 41029 -u -b 489.941k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 41030 -u -b 237.227k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 41031 -u -b 581.927k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 41033 -u -b 617.434k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 41034 -u -b 402.636k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 41036 -u -b 326.981k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 41039 -u -b 498.936k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 41040 -u -b 284.471k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 41042 -u -b 405.737k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 41043 -u -b 397.231k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 41044 -u -b 500.485k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 41045 -u -b 310.455k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 41047 -u -b 280.245k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 41048 -u -b 394.204k -w 256k -t 30 &
sleep 0.4