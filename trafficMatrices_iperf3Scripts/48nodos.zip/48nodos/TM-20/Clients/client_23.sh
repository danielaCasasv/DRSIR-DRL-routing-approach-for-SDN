 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 23002 -u -b 2658.061k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 23003 -u -b 12973.833k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 23005 -u -b 5771.379k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 23009 -u -b 6737.094k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 23010 -u -b 1937.185k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 23011 -u -b 6735.430k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 23013 -u -b 8153.952k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 23014 -u -b 9457.313k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 23015 -u -b 8258.889k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 23016 -u -b 1673.007k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 23017 -u -b 2052.664k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 23018 -u -b 9708.941k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 23019 -u -b 7555.218k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 23020 -u -b 5748.146k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 23021 -u -b 12967.865k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 23022 -u -b 10152.304k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 23026 -u -b 1216.384k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 23027 -u -b 10407.004k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 23028 -u -b 11161.050k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 23029 -u -b 9463.225k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 23030 -u -b 4582.048k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 23032 -u -b 7389.729k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 23033 -u -b 11925.741k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 23034 -u -b 7776.912k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 23035 -u -b 429.482k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 23037 -u -b 4792.034k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 23038 -u -b 11303.039k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 23039 -u -b 9636.947k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 23041 -u -b 583.234k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 23042 -u -b 7836.815k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 23043 -u -b 7672.526k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 23044 -u -b 9666.882k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 23045 -u -b 5996.452k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 23046 -u -b 9495.799k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 23047 -u -b 5412.931k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 23048 -u -b 7614.047k -w 256k -t 30 &
sleep 0.4