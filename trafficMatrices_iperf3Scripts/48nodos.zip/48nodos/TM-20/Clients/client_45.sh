 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.3 -p 45003 -u -b 6905.968k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 45004 -u -b 489.358k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 45007 -u -b 426.823k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 45008 -u -b 6585.454k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 45010 -u -b 1031.163k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 45011 -u -b 3585.268k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 45012 -u -b 2679.290k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 45014 -u -b 5034.125k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 45015 -u -b 4396.205k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 45016 -u -b 890.541k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 45017 -u -b 1092.633k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 45018 -u -b 5168.067k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 45019 -u -b 4021.641k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 45021 -u -b 6902.791k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 45024 -u -b 2495.150k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 45025 -u -b 1680.468k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 45026 -u -b 647.481k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 45027 -u -b 5539.646k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 45028 -u -b 5941.024k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 45029 -u -b 5037.273k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 45030 -u -b 2439.023k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 45031 -u -b 5983.013k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 45032 -u -b 3933.551k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 45035 -u -b 228.613k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 45036 -u -b 3361.816k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 45037 -u -b 2550.798k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 45038 -u -b 6016.605k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 45039 -u -b 5129.745k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 45041 -u -b 310.455k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 45042 -u -b 4171.535k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 45044 -u -b 5145.679k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 45046 -u -b 5054.612k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 45047 -u -b 2881.302k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 45048 -u -b 4052.955k -w 256k -t 30 &
sleep 0.4