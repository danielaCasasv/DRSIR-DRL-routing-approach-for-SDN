 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 40001 -u -b 3541.335k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 40002 -u -b 1296.464k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 40003 -u -b 6327.961k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 40005 -u -b 2814.979k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 40006 -u -b 6090.328k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 40008 -u -b 6034.273k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 40009 -u -b 3286.004k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 40010 -u -b 944.858k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 40011 -u -b 3285.192k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 40012 -u -b 2455.042k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 40013 -u -b 3977.074k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 40014 -u -b 4612.785k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 40015 -u -b 4028.257k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 40017 -u -b 1001.183k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 40018 -u -b 4735.516k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 40019 -u -b 3685.042k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 40020 -u -b 2803.646k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 40021 -u -b 6325.050k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 40025 -u -b 1539.818k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 40026 -u -b 593.289k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 40027 -u -b 5075.995k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 40028 -u -b 5443.780k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 40029 -u -b 4615.669k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 40030 -u -b 2234.884k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 40032 -u -b 3604.325k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 40036 -u -b 3080.442k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 40038 -u -b 5513.034k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 40039 -u -b 4700.401k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 40041 -u -b 284.471k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 40042 -u -b 3822.391k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 40043 -u -b 3742.259k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 40045 -u -b 2924.757k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 40046 -u -b 4631.557k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 40047 -u -b 2640.146k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 40048 -u -b 3713.736k -w 256k -t 30 &
sleep 0.4