 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 42001 -u -b 5050.950k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 42003 -u -b 9025.470k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 42005 -u -b 4014.959k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 42007 -u -b 557.819k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 42008 -u -b 8606.588k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 42009 -u -b 4686.775k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 42010 -u -b 1347.636k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 42012 -u -b 3501.588k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 42013 -u -b 5672.437k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 42014 -u -b 6579.142k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 42017 -u -b 1427.971k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 42018 -u -b 6754.192k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 42019 -u -b 5255.917k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 42021 -u -b 9021.318k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 42022 -u -b 7062.625k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 42023 -u -b 7836.815k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 42024 -u -b 3260.933k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 42028 -u -b 7764.376k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 42029 -u -b 6583.255k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 42031 -u -b 7819.252k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 42032 -u -b 5140.792k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 42035 -u -b 298.777k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 42036 -u -b 4393.586k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 42037 -u -b 3333.661k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 42041 -u -b 405.737k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 42043 -u -b 5337.525k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 42044 -u -b 6724.933k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 42045 -u -b 4171.535k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 42047 -u -b 3765.599k -w 256k -t 30 &
sleep 0.4