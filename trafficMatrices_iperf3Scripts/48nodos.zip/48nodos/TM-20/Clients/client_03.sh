 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 3001 -u -b 8361.838k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 3002 -u -b 3061.225k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 3005 -u -b 6646.758k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 3006 -u -b 14380.549k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 3007 -u -b 923.469k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 3008 -u -b 14248.190k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 3009 -u -b 7758.948k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 3010 -u -b 2231.009k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 3013 -u -b 9390.709k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 3014 -u -b 10891.758k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 3015 -u -b 9511.563k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 3016 -u -b 1926.761k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 3018 -u -b 11181.553k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 3020 -u -b 6620.000k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 3021 -u -b 14934.776k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 3022 -u -b 11692.163k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 3023 -u -b 12973.833k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 3024 -u -b 5398.469k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 3026 -u -b 1400.880k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 3027 -u -b 11985.494k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 3028 -u -b 12853.911k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 3029 -u -b 10898.567k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 3031 -u -b 12944.758k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 3032 -u -b 8510.572k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 3034 -u -b 8956.481k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 3036 -u -b 7273.574k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 3037 -u -b 5518.869k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 3039 -u -b 11098.638k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 3040 -u -b 6327.961k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 3042 -u -b 9025.470k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 3043 -u -b 8836.263k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 3044 -u -b 11133.114k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 3046 -u -b 10936.082k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 3047 -u -b 6233.942k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 3048 -u -b 8768.914k -w 256k -t 30 &
sleep 0.4