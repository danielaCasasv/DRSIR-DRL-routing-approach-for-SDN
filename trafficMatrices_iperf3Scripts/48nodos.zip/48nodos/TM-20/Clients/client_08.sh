 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 8002 -u -b 2919.150k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 8003 -u -b 14248.190k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 8004 -u -b 1009.629k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 8005 -u -b 6338.274k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 8006 -u -b 13713.132k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 8007 -u -b 880.609k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 8010 -u -b 2127.466k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 8011 -u -b 7397.019k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 8013 -u -b 8954.876k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 8014 -u -b 10386.259k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 8015 -u -b 9070.120k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 8016 -u -b 1837.338k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 8017 -u -b 2254.287k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 8018 -u -b 10662.604k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 8019 -u -b 8297.331k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 8020 -u -b 6312.759k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 8021 -u -b 14241.636k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 8022 -u -b 11149.517k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 8023 -u -b 12371.703k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 8024 -u -b 5147.920k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 8028 -u -b 12257.347k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 8029 -u -b 10392.753k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 8033 -u -b 13097.150k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 8034 -u -b 8540.801k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 8035 -u -b 471.669k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 8036 -u -b 6935.999k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 8038 -u -b 12413.282k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 8039 -u -b 10583.538k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 8040 -u -b 6034.273k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 8042 -u -b 8606.588k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 8043 -u -b 8426.162k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 8046 -u -b 10428.526k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 8047 -u -b 5944.618k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 8048 -u -b 8361.938k -w 256k -t 30 &
sleep 0.4