 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 46001 -u -b 6120.191k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 46002 -u -b 2240.570k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 46003 -u -b 10936.082k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 46006 -u -b 10525.402k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 46007 -u -b 675.905k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 46008 -u -b 10428.526k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 46009 -u -b 5678.924k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 46010 -u -b 1632.919k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 46012 -u -b 4242.843k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 46014 -u -b 7971.888k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 46015 -u -b 6961.697k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 46017 -u -b 1730.260k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 46018 -u -b 8183.995k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 46019 -u -b 6368.549k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 46020 -u -b 4845.306k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 46022 -u -b 8557.720k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 46024 -u -b 3951.244k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 46027 -u -b 8772.415k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 46029 -u -b 7976.872k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 46030 -u -b 3862.363k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 46031 -u -b 9474.519k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 46033 -u -b 10052.610k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 46035 -u -b 362.025k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 46036 -u -b 5323.669k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 46038 -u -b 9527.713k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 46040 -u -b 4631.557k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 46041 -u -b 491.628k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 46044 -u -b 8148.541k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 46045 -u -b 5054.612k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 46047 -u -b 4562.743k -w 256k -t 30 &
sleep 0.4