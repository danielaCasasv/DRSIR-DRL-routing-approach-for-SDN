 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 47001 -u -b 3488.719k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 47002 -u -b 1277.202k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 47004 -u -b 441.738k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 47005 -u -b 2773.155k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 47006 -u -b 5999.840k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 47008 -u -b 5944.618k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 47010 -u -b 930.820k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 47011 -u -b 3236.382k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 47012 -u -b 2418.566k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 47013 -u -b 3917.984k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 47014 -u -b 4544.250k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 47017 -u -b 986.308k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 47020 -u -b 2761.991k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 47021 -u -b 6231.074k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 47023 -u -b 5412.931k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 47024 -u -b 2252.344k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 47025 -u -b 1516.940k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 47026 -u -b 584.474k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 47027 -u -b 5000.578k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 47028 -u -b 5362.898k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 47029 -u -b 4547.091k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 47030 -u -b 2201.679k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 47031 -u -b 5400.801k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 47032 -u -b 3550.774k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 47033 -u -b 5730.333k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 47037 -u -b 2302.578k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 47038 -u -b 5431.124k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 47039 -u -b 4630.564k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 47040 -u -b 2640.146k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 47041 -u -b 280.245k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 47043 -u -b 3686.658k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 47044 -u -b 4644.948k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 47045 -u -b 2881.302k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 47046 -u -b 4562.743k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 47048 -u -b 3658.559k -w 256k -t 30 &
sleep 0.4