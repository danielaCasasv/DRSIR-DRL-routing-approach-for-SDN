 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 31002 -u -b 2652.104k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 31003 -u -b 12944.758k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 31005 -u -b 5758.445k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 31006 -u -b 12458.647k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 31007 -u -b 800.051k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 31009 -u -b 6721.996k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 31010 -u -b 1932.844k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 31011 -u -b 6720.336k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 31012 -u -b 5022.144k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 31013 -u -b 8135.678k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 31016 -u -b 1669.257k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 31017 -u -b 2048.064k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 31018 -u -b 9687.183k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 31019 -u -b 7538.286k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 31020 -u -b 5735.264k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 31021 -u -b 12938.803k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 31022 -u -b 10129.553k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 31023 -u -b 11239.932k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 31024 -u -b 4676.985k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 31027 -u -b 10383.681k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 31028 -u -b 11136.038k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 31029 -u -b 9442.018k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 31030 -u -b 4571.779k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 31034 -u -b 7759.483k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 31035 -u -b 428.520k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 31036 -u -b 6301.490k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 31037 -u -b 4781.295k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 31039 -u -b 9615.350k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 31040 -u -b 5482.254k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 31041 -u -b 581.927k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 31042 -u -b 7819.252k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 31043 -u -b 7655.332k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 31044 -u -b 9645.218k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 31045 -u -b 5983.013k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 31047 -u -b 5400.801k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 31048 -u -b 7596.983k -w 256k -t 30 &
sleep 0.4