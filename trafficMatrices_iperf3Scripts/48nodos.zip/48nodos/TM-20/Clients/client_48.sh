 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 48001 -u -b 4907.372k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 48002 -u -b 1796.563k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 48004 -u -b 621.367k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 48006 -u -b 8439.617k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 48007 -u -b 541.963k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 48009 -u -b 4553.550k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 48010 -u -b 1309.329k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 48011 -u -b 4552.425k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 48016 -u -b 1130.772k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 48017 -u -b 1387.380k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 48019 -u -b 5106.514k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 48020 -u -b 3885.127k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 48021 -u -b 8764.880k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 48023 -u -b 7614.047k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 48024 -u -b 3168.238k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 48025 -u -b 2133.789k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 48026 -u -b 822.145k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 48027 -u -b 7034.014k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 48028 -u -b 7543.668k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 48029 -u -b 6396.121k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 48030 -u -b 3096.971k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 48032 -u -b 4994.661k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 48033 -u -b 8060.517k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 48034 -u -b 5256.355k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 48035 -u -b 290.284k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 48037 -u -b 3238.899k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 48039 -u -b 6513.538k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 48041 -u -b 394.204k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 48043 -u -b 5185.801k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 48046 -u -b 6418.137k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 48047 -u -b 3658.559k -w 256k -t 30 &
sleep 0.4