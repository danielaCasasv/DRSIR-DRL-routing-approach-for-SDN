 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 1002 -u -b 1713.162k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 1003 -u -b 8361.838k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 1004 -u -b 592.521k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 1005 -u -b 3719.744k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 1006 -u -b 8047.828k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 1007 -u -b 516.803k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 1008 -u -b 7973.756k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 1009 -u -b 4342.162k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 1010 -u -b 1248.546k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 1011 -u -b 4341.090k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 1013 -u -b 5255.350k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 1014 -u -b 6095.386k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 1015 -u -b 5322.983k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 1018 -u -b 6257.565k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 1019 -u -b 4869.456k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 1020 -u -b 3704.770k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 1023 -u -b 7260.584k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 1024 -u -b 3021.161k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 1026 -u -b 783.979k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 1028 -u -b 7193.471k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 1029 -u -b 6099.197k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 1030 -u -b 2953.201k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 1031 -u -b 7244.312k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 1032 -u -b 4762.796k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 1033 -u -b 7686.327k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 1036 -u -b 4070.531k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 1037 -u -b 3088.541k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 1038 -u -b 7284.985k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 1040 -u -b 3541.335k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 1043 -u -b 4945.063k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 1044 -u -b 6230.457k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 1045 -u -b 3864.807k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 1046 -u -b 6120.191k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 1048 -u -b 4907.372k -w 256k -t 30 &
sleep 0.4