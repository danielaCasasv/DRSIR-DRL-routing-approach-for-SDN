 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 36001 -u -b 4070.531k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 36002 -u -b 1490.200k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 36003 -u -b 7273.574k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 36004 -u -b 515.407k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 36005 -u -b 3235.632k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 36006 -u -b 7000.431k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 36007 -u -b 449.543k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 36008 -u -b 6935.999k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 36010 -u -b 1086.052k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 36011 -u -b 3776.112k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 36014 -u -b 5302.093k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 36015 -u -b 4630.215k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 36018 -u -b 5443.164k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 36021 -u -b 7270.228k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 36022 -u -b 5691.729k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 36023 -u -b 6315.644k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 36024 -u -b 2627.967k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 36025 -u -b 1769.919k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 36026 -u -b 681.947k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 36027 -u -b 5834.522k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 36029 -u -b 5305.407k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 36030 -u -b 2568.852k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 36031 -u -b 6301.490k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 36032 -u -b 4142.934k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 36033 -u -b 6685.978k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 36034 -u -b 4360.003k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 36035 -u -b 240.783k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 36038 -u -b 6336.870k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 36039 -u -b 5402.802k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 36040 -u -b 3080.442k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 36041 -u -b 326.981k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 36042 -u -b 4393.586k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 36043 -u -b 4301.480k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 36044 -u -b 5419.584k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 36046 -u -b 5323.669k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 36047 -u -b 3034.674k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 36048 -u -b 4268.695k -w 256k -t 30 &
sleep 0.4