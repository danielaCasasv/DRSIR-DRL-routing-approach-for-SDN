 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 30001 -u -b 2953.201k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 30002 -u -b 1081.151k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 30003 -u -b 5277.033k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 30005 -u -b 2347.476k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 30007 -u -b 326.147k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 30008 -u -b 5032.120k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 30011 -u -b 2739.598k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 30012 -u -b 2047.317k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 30014 -u -b 3846.709k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 30016 -u -b 680.486k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 30017 -u -b 834.910k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 30022 -u -b 4129.393k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 30023 -u -b 4582.048k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 30024 -u -b 1906.610k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 30025 -u -b 1284.090k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 30026 -u -b 494.757k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 30027 -u -b 4232.990k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 30028 -u -b 4539.694k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 30029 -u -b 3849.113k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 30033 -u -b 4850.728k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 30034 -u -b 3163.215k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 30036 -u -b 2568.852k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 30037 -u -b 1949.133k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 30038 -u -b 4597.447k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 30040 -u -b 2234.884k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 30041 -u -b 237.227k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 30042 -u -b 3187.580k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 30043 -u -b 3120.757k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 30044 -u -b 3931.950k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 30045 -u -b 2439.023k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 30047 -u -b 2201.679k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 30048 -u -b 3096.971k -w 256k -t 30 &
sleep 0.4