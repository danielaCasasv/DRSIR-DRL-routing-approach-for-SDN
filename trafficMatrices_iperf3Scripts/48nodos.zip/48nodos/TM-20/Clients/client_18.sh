 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.3 -p 18003 -u -b 11181.553k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 18004 -u -b 792.327k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 18005 -u -b 4974.088k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 18006 -u -b 10761.655k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 18007 -u -b 691.076k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 18008 -u -b 10662.604k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 18009 -u -b 5806.393k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 18010 -u -b 1669.571k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 18011 -u -b 5804.959k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 18013 -u -b 7027.518k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 18014 -u -b 8150.825k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 18015 -u -b 7117.959k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 18017 -u -b 1769.097k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 18020 -u -b 4954.064k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 18021 -u -b 11176.409k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 18022 -u -b 8749.806k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 18024 -u -b 4039.933k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 18025 -u -b 2720.870k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 18028 -u -b 9619.198k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 18029 -u -b 8155.921k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 18031 -u -b 9687.183k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 18033 -u -b 10278.251k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 18035 -u -b 370.151k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 18039 -u -b 8305.643k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 18040 -u -b 4735.516k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 18041 -u -b 502.663k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 18043 -u -b 6612.599k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 18044 -u -b 8331.443k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 18046 -u -b 8183.995k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 18048 -u -b 6562.199k -w 256k -t 30 &
sleep 0.4