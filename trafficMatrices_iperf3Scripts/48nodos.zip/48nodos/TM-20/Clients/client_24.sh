 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 24001 -u -b 3021.161k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 24002 -u -b 1106.031k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 24003 -u -b 5398.469k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 24004 -u -b 382.536k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 24005 -u -b 2401.496k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 24006 -u -b 5195.741k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 24008 -u -b 5147.920k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 24009 -u -b 2803.334k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 24010 -u -b 806.071k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 24011 -u -b 2802.642k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 24012 -u -b 2094.430k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 24018 -u -b 4039.933k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 24021 -u -b 5395.985k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 24022 -u -b 4224.418k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 24023 -u -b 4687.490k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 24025 -u -b 1313.640k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 24026 -u -b 506.143k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 24027 -u -b 4330.400k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 24029 -u -b 3937.689k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 24030 -u -b 1906.610k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 24031 -u -b 4676.985k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 24032 -u -b 3074.899k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 24033 -u -b 4962.353k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 24034 -u -b 3236.007k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 24035 -u -b 178.710k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 24036 -u -b 2627.967k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 24037 -u -b 1993.986k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 24038 -u -b 4703.244k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 24040 -u -b 2286.314k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 24042 -u -b 3260.933k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 24043 -u -b 3192.572k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 24045 -u -b 2495.150k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 24046 -u -b 3951.244k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 24047 -u -b 2252.344k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 24048 -u -b 3168.238k -w 256k -t 30 &
sleep 0.4