 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 2001 -u -b 1713.162k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 2005 -u -b 1361.779k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 2010 -u -b 457.086k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 2011 -u -b 1589.250k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 2012 -u -b 1187.655k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 2013 -u -b 1923.956k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 2014 -u -b 2231.488k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 2015 -u -b 1948.716k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 2017 -u -b 484.334k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 2018 -u -b 2290.861k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 2019 -u -b 1782.682k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 2023 -u -b 2658.061k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 2025 -u -b 744.905k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 2026 -u -b 287.010k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 2027 -u -b 2455.572k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 2028 -u -b 2633.492k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 2029 -u -b 2232.884k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 2030 -u -b 1081.151k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 2031 -u -b 2652.104k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 2036 -u -b 1490.200k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 2037 -u -b 1130.698k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 2039 -u -b 2273.874k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 2041 -u -b 137.616k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 2042 -u -b 1849.126k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 2043 -u -b 1810.361k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 2044 -u -b 2280.937k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 2046 -u -b 2240.570k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 2047 -u -b 1277.202k -w 256k -t 30 &
sleep 0.4