 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 9001 -u -b 4342.162k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 9002 -u -b 1589.643k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 9004 -u -b 549.800k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 9006 -u -b 7467.578k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 9007 -u -b 479.542k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 9008 -u -b 7398.846k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 9010 -u -b 1158.526k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 9011 -u -b 4028.097k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 9012 -u -b 3010.219k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 9013 -u -b 4876.438k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 9014 -u -b 5655.907k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 9015 -u -b 4939.195k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 9018 -u -b 5806.393k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 9020 -u -b 3437.655k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 9021 -u -b 7755.379k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 9022 -u -b 6071.544k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 9023 -u -b 6737.094k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 9024 -u -b 2803.334k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 9026 -u -b 727.454k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 9028 -u -b 6674.821k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 9029 -u -b 5659.443k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 9030 -u -b 2740.275k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 9031 -u -b 6721.996k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 9033 -u -b 7132.141k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 9034 -u -b 4650.951k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 9035 -u -b 256.850k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 9036 -u -b 3777.045k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 9037 -u -b 2865.856k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 9038 -u -b 6759.736k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 9039 -u -b 5763.337k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 9040 -u -b 3286.004k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 9041 -u -b 348.801k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 9043 -u -b 4588.523k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 9045 -u -b 3586.153k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 9047 -u -b 3237.182k -w 256k -t 30 &
sleep 0.4