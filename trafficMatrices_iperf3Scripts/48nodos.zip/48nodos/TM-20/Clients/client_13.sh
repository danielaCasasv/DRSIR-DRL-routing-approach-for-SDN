 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 13001 -u -b 5255.350k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 13003 -u -b 9390.709k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 13005 -u -b 4177.435k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 13006 -u -b 9038.062k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 13008 -u -b 8954.876k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 13009 -u -b 4876.438k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 13010 -u -b 1402.172k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 13011 -u -b 4875.233k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 13012 -u -b 3643.289k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 13015 -u -b 5977.942k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 13016 -u -b 1210.954k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 13017 -u -b 1485.758k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 13018 -u -b 7027.518k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 13019 -u -b 5468.612k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 13021 -u -b 9386.389k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 13023 -u -b 8153.952k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 13024 -u -b 3392.895k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 13025 -u -b 2285.094k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 13026 -u -b 880.442k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 13027 -u -b 7532.789k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 13029 -u -b 6849.664k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 13030 -u -b 3316.574k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 13031 -u -b 8135.678k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 13032 -u -b 5348.828k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 13033 -u -b 8632.080k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 13034 -u -b 5629.078k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 13035 -u -b 310.868k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 13037 -u -b 3468.566k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 13040 -u -b 3977.074k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 13041 -u -b 422.156k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 13043 -u -b 5553.522k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 13045 -u -b 4340.347k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 13047 -u -b 3917.984k -w 256k -t 30 &
sleep 0.4