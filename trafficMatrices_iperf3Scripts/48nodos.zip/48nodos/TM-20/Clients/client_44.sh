 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 44001 -u -b 6230.457k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 44003 -u -b 11133.114k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 44005 -u -b 4952.540k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 44008 -u -b 10616.413k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 44010 -u -b 1662.339k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 44014 -u -b 8115.515k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 44015 -u -b 7087.123k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 44016 -u -b 1435.642k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 44018 -u -b 8331.443k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 44019 -u -b 6483.289k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 44020 -u -b 4932.603k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 44022 -u -b 8711.902k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 44023 -u -b 9666.882k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 44024 -u -b 4022.432k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 44025 -u -b 2709.083k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 44026 -u -b 1043.804k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 44030 -u -b 3931.950k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 44031 -u -b 9645.218k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 44032 -u -b 6341.279k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 44033 -u -b 10233.725k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 44034 -u -b 6673.529k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 44035 -u -b 368.548k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 44036 -u -b 5419.584k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 44037 -u -b 4112.143k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 44039 -u -b 8269.663k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 44040 -u -b 4715.002k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 44042 -u -b 6724.933k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 44043 -u -b 6583.953k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 44045 -u -b 5145.679k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 44046 -u -b 8148.541k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 44047 -u -b 4644.948k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 44048 -u -b 6533.771k -w 256k -t 30 &
sleep 0.4