 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 17001 -u -b 1322.974k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 17002 -u -b 484.334k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 17003 -u -b 2364.003k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 17004 -u -b 167.514k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 17005 -u -b 1051.621k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 17006 -u -b 2275.229k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 17007 -u -b 146.107k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 17010 -u -b 352.981k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 17011 -u -b 1227.284k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 17012 -u -b 917.156k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 17013 -u -b 1485.758k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 17014 -u -b 1723.247k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 17015 -u -b 1504.879k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 17018 -u -b 1769.097k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 17019 -u -b 1376.660k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 17020 -u -b 1047.388k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 17021 -u -b 2362.916k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 17022 -u -b 1849.884k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 17023 -u -b 2052.664k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 17025 -u -b 575.246k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 17026 -u -b 221.641k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 17027 -u -b 1896.293k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 17030 -u -b 834.910k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 17032 -u -b 1346.506k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 17033 -u -b 2173.027k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 17036 -u -b 1150.794k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 17038 -u -b 2059.563k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 17039 -u -b 1755.979k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 17041 -u -b 106.273k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 17042 -u -b 1427.971k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 17044 -u -b 1761.433k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 17045 -u -b 1092.633k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 17046 -u -b 1730.260k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 17047 -u -b 986.308k -w 256k -t 30 &
sleep 0.4