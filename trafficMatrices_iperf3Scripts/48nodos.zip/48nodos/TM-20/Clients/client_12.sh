 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 12002 -u -b 1187.655k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 12003 -u -b 5796.872k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 12004 -u -b 410.767k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 12005 -u -b 2578.725k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 12006 -u -b 5579.184k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 12007 -u -b 358.276k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 12008 -u -b 5527.833k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 12009 -u -b 3010.219k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 12011 -u -b 3009.475k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 12013 -u -b 3643.289k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 12014 -u -b 4225.647k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 12015 -u -b 3690.176k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 12017 -u -b 917.156k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 12018 -u -b 4338.077k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 12021 -u -b 5794.206k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 12023 -u -b 5033.424k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 12024 -u -b 2094.430k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 12025 -u -b 1410.585k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 12026 -u -b 543.496k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 12027 -u -b 4649.981k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 12030 -u -b 2047.317k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 12031 -u -b 5022.144k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 12033 -u -b 5328.572k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 12034 -u -b 3474.822k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 12035 -u -b 191.898k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 12036 -u -b 2821.909k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 12038 -u -b 5050.340k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 12039 -u -b 4305.909k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 12040 -u -b 2455.042k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 12045 -u -b 2679.290k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 12046 -u -b 4242.843k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 12047 -u -b 2418.566k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 12048 -u -b 3402.052k -w 256k -t 30 &
sleep 0.4