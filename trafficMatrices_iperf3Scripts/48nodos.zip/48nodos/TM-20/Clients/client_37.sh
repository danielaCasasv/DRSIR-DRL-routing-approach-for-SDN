 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 37001 -u -b 3088.541k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 37002 -u -b 1130.698k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 37003 -u -b 5518.869k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 37004 -u -b 391.068k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 37006 -u -b 5311.621k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 37007 -u -b 341.094k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 37008 -u -b 5262.732k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 37009 -u -b 2865.856k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 37010 -u -b 824.049k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 37011 -u -b 2865.149k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 37012 -u -b 2141.141k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 37013 -u -b 3468.566k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 37015 -u -b 3513.205k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 37017 -u -b 873.172k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 37018 -u -b 4130.035k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 37019 -u -b 3213.874k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 37021 -u -b 5516.331k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 37022 -u -b 4318.634k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 37024 -u -b 1993.986k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 37025 -u -b 1342.937k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 37027 -u -b 4426.980k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 37028 -u -b 4747.739k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 37031 -u -b 4781.295k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 37032 -u -b 3143.477k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 37033 -u -b 5073.027k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 37034 -u -b 3308.179k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 37035 -u -b 182.695k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 37039 -u -b 4099.409k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 37040 -u -b 2337.305k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 37042 -u -b 3333.661k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 37043 -u -b 3263.775k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 37044 -u -b 4112.143k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 37045 -u -b 2550.798k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 37047 -u -b 2302.578k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 37048 -u -b 3238.899k -w 256k -t 30 &
sleep 0.4