 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 19001 -u -b 4869.456k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 19002 -u -b 1782.682k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 19003 -u -b 8701.162k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 19005 -u -b 3870.692k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 19006 -u -b 8374.409k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 19007 -u -b 537.775k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 19008 -u -b 8297.331k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 19010 -u -b 1299.212k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 19012 -u -b 3375.767k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 19013 -u -b 5468.612k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 19014 -u -b 6342.737k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 19015 -u -b 5538.990k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 19016 -u -b 1122.036k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 19017 -u -b 1376.660k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 19018 -u -b 6511.497k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 19020 -u -b 3855.109k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 19022 -u -b 6808.847k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 19023 -u -b 7555.218k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 19025 -u -b 2117.302k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 19026 -u -b 815.792k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 19027 -u -b 6979.666k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 19028 -u -b 7485.383k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 19032 -u -b 4956.070k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 19033 -u -b 7998.238k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 19034 -u -b 5215.742k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 19035 -u -b 288.041k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 19036 -u -b 4235.713k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 19037 -u -b 3213.874k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 19039 -u -b 6463.212k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 19041 -u -b 391.158k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 19042 -u -b 5255.917k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 19043 -u -b 5145.734k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 19044 -u -b 6483.289k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 19045 -u -b 4021.641k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 19046 -u -b 6368.549k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 19047 -u -b 3630.291k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 19048 -u -b 5106.514k -w 256k -t 30 &
sleep 0.4