 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 6002 -u -b 2946.267k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 6003 -u -b 14380.549k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 6004 -u -b 1019.008k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 6005 -u -b 6397.154k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 6007 -u -b 888.790k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 6009 -u -b 7467.578k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 6010 -u -b 2147.229k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 6012 -u -b 5579.184k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 6014 -u -b 10482.743k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 6015 -u -b 9154.378k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 6016 -u -b 1854.406k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 6017 -u -b 2275.229k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 6019 -u -b 8374.409k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 6020 -u -b 6371.401k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 6022 -u -b 11253.091k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 6023 -u -b 12486.630k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 6028 -u -b 12371.212k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 6031 -u -b 12458.647k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 6032 -u -b 8190.977k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 6036 -u -b 7000.431k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 6037 -u -b 5311.621k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 6041 -u -b 646.473k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 6042 -u -b 8686.539k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 6043 -u -b 8504.437k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 6045 -u -b 6646.630k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 6046 -u -b 10525.402k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 6047 -u -b 5999.840k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 6048 -u -b 8439.617k -w 256k -t 30 &
sleep 0.4