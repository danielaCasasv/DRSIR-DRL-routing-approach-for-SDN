 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 7001 -u -b 516.803k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 7002 -u -b 189.199k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 7003 -u -b 923.469k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 7004 -u -b 65.437k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 7008 -u -b 880.609k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 7009 -u -b 479.542k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 7010 -u -b 137.888k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 7011 -u -b 479.423k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 7012 -u -b 358.276k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 7013 -u -b 580.393k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 7014 -u -b 673.165k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 7015 -u -b 587.862k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 7016 -u -b 119.083k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 7020 -u -b 409.149k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 7022 -u -b 722.634k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 7023 -u -b 801.848k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 7024 -u -b 333.652k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 7025 -u -b 224.713k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 7026 -u -b 86.581k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 7027 -u -b 740.764k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 7028 -u -b 794.436k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 7029 -u -b 673.586k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 7030 -u -b 326.147k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 7034 -u -b 553.555k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 7038 -u -b 804.543k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 7039 -u -b 685.951k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 7040 -u -b 391.100k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 7041 -u -b 41.514k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 7043 -u -b 546.125k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 7044 -u -b 688.082k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 7045 -u -b 426.823k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 7046 -u -b 675.905k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 7047 -u -b 385.289k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 7048 -u -b 541.963k -w 256k -t 30 &
sleep 0.4