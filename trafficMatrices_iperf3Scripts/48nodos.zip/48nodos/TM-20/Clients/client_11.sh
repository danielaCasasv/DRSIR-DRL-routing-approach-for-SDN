 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 11001 -u -b 4341.090k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 11002 -u -b 1589.250k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 11004 -u -b 549.665k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 11005 -u -b 3450.698k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 11007 -u -b 479.423k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 11008 -u -b 7397.019k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 11009 -u -b 4028.097k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 11010 -u -b 1158.240k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 11012 -u -b 3009.475k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 11013 -u -b 4875.233k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 11016 -u -b 1000.288k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 11017 -u -b 1227.284k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 11018 -u -b 5804.959k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 11019 -u -b 4517.252k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 11021 -u -b 7753.463k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 11022 -u -b 6070.045k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 11026 -u -b 727.274k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 11027 -u -b 6222.329k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 11028 -u -b 6673.172k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 11029 -u -b 5658.046k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 11030 -u -b 2739.598k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 11031 -u -b 6720.336k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 11032 -u -b 4418.306k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 11033 -u -b 7130.380k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 11036 -u -b 3776.112k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 11037 -u -b 2865.149k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 11038 -u -b 6758.067k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 11039 -u -b 5761.913k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 11041 -u -b 348.715k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 11042 -u -b 4685.618k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 11043 -u -b 4587.390k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 11044 -u -b 5779.812k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 11045 -u -b 3585.268k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 11046 -u -b 5677.522k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 11048 -u -b 4552.425k -w 256k -t 30 &
sleep 0.4