 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 25002 -u -b 744.905k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 25003 -u -b 3635.835k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 25005 -u -b 1617.393k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 25007 -u -b 224.713k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 25009 -u -b 1888.028k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 25010 -u -b 542.884k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 25011 -u -b 1887.562k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 25012 -u -b 1410.585k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 25013 -u -b 2285.094k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 25016 -u -b 468.850k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 25018 -u -b 2720.870k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 25019 -u -b 2117.302k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 25022 -u -b 2845.120k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 25026 -u -b 340.884k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 25027 -u -b 2916.497k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 25028 -u -b 3127.814k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 25030 -u -b 1284.090k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 25032 -u -b 2070.925k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 25033 -u -b 3342.114k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 25036 -u -b 1769.919k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 25037 -u -b 1342.937k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 25038 -u -b 3167.606k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 25039 -u -b 2700.694k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 25040 -u -b 1539.818k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 25044 -u -b 2709.083k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 25046 -u -b 2661.138k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 25047 -u -b 1516.940k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 25048 -u -b 2133.789k -w 256k -t 30 &
sleep 0.4