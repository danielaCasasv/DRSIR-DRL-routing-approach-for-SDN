 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 43001 -u -b 4064.971k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 43002 -u -b 1488.164k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 43004 -u -b 514.703k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 43005 -u -b 3231.213k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 43007 -u -b 448.929k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 43010 -u -b 1084.569k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 43011 -u -b 3770.954k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 43012 -u -b 2818.055k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 43013 -u -b 4565.140k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 43014 -u -b 5294.851k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 43016 -u -b 936.664k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 43017 -u -b 1149.222k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 43018 -u -b 5435.729k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 43019 -u -b 4229.928k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 43021 -u -b 7260.298k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 43022 -u -b 5683.954k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 43023 -u -b 6307.017k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 43025 -u -b 1767.502k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 43026 -u -b 681.015k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 43027 -u -b 5826.553k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 43028 -u -b 6248.719k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 43029 -u -b 5298.161k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 43030 -u -b 2565.344k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 43033 -u -b 6676.846k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 43034 -u -b 4354.047k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 43035 -u -b 240.454k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 43036 -u -b 3535.929k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 43037 -u -b 2682.908k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 43039 -u -b 5395.422k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 43040 -u -b 3076.235k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 43042 -u -b 4387.585k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 43044 -u -b 5412.182k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 43046 -u -b 5316.398k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 43047 -u -b 3030.529k -w 256k -t 30 &
sleep 0.4