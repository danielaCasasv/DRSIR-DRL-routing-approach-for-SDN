 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 30001 -u -b 2427.609k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 30002 -u -b 888.735k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 30003 -u -b 4337.859k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 30005 -u -b 1929.687k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 30007 -u -b 268.101k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 30008 -u -b 4136.534k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 30011 -u -b 2252.021k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 30012 -u -b 1682.948k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 30014 -u -b 3162.095k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 30016 -u -b 559.377k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 30017 -u -b 686.317k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 30022 -u -b 3394.469k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 30023 -u -b 3766.563k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 30024 -u -b 1567.283k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 30025 -u -b 1055.556k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 30026 -u -b 406.704k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 30027 -u -b 3479.628k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 30028 -u -b 3731.747k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 30029 -u -b 3164.072k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 30033 -u -b 3987.425k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 30034 -u -b 2600.245k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 30036 -u -b 2111.664k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 30037 -u -b 1602.238k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 30038 -u -b 3779.222k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 30040 -u -b 1837.133k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 30041 -u -b 195.007k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 30042 -u -b 2620.274k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 30043 -u -b 2565.344k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 30044 -u -b 3232.165k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 30045 -u -b 2004.940k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 30047 -u -b 1809.838k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 30048 -u -b 2545.791k -w 256k -t 30 &
sleep 0.4