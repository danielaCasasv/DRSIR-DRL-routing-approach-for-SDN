 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 24001 -u -b 2483.473k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 24002 -u -b 909.186k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 24003 -u -b 4437.682k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 24004 -u -b 314.455k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 24005 -u -b 1974.093k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 24006 -u -b 4271.035k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 24008 -u -b 4231.724k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 24009 -u -b 2304.414k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 24010 -u -b 662.612k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 24011 -u -b 2303.845k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 24012 -u -b 1721.676k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 24018 -u -b 3320.930k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 24021 -u -b 4435.641k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 24022 -u -b 3472.582k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 24023 -u -b 3853.239k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 24025 -u -b 1079.846k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 24026 -u -b 416.063k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 24027 -u -b 3559.702k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 24029 -u -b 3236.884k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 24030 -u -b 1567.283k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 24031 -u -b 3844.604k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 24032 -u -b 2527.647k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 24033 -u -b 4079.184k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 24034 -u -b 2660.082k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 24035 -u -b 146.904k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 24036 -u -b 2160.258k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 24037 -u -b 1639.109k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 24038 -u -b 3866.189k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 24040 -u -b 1879.410k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 24042 -u -b 2680.572k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 24043 -u -b 2624.377k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 24045 -u -b 2051.078k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 24046 -u -b 3248.026k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 24047 -u -b 1851.486k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 24048 -u -b 2604.375k -w 256k -t 30 &
sleep 0.4