 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 44001 -u -b 5121.598k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 44003 -u -b 9151.710k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 44005 -u -b 4071.117k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 44008 -u -b 8726.969k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 44010 -u -b 1366.486k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 44014 -u -b 6671.166k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 44015 -u -b 5825.800k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 44016 -u -b 1180.135k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 44018 -u -b 6848.664k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 44019 -u -b 5329.433k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 44020 -u -b 4054.728k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 44022 -u -b 7161.411k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 44023 -u -b 7946.429k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 44024 -u -b 3306.544k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 44025 -u -b 2226.937k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 44026 -u -b 858.034k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 44030 -u -b 3232.165k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 44031 -u -b 7928.621k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 44032 -u -b 5212.697k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 44033 -u -b 8412.389k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 44034 -u -b 5485.815k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 44035 -u -b 302.956k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 44036 -u -b 4455.040k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 44037 -u -b 3380.289k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 44039 -u -b 6797.879k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 44040 -u -b 3875.855k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 44042 -u -b 5528.070k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 44043 -u -b 5412.182k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 44045 -u -b 4229.883k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 44046 -u -b 6698.314k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 44047 -u -b 3818.269k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 44048 -u -b 5370.930k -w 256k -t 30 &
sleep 0.4