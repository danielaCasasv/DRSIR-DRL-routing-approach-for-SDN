 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 48001 -u -b 4033.988k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 48002 -u -b 1476.822k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 48004 -u -b 510.780k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 48006 -u -b 6937.586k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 48007 -u -b 445.508k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 48009 -u -b 3743.137k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 48010 -u -b 1076.302k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 48011 -u -b 3742.212k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 48016 -u -b 929.524k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 48017 -u -b 1140.462k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 48019 -u -b 4197.688k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 48020 -u -b 3193.676k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 48021 -u -b 7204.960k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 48023 -u -b 6258.945k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 48024 -u -b 2604.375k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 48025 -u -b 1754.030k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 48026 -u -b 675.824k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 48027 -u -b 5782.143k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 48028 -u -b 6201.092k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 48029 -u -b 5257.778k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 48030 -u -b 2545.791k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 48032 -u -b 4105.742k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 48033 -u -b 6625.955k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 48034 -u -b 4320.861k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 48035 -u -b 238.621k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 48037 -u -b 2662.459k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 48039 -u -b 5354.298k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 48041 -u -b 324.046k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 48043 -u -b 4262.864k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 48046 -u -b 5275.877k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 48047 -u -b 3007.431k -w 256k -t 30 &
sleep 0.4