 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 41001 -u -b 309.003k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 41002 -u -b 113.124k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 41003 -u -b 552.152k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 41004 -u -b 39.126k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 41005 -u -b 245.624k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 41006 -u -b 531.417k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 41007 -u -b 34.126k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 41008 -u -b 526.526k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 41011 -u -b 286.653k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 41014 -u -b 402.493k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 41016 -u -b 71.201k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 41018 -u -b 413.202k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 41021 -u -b 551.898k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 41022 -u -b 432.071k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 41024 -u -b 199.495k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 41025 -u -b 134.358k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 41026 -u -b 51.768k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 41027 -u -b 442.911k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 41028 -u -b 475.002k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 41029 -u -b 402.745k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 41030 -u -b 195.007k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 41031 -u -b 478.359k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 41033 -u -b 507.547k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 41034 -u -b 330.977k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 41036 -u -b 268.787k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 41039 -u -b 410.138k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 41040 -u -b 233.843k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 41042 -u -b 333.526k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 41043 -u -b 326.534k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 41044 -u -b 411.412k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 41045 -u -b 255.202k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 41047 -u -b 230.369k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 41048 -u -b 324.046k -w 256k -t 30 &
sleep 0.4