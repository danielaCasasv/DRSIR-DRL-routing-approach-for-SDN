 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 9001 -u -b 3569.371k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 9002 -u -b 1306.728k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 9004 -u -b 451.950k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 9006 -u -b 6138.544k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 9007 -u -b 394.196k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 9008 -u -b 6082.045k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 9010 -u -b 952.338k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 9011 -u -b 3311.201k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 9012 -u -b 2474.478k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 9013 -u -b 4008.559k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 9014 -u -b 4649.304k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 9015 -u -b 4060.147k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 9018 -u -b 4773.007k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 9020 -u -b 2825.842k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 9021 -u -b 6375.124k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 9022 -u -b 4990.968k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 9023 -u -b 5538.067k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 9024 -u -b 2304.414k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 9026 -u -b 597.986k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 9028 -u -b 5486.877k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 9029 -u -b 4652.210k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 9030 -u -b 2252.578k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 9031 -u -b 5525.656k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 9033 -u -b 5862.806k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 9034 -u -b 3823.203k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 9035 -u -b 211.138k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 9036 -u -b 3104.830k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 9037 -u -b 2355.809k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 9038 -u -b 5556.680k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 9039 -u -b 4737.613k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 9040 -u -b 2701.181k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 9041 -u -b 286.723k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 9043 -u -b 3771.886k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 9045 -u -b 2947.912k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 9047 -u -b 2661.048k -w 256k -t 30 &
sleep 0.4