 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 40001 -u -b 2911.070k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 40002 -u -b 1065.727k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 40003 -u -b 5201.749k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 40005 -u -b 2313.986k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 40006 -u -b 5006.409k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 40008 -u -b 4960.330k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 40009 -u -b 2701.181k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 40010 -u -b 776.698k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 40011 -u -b 2700.514k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 40012 -u -b 2018.109k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 40013 -u -b 3269.258k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 40014 -u -b 3791.830k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 40015 -u -b 3311.332k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 40017 -u -b 822.998k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 40018 -u -b 3892.718k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 40019 -u -b 3029.201k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 40020 -u -b 2304.671k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 40021 -u -b 5199.356k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 40025 -u -b 1265.771k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 40026 -u -b 487.699k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 40027 -u -b 4172.601k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 40028 -u -b 4474.929k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 40029 -u -b 3794.200k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 40030 -u -b 1837.133k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 40032 -u -b 2962.850k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 40036 -u -b 2532.204k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 40038 -u -b 4531.858k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 40039 -u -b 3863.853k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 40041 -u -b 233.843k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 40042 -u -b 3142.105k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 40043 -u -b 3076.235k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 40045 -u -b 2404.227k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 40046 -u -b 3807.261k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 40047 -u -b 2170.269k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 40048 -u -b 3052.788k -w 256k -t 30 &
sleep 0.4