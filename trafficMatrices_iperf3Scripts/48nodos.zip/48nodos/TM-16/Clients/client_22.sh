 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 22002 -u -b 1969.143k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 22003 -u -b 9611.264k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 22005 -u -b 4275.548k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 22006 -u -b 9250.334k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 22007 -u -b 594.024k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 22008 -u -b 9165.194k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 22009 -u -b 4990.968k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 22010 -u -b 1435.104k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 22011 -u -b 4989.735k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 22012 -u -b 3728.857k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 22014 -u -b 7006.158k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 22016 -u -b 1239.395k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 22019 -u -b 5597.050k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 22021 -u -b 9606.842k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 22023 -u -b 8345.459k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 22025 -u -b 2338.763k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 22027 -u -b 7709.708k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 22029 -u -b 7010.538k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 22030 -u -b 3394.469k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 22031 -u -b 8326.757k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 22033 -u -b 8834.818k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 22034 -u -b 5761.285k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 22035 -u -b 318.169k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 22038 -u -b 8373.507k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 22040 -u -b 4070.481k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 22042 -u -b 5805.662k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 22043 -u -b 5683.954k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 22047 -u -b 4010.003k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 22048 -u -b 5640.632k -w 256k -t 30 &
sleep 0.4