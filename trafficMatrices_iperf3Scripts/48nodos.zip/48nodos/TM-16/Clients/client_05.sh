 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 5001 -u -b 3057.727k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 5003 -u -b 5463.809k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 5004 -u -b 387.166k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 5006 -u -b 5258.628k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 5007 -u -b 337.691k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 5008 -u -b 5210.227k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 5009 -u -b 2837.264k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 5012 -u -b 2119.779k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 5013 -u -b 3433.961k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 5016 -u -b 704.571k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 5017 -u -b 864.460k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 5018 -u -b 4088.830k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 5019 -u -b 3181.810k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 5021 -u -b 5461.295k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 5022 -u -b 4275.548k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 5023 -u -b 4744.225k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 5024 -u -b 1974.093k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 5025 -u -b 1329.539k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 5026 -u -b 512.269k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 5027 -u -b 4382.813k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 5028 -u -b 4700.372k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 5029 -u -b 3985.349k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 5031 -u -b 4733.593k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 5034 -u -b 3275.174k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 5035 -u -b 180.873k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 5036 -u -b 2659.774k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 5037 -u -b 2018.120k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 5039 -u -b 4058.510k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 5040 -u -b 2313.986k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 5041 -u -b 245.624k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 5042 -u -b 3300.401k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 5043 -u -b 3231.213k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 5044 -u -b 4071.117k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 5045 -u -b 2525.350k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 5046 -u -b 3999.067k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 5047 -u -b 2279.606k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 5048 -u -b 3206.585k -w 256k -t 30 &
sleep 0.4