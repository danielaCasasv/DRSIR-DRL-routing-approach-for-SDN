 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 46001 -u -b 5030.957k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 46002 -u -b 1841.807k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 46003 -u -b 8989.745k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 46006 -u -b 8652.156k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 46007 -u -b 555.611k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 46008 -u -b 8572.521k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 46009 -u -b 4668.224k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 46010 -u -b 1342.302k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 46012 -u -b 3487.728k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 46014 -u -b 6553.101k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 46015 -u -b 5722.697k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 46017 -u -b 1422.319k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 46018 -u -b 6727.457k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 46019 -u -b 5235.113k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 46020 -u -b 3982.968k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 46022 -u -b 7034.670k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 46024 -u -b 3248.026k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 46027 -u -b 7211.154k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 46029 -u -b 6557.197k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 46030 -u -b 3174.963k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 46031 -u -b 7788.302k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 46033 -u -b 8263.508k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 46035 -u -b 297.594k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 46036 -u -b 4376.195k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 46038 -u -b 7832.029k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 46040 -u -b 3807.261k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 46041 -u -b 404.131k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 46044 -u -b 6698.314k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 46045 -u -b 4155.023k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 46047 -u -b 3750.694k -w 256k -t 30 &
sleep 0.4