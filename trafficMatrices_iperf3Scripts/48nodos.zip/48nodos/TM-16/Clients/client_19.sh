 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 19001 -u -b 4002.820k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 19002 -u -b 1465.411k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 19003 -u -b 7152.582k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 19005 -u -b 3181.810k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 19006 -u -b 6883.983k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 19007 -u -b 442.065k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 19008 -u -b 6820.623k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 19010 -u -b 1067.986k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 19012 -u -b 2774.968k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 19013 -u -b 4495.342k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 19014 -u -b 5213.895k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 19015 -u -b 4553.195k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 19016 -u -b 922.343k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 19017 -u -b 1131.651k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 19018 -u -b 5352.620k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 19020 -u -b 3169.001k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 19022 -u -b 5597.050k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 19023 -u -b 6210.587k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 19025 -u -b 1740.478k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 19026 -u -b 670.603k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 19027 -u -b 5737.468k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 19028 -u -b 6153.180k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 19032 -u -b 4074.019k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 19033 -u -b 6574.761k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 19034 -u -b 4287.476k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 19035 -u -b 236.777k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 19036 -u -b 3481.867k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 19037 -u -b 2641.888k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 19039 -u -b 5312.929k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 19041 -u -b 321.542k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 19042 -u -b 4320.501k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 19043 -u -b 4229.928k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 19044 -u -b 5329.433k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 19045 -u -b 3305.894k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 19046 -u -b 5235.113k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 19047 -u -b 2984.194k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 19048 -u -b 4197.688k -w 256k -t 30 &
sleep 0.4