 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 28001 -u -b 5913.221k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 28002 -u -b 2164.799k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 28004 -u -b 748.726k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 28005 -u -b 4700.372k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 28007 -u -b 653.047k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 28008 -u -b 10075.859k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 28009 -u -b 5486.877k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 28012 -u -b 4099.360k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 28013 -u -b 6640.806k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 28015 -u -b 6726.269k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 28016 -u -b 1362.543k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 28017 -u -b 1671.747k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 28019 -u -b 6153.180k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 28020 -u -b 4681.450k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 28022 -u -b 8268.320k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 28023 -u -b 9174.675k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 28024 -u -b 3817.622k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 28025 -u -b 2571.145k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 28026 -u -b 990.657k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 28027 -u -b 8475.754k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 28029 -u -b 7707.114k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 28030 -u -b 3731.747k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 28031 -u -b 9154.114k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 28032 -u -b 6018.401k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 28034 -u -b 6333.734k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 28035 -u -b 349.783k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 28037 -u -b 3902.766k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 28039 -u -b 7848.598k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 28040 -u -b 4474.929k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 28042 -u -b 6382.520k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 28044 -u -b 7872.978k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 28045 -u -b 4883.677k -w 256k -t 30 &
sleep 0.4