 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 4001 -u -b 487.068k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 4005 -u -b 387.166k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 4006 -u -b 837.651k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 4007 -u -b 53.791k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 4009 -u -b 451.950k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 4010 -u -b 129.954k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 4011 -u -b 451.839k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 4013 -u -b 546.999k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 4016 -u -b 112.232k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 4017 -u -b 137.701k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 4020 -u -b 385.608k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 4022 -u -b 681.056k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 4023 -u -b 755.712k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 4025 -u -b 211.783k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 4026 -u -b 81.600k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 4029 -u -b 634.830k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 4030 -u -b 307.381k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 4031 -u -b 754.018k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 4032 -u -b 495.732k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 4033 -u -b 800.025k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 4035 -u -b 28.811k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 4036 -u -b 423.678k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 4037 -u -b 321.468k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 4038 -u -b 758.252k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 4039 -u -b 646.484k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 4040 -u -b 368.597k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 4041 -u -b 39.126k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 4043 -u -b 514.703k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 4045 -u -b 402.265k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 4047 -u -b 363.120k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 4048 -u -b 510.780k -w 256k -t 30 &
sleep 0.4