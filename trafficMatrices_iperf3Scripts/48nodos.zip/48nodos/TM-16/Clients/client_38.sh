 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 38002 -u -b 2192.339k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 38003 -u -b 10700.673k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 38004 -u -b 758.252k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 38005 -u -b 4760.169k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 38006 -u -b 10298.833k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 38007 -u -b 661.355k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 38008 -u -b 10204.042k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 38009 -u -b 5556.680k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 38012 -u -b 4151.512k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 38013 -u -b 6725.289k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 38014 -u -b 7800.286k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 38015 -u -b 6811.840k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 38016 -u -b 1379.877k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 38017 -u -b 1693.014k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 38020 -u -b 4741.006k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 38023 -u -b 9291.393k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 38026 -u -b 1003.260k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 38028 -u -b 9205.510k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 38029 -u -b 7805.163k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 38030 -u -b 3779.222k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 38032 -u -b 6094.966k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 38033 -u -b 9836.219k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 38034 -u -b 6414.310k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 38035 -u -b 354.232k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 38036 -u -b 5209.072k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 38037 -u -b 3952.416k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 38041 -u -b 481.045k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 38042 -u -b 6463.717k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 38044 -u -b 7973.136k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 38047 -u -b 4464.525k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 38048 -u -b 6279.981k -w 256k -t 30 &
sleep 0.4