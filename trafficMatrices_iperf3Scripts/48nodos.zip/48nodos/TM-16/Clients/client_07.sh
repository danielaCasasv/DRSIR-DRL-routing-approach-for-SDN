 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 7001 -u -b 424.826k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 7002 -u -b 155.527k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 7003 -u -b 759.115k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 7004 -u -b 53.791k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 7008 -u -b 723.884k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 7009 -u -b 394.196k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 7010 -u -b 113.347k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 7011 -u -b 394.099k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 7012 -u -b 294.512k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 7013 -u -b 477.098k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 7014 -u -b 553.359k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 7015 -u -b 483.238k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 7016 -u -b 97.890k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 7020 -u -b 336.331k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 7022 -u -b 594.024k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 7023 -u -b 659.140k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 7024 -u -b 274.271k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 7025 -u -b 184.720k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 7026 -u -b 71.172k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 7027 -u -b 608.927k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 7028 -u -b 653.047k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 7029 -u -b 553.705k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 7030 -u -b 268.101k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 7034 -u -b 455.037k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 7038 -u -b 661.355k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 7039 -u -b 563.870k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 7040 -u -b 321.494k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 7041 -u -b 34.126k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 7043 -u -b 448.929k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 7044 -u -b 565.622k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 7045 -u -b 350.860k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 7046 -u -b 555.611k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 7047 -u -b 316.717k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 7048 -u -b 445.508k -w 256k -t 30 &
sleep 0.4