 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 20001 -u -b 3045.418k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 20003 -u -b 5441.813k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 20004 -u -b 385.608k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 20005 -u -b 2420.778k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 20007 -u -b 336.331k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 20010 -u -b 812.543k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 20012 -u -b 2111.246k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 20013 -u -b 3420.137k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 20014 -u -b 3966.825k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 20015 -u -b 3464.152k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 20016 -u -b 701.735k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 20018 -u -b 4072.370k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 20021 -u -b 5439.310k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 20023 -u -b 4725.126k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 20024 -u -b 1966.146k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 20025 -u -b 1324.187k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 20027 -u -b 4365.169k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 20028 -u -b 4681.450k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 20029 -u -b 3969.305k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 20030 -u -b 1921.918k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 20032 -u -b 3099.587k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 20035 -u -b 180.144k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 20037 -u -b 2009.996k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 20039 -u -b 4042.172k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 20040 -u -b 2304.671k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 20041 -u -b 244.635k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 20043 -u -b 3218.205k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 20044 -u -b 4054.728k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 20045 -u -b 2515.183k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 20047 -u -b 2270.429k -w 256k -t 30 &
sleep 0.4