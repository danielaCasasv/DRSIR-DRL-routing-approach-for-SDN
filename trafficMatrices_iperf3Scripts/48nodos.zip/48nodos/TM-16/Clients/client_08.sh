 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 8002 -u -b 2399.617k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 8003 -u -b 11712.385k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 8004 -u -b 829.942k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 8005 -u -b 5210.227k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 8006 -u -b 11272.553k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 8007 -u -b 723.884k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 8010 -u -b 1748.832k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 8011 -u -b 6080.543k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 8013 -u -b 7361.142k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 8014 -u -b 8537.777k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 8015 -u -b 7455.876k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 8016 -u -b 1510.340k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 8017 -u -b 1853.083k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 8018 -u -b 8764.939k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 8019 -u -b 6820.623k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 8020 -u -b 5189.253k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 8021 -u -b 11706.997k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 8022 -u -b 9165.194k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 8023 -u -b 10169.863k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 8024 -u -b 4231.724k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 8028 -u -b 10075.859k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 8029 -u -b 8543.114k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 8033 -u -b 10766.200k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 8034 -u -b 7020.761k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 8035 -u -b 387.724k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 8036 -u -b 5701.572k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 8038 -u -b 10204.042k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 8039 -u -b 8699.945k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 8040 -u -b 4960.330k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 8042 -u -b 7074.840k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 8043 -u -b 6926.525k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 8046 -u -b 8572.521k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 8047 -u -b 4886.631k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 8048 -u -b 6873.732k -w 256k -t 30 &
sleep 0.4