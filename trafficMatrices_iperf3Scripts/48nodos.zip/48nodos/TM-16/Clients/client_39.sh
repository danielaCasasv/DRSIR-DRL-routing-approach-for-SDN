 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 39001 -u -b 5105.738k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 39003 -u -b 9123.371k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 39004 -u -b 646.484k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 39005 -u -b 4058.510k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 39006 -u -b 8780.763k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 39007 -u -b 563.870k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 39008 -u -b 8699.945k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 39012 -u -b 3539.570k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 39013 -u -b 5733.967k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 39014 -u -b 6650.507k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 39016 -u -b 1176.480k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 39018 -u -b 6827.456k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 39021 -u -b 9119.174k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 39022 -u -b 7139.235k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 39023 -u -b 7921.822k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 39024 -u -b 3296.305k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 39026 -u -b 855.377k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 39028 -u -b 7848.598k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 39031 -u -b 7904.069k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 39033 -u -b 8386.339k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 39034 -u -b 5468.827k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 39036 -u -b 4441.244k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 39037 -u -b 3369.821k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 39038 -u -b 7948.446k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 39040 -u -b 3863.853k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 39041 -u -b 410.138k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 39042 -u -b 5510.952k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 39044 -u -b 6797.879k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 39046 -u -b 6677.571k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 39047 -u -b 3806.445k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 39048 -u -b 5354.298k -w 256k -t 30 &
sleep 0.4