 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 47001 -u -b 2867.818k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 47002 -u -b 1049.893k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 47004 -u -b 363.120k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 47005 -u -b 2279.606k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 47006 -u -b 4932.026k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 47008 -u -b 4886.631k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 47010 -u -b 765.158k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 47011 -u -b 2660.391k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 47012 -u -b 1988.124k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 47013 -u -b 3220.685k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 47014 -u -b 3735.492k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 47017 -u -b 810.771k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 47020 -u -b 2270.429k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 47021 -u -b 5122.106k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 47023 -u -b 4449.571k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 47024 -u -b 1851.486k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 47025 -u -b 1246.964k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 47026 -u -b 480.453k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 47027 -u -b 4110.605k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 47028 -u -b 4408.442k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 47029 -u -b 3737.828k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 47030 -u -b 1809.838k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 47031 -u -b 4439.599k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 47032 -u -b 2918.829k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 47033 -u -b 4710.483k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 47037 -u -b 1892.779k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 47038 -u -b 4464.525k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 47039 -u -b 3806.445k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 47040 -u -b 2170.269k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 47041 -u -b 230.369k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 47043 -u -b 3030.529k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 47044 -u -b 3818.269k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 47045 -u -b 2368.506k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 47046 -u -b 3750.694k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 47048 -u -b 3007.431k -w 256k -t 30 &
sleep 0.4