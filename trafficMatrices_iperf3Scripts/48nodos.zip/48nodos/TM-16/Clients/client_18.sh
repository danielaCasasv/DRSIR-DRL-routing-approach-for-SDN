 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.3 -p 18003 -u -b 9191.528k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 18004 -u -b 651.313k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 18005 -u -b 4088.830k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 18006 -u -b 8846.361k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 18007 -u -b 568.082k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 18008 -u -b 8764.939k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 18009 -u -b 4773.007k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 18010 -u -b 1372.431k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 18011 -u -b 4771.828k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 18013 -u -b 5776.803k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 18014 -u -b 6700.191k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 18015 -u -b 5851.148k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 18017 -u -b 1454.244k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 18020 -u -b 4072.370k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 18021 -u -b 9187.300k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 18022 -u -b 7192.570k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 18024 -u -b 3320.930k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 18025 -u -b 2236.626k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 18028 -u -b 7907.232k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 18029 -u -b 6704.380k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 18031 -u -b 7963.117k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 18033 -u -b 8448.991k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 18035 -u -b 304.274k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 18039 -u -b 6827.456k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 18040 -u -b 3892.718k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 18041 -u -b 413.202k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 18043 -u -b 5435.729k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 18044 -u -b 6848.664k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 18046 -u -b 6727.457k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 18048 -u -b 5394.299k -w 256k -t 30 &
sleep 0.4