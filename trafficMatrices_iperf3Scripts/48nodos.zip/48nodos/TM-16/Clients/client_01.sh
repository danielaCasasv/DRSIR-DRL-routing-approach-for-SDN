 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 1002 -u -b 1408.264k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 1003 -u -b 6873.650k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 1004 -u -b 487.068k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 1005 -u -b 3057.727k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 1006 -u -b 6615.525k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 1007 -u -b 424.826k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 1008 -u -b 6554.636k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 1009 -u -b 3569.371k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 1010 -u -b 1026.338k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 1011 -u -b 3568.489k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 1013 -u -b 4320.035k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 1014 -u -b 5010.567k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 1015 -u -b 4375.631k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 1018 -u -b 5143.882k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 1019 -u -b 4002.820k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 1020 -u -b 3045.418k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 1023 -u -b 5968.389k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 1024 -u -b 2483.473k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 1026 -u -b 644.451k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 1028 -u -b 5913.221k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 1029 -u -b 5013.699k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 1030 -u -b 2427.609k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 1031 -u -b 5955.014k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 1032 -u -b 3915.143k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 1033 -u -b 6318.362k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 1036 -u -b 3346.083k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 1037 -u -b 2538.861k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 1038 -u -b 5988.448k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 1040 -u -b 2911.070k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 1043 -u -b 4064.971k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 1044 -u -b 5121.598k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 1045 -u -b 3176.972k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 1046 -u -b 5030.957k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 1048 -u -b 4033.988k -w 256k -t 30 &
sleep 0.4