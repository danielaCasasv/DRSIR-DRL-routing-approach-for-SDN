 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 16001 -u -b 886.373k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 16002 -u -b 324.497k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 16003 -u -b 1583.848k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 16005 -u -b 704.571k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 16006 -u -b 1524.370k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 16008 -u -b 1510.340k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 16010 -u -b 236.492k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 16012 -u -b 614.481k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 16013 -u -b 995.436k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 16014 -u -b 1154.551k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 16017 -u -b 250.590k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 16018 -u -b 1185.269k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 16020 -u -b 701.735k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 16021 -u -b 1583.119k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 16022 -u -b 1239.395k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 16026 -u -b 148.496k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 16027 -u -b 1270.489k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 16030 -u -b 559.377k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 16031 -u -b 1372.173k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 16032 -u -b 902.140k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 16033 -u -b 1455.897k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 16034 -u -b 949.407k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 16035 -u -b 52.431k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 16036 -u -b 771.015k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 16037 -u -b 585.012k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 16038 -u -b 1379.877k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 16040 -u -b 670.778k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 16042 -u -b 956.720k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 16044 -u -b 1180.135k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 16045 -u -b 732.048k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 16046 -u -b 1159.249k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 16047 -u -b 660.812k -w 256k -t 30 &
sleep 0.4