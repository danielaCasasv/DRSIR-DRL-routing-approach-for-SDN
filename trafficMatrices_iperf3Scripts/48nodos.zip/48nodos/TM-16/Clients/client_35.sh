 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 35001 -u -b 227.544k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 35002 -u -b 83.302k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 35003 -u -b 406.594k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 35005 -u -b 180.873k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 35006 -u -b 391.326k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 35010 -u -b 60.711k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 35012 -u -b 157.745k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 35014 -u -b 296.388k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 35015 -u -b 258.830k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 35016 -u -b 52.431k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 35017 -u -b 64.330k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 35018 -u -b 304.274k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 35019 -u -b 236.777k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 35021 -u -b 406.407k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 35022 -u -b 318.169k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 35023 -u -b 353.046k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 35025 -u -b 98.939k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 35026 -u -b 38.121k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 35027 -u -b 326.151k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 35029 -u -b 296.573k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 35030 -u -b 143.599k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 35031 -u -b 352.255k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 35032 -u -b 231.591k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 35034 -u -b 243.725k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 35037 -u -b 150.180k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 35038 -u -b 354.232k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 35039 -u -b 302.018k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 35041 -u -b 18.278k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 35043 -u -b 240.454k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 35044 -u -b 302.956k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 35046 -u -b 297.594k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 35047 -u -b 169.639k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 35048 -u -b 238.621k -w 256k -t 30 &
sleep 0.4