 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 13001 -u -b 4320.035k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 13003 -u -b 7719.408k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 13005 -u -b 3433.961k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 13006 -u -b 7429.523k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 13008 -u -b 7361.142k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 13009 -u -b 4008.559k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 13010 -u -b 1152.622k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 13011 -u -b 4007.569k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 13012 -u -b 2994.878k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 13015 -u -b 4914.025k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 13016 -u -b 995.436k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 13017 -u -b 1221.332k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 13018 -u -b 5776.803k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 13019 -u -b 4495.342k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 13021 -u -b 7715.857k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 13023 -u -b 6702.761k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 13024 -u -b 2789.048k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 13025 -u -b 1878.407k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 13026 -u -b 723.746k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 13027 -u -b 6192.149k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 13029 -u -b 5630.603k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 13030 -u -b 2726.310k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 13031 -u -b 6687.740k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 13032 -u -b 4396.876k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 13033 -u -b 7095.796k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 13034 -u -b 4627.249k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 13035 -u -b 255.541k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 13037 -u -b 2851.252k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 13040 -u -b 3269.258k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 13041 -u -b 347.023k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 13043 -u -b 4565.140k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 13045 -u -b 3567.878k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 13047 -u -b 3220.685k -w 256k -t 30 &
sleep 0.4