 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 17001 -u -b 1087.519k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 17002 -u -b 398.135k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 17003 -u -b 1943.273k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 17004 -u -b 137.701k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 17005 -u -b 864.460k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 17006 -u -b 1870.297k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 17007 -u -b 120.104k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 17010 -u -b 290.159k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 17011 -u -b 1008.860k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 17012 -u -b 753.926k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 17013 -u -b 1221.332k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 17014 -u -b 1416.554k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 17015 -u -b 1237.049k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 17018 -u -b 1454.244k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 17019 -u -b 1131.651k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 17020 -u -b 860.980k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 17021 -u -b 1942.379k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 17022 -u -b 1520.653k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 17023 -u -b 1687.343k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 17025 -u -b 472.867k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 17026 -u -b 182.195k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 17027 -u -b 1558.803k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 17030 -u -b 686.317k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 17032 -u -b 1106.863k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 17033 -u -b 1786.285k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 17036 -u -b 945.982k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 17038 -u -b 1693.014k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 17039 -u -b 1443.460k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 17041 -u -b 87.359k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 17042 -u -b 1173.830k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 17044 -u -b 1447.944k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 17045 -u -b 898.173k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 17046 -u -b 1422.319k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 17047 -u -b 810.771k -w 256k -t 30 &
sleep 0.4