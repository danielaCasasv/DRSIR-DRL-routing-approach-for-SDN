 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 31002 -u -b 2180.099k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 31003 -u -b 10640.929k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 31005 -u -b 4733.593k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 31006 -u -b 10241.333k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 31007 -u -b 657.663k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 31009 -u -b 5525.656k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 31010 -u -b 1588.848k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 31011 -u -b 5524.291k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 31012 -u -b 4128.333k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 31013 -u -b 6687.740k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 31016 -u -b 1372.173k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 31017 -u -b 1683.562k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 31018 -u -b 7963.117k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 31019 -u -b 6196.668k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 31020 -u -b 4714.537k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 31021 -u -b 10636.034k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 31022 -u -b 8326.757k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 31023 -u -b 9239.518k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 31024 -u -b 3844.604k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 31027 -u -b 8535.657k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 31028 -u -b 9154.114k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 31029 -u -b 7761.585k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 31030 -u -b 3758.122k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 31034 -u -b 6378.498k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 31035 -u -b 352.255k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 31036 -u -b 5179.989k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 31037 -u -b 3930.349k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 31039 -u -b 7904.069k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 31040 -u -b 4506.556k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 31041 -u -b 478.359k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 31042 -u -b 6427.629k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 31043 -u -b 6292.883k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 31044 -u -b 7928.621k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 31045 -u -b 4918.193k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 31047 -u -b 4439.599k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 31048 -u -b 6244.919k -w 256k -t 30 &
sleep 0.4