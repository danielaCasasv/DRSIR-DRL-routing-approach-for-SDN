 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 15001 -u -b 4375.631k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 15002 -u -b 1601.895k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 15003 -u -b 7818.753k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 15006 -u -b 7525.137k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 15007 -u -b 483.238k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 15008 -u -b 7455.876k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 15009 -u -b 4060.147k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 15010 -u -b 1167.456k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 15011 -u -b 4059.145k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 15012 -u -b 3033.421k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 15014 -u -b 5699.503k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 15016 -u -b 1008.247k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 15017 -u -b 1237.049k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 15018 -u -b 5851.148k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 15019 -u -b 4553.195k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 15020 -u -b 3464.152k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 15021 -u -b 7815.156k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 15022 -u -b 6118.343k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 15025 -u -b 1902.581k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 15027 -u -b 6271.839k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 15028 -u -b 6726.269k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 15030 -u -b 2761.397k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 15033 -u -b 7187.115k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 15035 -u -b 258.830k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 15037 -u -b 2887.946k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 15038 -u -b 6811.840k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 15039 -u -b 5807.760k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 15042 -u -b 4722.900k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 15043 -u -b 4623.891k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 15046 -u -b 5722.697k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 15047 -u -b 3262.133k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 15048 -u -b 4588.648k -w 256k -t 30 &
sleep 0.4