 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 37001 -u -b 2538.861k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 37002 -u -b 929.464k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 37003 -u -b 4536.655k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 37004 -u -b 321.468k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 37006 -u -b 4366.291k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 37007 -u -b 280.388k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 37008 -u -b 4326.103k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 37009 -u -b 2355.809k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 37010 -u -b 677.390k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 37011 -u -b 2355.227k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 37012 -u -b 1760.074k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 37013 -u -b 2851.252k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 37015 -u -b 2887.946k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 37017 -u -b 717.770k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 37018 -u -b 3394.996k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 37019 -u -b 2641.888k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 37021 -u -b 4534.568k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 37022 -u -b 3550.030k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 37024 -u -b 1639.109k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 37025 -u -b 1103.930k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 37027 -u -b 3639.093k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 37028 -u -b 3902.766k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 37031 -u -b 3930.349k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 37032 -u -b 2584.020k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 37033 -u -b 4170.161k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 37034 -u -b 2719.410k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 37035 -u -b 150.180k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 37039 -u -b 3369.821k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 37040 -u -b 1921.326k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 37042 -u -b 2740.356k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 37043 -u -b 2682.908k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 37044 -u -b 3380.289k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 37045 -u -b 2096.823k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 37047 -u -b 1892.779k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 37048 -u -b 2662.459k -w 256k -t 30 &
sleep 0.4