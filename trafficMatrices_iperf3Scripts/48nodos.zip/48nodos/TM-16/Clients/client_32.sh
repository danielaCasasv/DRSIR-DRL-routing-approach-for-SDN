 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 32001 -u -b 3915.143k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 32003 -u -b 6995.913k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 32004 -u -b 495.732k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 32008 -u -b 6671.224k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 32010 -u -b 1044.593k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 32011 -u -b 3631.963k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 32013 -u -b 4396.876k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 32014 -u -b 5099.691k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 32015 -u -b 4453.462k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 32017 -u -b 1106.863k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 32018 -u -b 5235.377k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 32020 -u -b 3099.587k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 32023 -u -b 6074.550k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 32024 -u -b 2527.647k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 32025 -u -b 1702.355k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 32026 -u -b 655.914k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 32027 -u -b 5611.795k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 32029 -u -b 5102.879k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 32030 -u -b 2470.789k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 32031 -u -b 6060.937k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.34 -p 32034 -u -b 4193.564k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 32035 -u -b 231.591k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 32036 -u -b 3405.600k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 32038 -u -b 6094.966k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 32039 -u -b 5196.555k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 32040 -u -b 2962.850k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 32041 -u -b 314.499k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 32044 -u -b 5212.697k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 32047 -u -b 2918.829k -w 256k -t 30 &
sleep 0.4