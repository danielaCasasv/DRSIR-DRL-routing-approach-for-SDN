 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 42001 -u -b 4152.013k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 42003 -u -b 7419.172k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 42005 -u -b 3300.401k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 42007 -u -b 458.542k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 42008 -u -b 7074.840k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 42009 -u -b 3852.652k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 42010 -u -b 1107.792k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 42012 -u -b 2878.397k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 42013 -u -b 4662.891k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 42014 -u -b 5408.227k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 42017 -u -b 1173.830k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 42018 -u -b 5552.122k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 42019 -u -b 4320.501k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 42021 -u -b 7415.759k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 42022 -u -b 5805.662k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 42023 -u -b 6442.067k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 42024 -u -b 2680.572k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 42028 -u -b 6382.520k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 42029 -u -b 5411.608k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 42031 -u -b 6427.629k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 42032 -u -b 4225.865k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.35 -p 42035 -u -b 245.602k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 42036 -u -b 3611.643k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 42037 -u -b 2740.356k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 42041 -u -b 333.526k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 42043 -u -b 4387.585k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 42044 -u -b 5528.070k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 42045 -u -b 3429.111k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 42047 -u -b 3095.421k -w 256k -t 30 &
sleep 0.4