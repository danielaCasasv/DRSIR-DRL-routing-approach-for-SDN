 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 34001 -u -b 4120.276k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 34002 -u -b 1508.411k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 34004 -u -b 521.705k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 34006 -u -b 7085.981k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 34007 -u -b 455.037k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 34009 -u -b 3823.203k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 34010 -u -b 1099.324k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 34011 -u -b 3822.259k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 34014 -u -b 5366.888k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 34015 -u -b 4686.800k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 34018 -u -b 5509.683k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 34019 -u -b 4287.476k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 34021 -u -b 7359.075k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 34023 -u -b 6392.825k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 34024 -u -b 2660.082k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 34025 -u -b 1791.549k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 34027 -u -b 5905.823k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 34028 -u -b 6333.734k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 34029 -u -b 5370.243k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 34030 -u -b 2600.245k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 34032 -u -b 4193.564k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 34033 -u -b 6767.685k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 34036 -u -b 3584.036k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 34037 -u -b 2719.410k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 34040 -u -b 3118.087k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 34041 -u -b 330.977k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 34042 -u -b 4447.279k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 34045 -u -b 3402.899k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 34046 -u -b 5388.728k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 34047 -u -b 3071.760k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 34048 -u -b 4320.861k -w 256k -t 30 &
sleep 0.4