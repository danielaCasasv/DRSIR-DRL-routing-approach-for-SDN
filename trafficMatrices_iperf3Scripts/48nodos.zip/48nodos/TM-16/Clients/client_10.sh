 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 10001 -u -b 1026.338k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 10004 -u -b 129.954k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 10005 -u -b 815.827k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 10007 -u -b 113.347k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 10008 -u -b 1748.832k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 10009 -u -b 952.338k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 10011 -u -b 952.103k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 10012 -u -b 711.512k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 10013 -u -b 1152.622k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 10015 -u -b 1167.456k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 10016 -u -b 236.492k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 10018 -u -b 1372.431k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 10019 -u -b 1067.986k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 10020 -u -b 812.543k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 10021 -u -b 1833.104k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 10023 -u -b 1592.417k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 10024 -u -b 662.612k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 10025 -u -b 446.265k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 10026 -u -b 171.945k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 10027 -u -b 1471.108k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 10028 -u -b 1577.698k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 10029 -u -b 1337.697k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 10030 -u -b 647.707k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 10032 -u -b 1044.593k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.33 -p 10033 -u -b 1685.792k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 10037 -u -b 677.390k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.38 -p 10038 -u -b 1597.769k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.39 -p 10039 -u -b 1362.254k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.40 -p 10040 -u -b 776.698k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 10041 -u -b 82.445k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 10042 -u -b 1107.792k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.44 -p 10044 -u -b 1366.486k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 10045 -u -b 847.643k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 10046 -u -b 1342.302k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 10047 -u -b 765.158k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 10048 -u -b 1076.302k -w 256k -t 30 &
sleep 0.4