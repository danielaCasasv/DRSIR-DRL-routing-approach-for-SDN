 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 6002 -u -b 2421.909k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 6003 -u -b 11821.187k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 6004 -u -b 837.651k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 6005 -u -b 5258.628k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 6007 -u -b 730.609k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 6009 -u -b 6138.544k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 6010 -u -b 1765.078k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 6012 -u -b 4586.235k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 6014 -u -b 8617.088k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 6015 -u -b 7525.137k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 6016 -u -b 1524.370k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 6017 -u -b 1870.297k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 6019 -u -b 6883.983k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 6020 -u -b 5237.458k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 6022 -u -b 9250.334k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 6023 -u -b 10264.336k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 6028 -u -b 10169.459k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 6031 -u -b 10241.333k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 6032 -u -b 6733.197k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.36 -p 6036 -u -b 5754.537k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.37 -p 6037 -u -b 4366.291k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.41 -p 6041 -u -b 531.417k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.42 -p 6042 -u -b 7140.562k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.43 -p 6043 -u -b 6990.869k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.45 -p 6045 -u -b 5463.704k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.46 -p 6046 -u -b 8652.156k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.47 -p 6047 -u -b 4932.026k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.48 -p 6048 -u -b 6937.586k -w 256k -t 30 &
sleep 0.4