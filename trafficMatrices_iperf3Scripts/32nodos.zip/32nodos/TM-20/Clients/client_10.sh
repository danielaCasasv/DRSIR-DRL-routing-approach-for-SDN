 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 10001 -u -b 9713.620k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 10002 -u -b 7882.719k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 10003 -u -b 7703.793k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 10006 -u -b 7008.046k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 10007 -u -b 997.903k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 10008 -u -b 1923.571k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 10009 -u -b 1862.809k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 10011 -u -b 5823.502k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 10012 -u -b 1175.869k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 10013 -u -b 1497.264k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 10014 -u -b 10266.985k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 10016 -u -b 1422.107k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 10018 -u -b 10339.299k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 10019 -u -b 3226.026k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 10021 -u -b 6828.752k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 10022 -u -b 4831.027k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 10025 -u -b 943.833k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 10027 -u -b 1903.817k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 10028 -u -b 4924.349k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 10029 -u -b 3734.173k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 10030 -u -b 4690.383k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 10031 -u -b 722.881k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 10032 -u -b 5173.898k -w 256k -t 30 &
sleep 0.4