 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 12001 -u -b 1299.314k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 12005 -u -b 411.025k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 12006 -u -b 937.411k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 12008 -u -b 257.301k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 12009 -u -b 249.173k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 12011 -u -b 778.964k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 12013 -u -b 200.277k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 12014 -u -b 1373.333k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 12015 -u -b 2.352k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 12016 -u -b 190.224k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 12017 -u -b 1145.075k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 12018 -u -b 1383.006k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 12020 -u -b 12.909k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 12021 -u -b 913.428k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 12022 -u -b 646.208k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 12024 -u -b 117.750k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 12025 -u -b 126.249k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 12028 -u -b 658.691k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 12029 -u -b 499.491k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 12030 -u -b 627.395k -w 256k -t 30 &
sleep 0.4