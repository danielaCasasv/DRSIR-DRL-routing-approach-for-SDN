 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 9001 -u -b 2058.370k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 9004 -u -b 1128.145k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 9005 -u -b 651.145k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 9007 -u -b 211.461k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 9008 -u -b 407.615k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 9012 -u -b 249.173k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 9014 -u -b 2175.631k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 9016 -u -b 301.352k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 9018 -u -b 2190.955k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 9019 -u -b 683.613k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 9020 -u -b 20.450k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 9022 -u -b 1023.721k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 9025 -u -b 200.003k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 9026 -u -b 377.364k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 9027 -u -b 403.429k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 9028 -u -b 1043.497k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 9029 -u -b 791.292k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 9030 -u -b 993.918k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 9031 -u -b 153.182k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 9032 -u -b 1096.378k -w 256k -t 30 &
sleep 0.4