 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 3001 -u -b 8512.553k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 3002 -u -b 6908.038k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 3008 -u -b 1685.726k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 3009 -u -b 1632.476k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 3010 -u -b 7703.793k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 3011 -u -b 5103.439k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 3012 -u -b 1030.475k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 3014 -u -b 8997.495k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 3015 -u -b 15.408k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 3016 -u -b 1246.266k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 3017 -u -b 7502.045k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 3018 -u -b 9060.867k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 3019 -u -b 2827.135k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 3021 -u -b 5984.392k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 3022 -u -b 4233.681k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 3023 -u -b 3493.373k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 3024 -u -b 771.446k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 3026 -u -b 1560.620k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 3027 -u -b 1668.415k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 3028 -u -b 4315.465k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 3030 -u -b 4110.428k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 3031 -u -b 633.498k -w 256k -t 30 &
sleep 0.4