 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 14001 -u -b 11344.834k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 14002 -u -b 9206.468k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 14004 -u -b 6217.839k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 14005 -u -b 3588.825k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 14006 -u -b 8184.911k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 14007 -u -b 1165.482k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 14011 -u -b 6801.445k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 14013 -u -b 1748.700k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 14015 -u -b 20.535k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 14016 -u -b 1660.922k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 14017 -u -b 9998.111k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 14018 -u -b 12075.583k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 14019 -u -b 3767.775k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 14020 -u -b 112.710k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 14021 -u -b 7975.508k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 14022 -u -b 5642.304k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 14023 -u -b 4655.681k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 14024 -u -b 1028.120k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 14025 -u -b 1102.331k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 14028 -u -b 5751.298k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 14029 -u -b 4361.255k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 14030 -u -b 5478.042k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 14031 -u -b 844.275k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 14032 -u -b 6042.754k -w 256k -t 30 &
sleep 0.4