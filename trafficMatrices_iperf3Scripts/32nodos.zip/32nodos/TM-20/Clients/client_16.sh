 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 16001 -u -b 1571.402k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 16002 -u -b 1275.212k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 16006 -u -b 1133.713k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 16007 -u -b 161.434k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 16008 -u -b 311.182k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 16010 -u -b 1422.107k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 16011 -u -b 942.086k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 16014 -u -b 1660.922k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 16015 -u -b 2.844k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 16017 -u -b 1384.864k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 16020 -u -b 15.612k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 16022 -u -b 781.530k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 16025 -u -b 152.687k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 16027 -u -b 307.986k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 16028 -u -b 796.627k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 16029 -u -b 604.089k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 16030 -u -b 758.778k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 16031 -u -b 116.943k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 16032 -u -b 836.997k -w 256k -t 30 &
sleep 0.4