 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 15001 -u -b 19.428k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 15002 -u -b 15.766k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 15003 -u -b 15.408k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 15004 -u -b 10.648k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 15005 -u -b 6.146k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 15006 -u -b 14.016k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 15007 -u -b 1.996k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 15009 -u -b 3.726k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 15010 -u -b 17.582k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 15011 -u -b 11.647k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 15013 -u -b 2.995k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 15014 -u -b 20.535k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 15016 -u -b 2.844k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 15017 -u -b 17.122k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 15018 -u -b 20.679k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 15019 -u -b 6.452k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 15020 -u -b 0.193k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 15021 -u -b 13.658k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 15022 -u -b 9.662k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 15023 -u -b 7.973k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 15024 -u -b 1.761k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 15025 -u -b 1.888k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 15026 -u -b 3.562k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 15028 -u -b 9.849k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 15030 -u -b 9.381k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 15031 -u -b 1.446k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 15032 -u -b 10.348k -w 256k -t 30 &
sleep 0.4