 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 23002 -u -b 3574.509k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 23003 -u -b 3493.373k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 23004 -u -b 2414.142k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 23006 -u -b 3177.878k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 23007 -u -b 452.511k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 23008 -u -b 872.265k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 23009 -u -b 844.712k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 23010 -u -b 3986.265k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 23011 -u -b 2640.733k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 23013 -u -b 678.951k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 23015 -u -b 7.973k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 23017 -u -b 3881.872k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 23018 -u -b 4688.473k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 23019 -u -b 1462.878k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 23021 -u -b 3096.575k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 23022 -u -b 2190.684k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 23024 -u -b 399.179k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 23025 -u -b 427.992k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 23026 -u -b 807.530k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 23028 -u -b 2233.002k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 23029 -u -b 1693.303k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 23031 -u -b 327.799k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 23032 -u -b 2346.163k -w 256k -t 30 &
sleep 0.4