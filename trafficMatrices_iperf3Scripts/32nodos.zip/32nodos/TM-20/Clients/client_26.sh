 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 26001 -u -b 1967.768k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 26002 -u -b 1596.867k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 26003 -u -b 1560.620k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 26005 -u -b 622.484k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 26006 -u -b 1419.677k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 26008 -u -b 389.674k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 26009 -u -b 377.364k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 26010 -u -b 1780.814k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 26011 -u -b 1179.714k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 26012 -u -b 238.205k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 26013 -u -b 303.313k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 26014 -u -b 2079.867k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 26015 -u -b 3.562k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 26017 -u -b 1734.178k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 26018 -u -b 2094.516k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 26019 -u -b 653.523k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 26021 -u -b 1383.356k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 26022 -u -b 978.661k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 26023 -u -b 807.530k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 26028 -u -b 997.566k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 26029 -u -b 756.462k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 26030 -u -b 950.169k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 26032 -u -b 1048.119k -w 256k -t 30 &
sleep 0.4