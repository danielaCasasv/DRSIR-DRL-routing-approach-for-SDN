 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 4001 -u -b 5882.713k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 4002 -u -b 4773.892k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 4003 -u -b 4665.532k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 4005 -u -b 1860.938k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 4006 -u -b 4244.177k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 4007 -u -b 604.345k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 4008 -u -b 1164.944k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 4009 -u -b 1128.145k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 4011 -u -b 3526.799k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 4015 -u -b 10.648k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 4016 -u -b 861.249k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 4017 -u -b 5184.388k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 4018 -u -b 6261.634k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 4019 -u -b 1953.730k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 4020 -u -b 58.444k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 4021 -u -b 4135.594k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 4022 -u -b 2925.742k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 4026 -u -b 1078.488k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 4027 -u -b 1152.980k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 4028 -u -b 2982.259k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 4029 -u -b 2261.471k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 4030 -u -b 2840.566k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 4032 -u -b 3133.390k -w 256k -t 30 &
sleep 0.4