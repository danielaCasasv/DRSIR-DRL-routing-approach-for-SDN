 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 28001 -u -b 5441.318k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 28004 -u -b 2982.259k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 28005 -u -b 1721.307k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 28007 -u -b 559.000k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 28008 -u -b 1077.535k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 28011 -u -b 3262.174k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 28012 -u -b 658.691k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 28013 -u -b 838.728k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 28014 -u -b 5751.298k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 28015 -u -b 9.849k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 28016 -u -b 796.627k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 28019 -u -b 1807.136k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 28020 -u -b 54.059k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 28023 -u -b 2233.002k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 28024 -u -b 493.117k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 28025 -u -b 528.711k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 28026 -u -b 997.566k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 28027 -u -b 1066.469k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 28029 -u -b 2091.787k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 28030 -u -b 2627.431k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 28031 -u -b 404.939k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 28032 -u -b 2898.283k -w 256k -t 30 &
sleep 0.4