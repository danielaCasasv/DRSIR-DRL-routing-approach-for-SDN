 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 13002 -u -b 1342.605k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 13003 -u -b 1312.130k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 13004 -u -b 906.765k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 13005 -u -b 523.369k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 13006 -u -b 1193.629k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 13007 -u -b 169.966k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 13008 -u -b 327.628k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 13010 -u -b 1497.264k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 13011 -u -b 991.874k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 13012 -u -b 200.277k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 13014 -u -b 1748.700k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 13015 -u -b 2.995k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 13016 -u -b 242.217k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 13017 -u -b 1458.053k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 13018 -u -b 1761.017k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 13019 -u -b 549.465k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 13022 -u -b 822.833k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 13023 -u -b 678.951k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 13024 -u -b 149.934k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 13026 -u -b 303.313k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 13027 -u -b 324.263k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 13030 -u -b 798.878k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 13031 -u -b 123.123k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 13032 -u -b 881.232k -w 256k -t 30 &
sleep 0.4