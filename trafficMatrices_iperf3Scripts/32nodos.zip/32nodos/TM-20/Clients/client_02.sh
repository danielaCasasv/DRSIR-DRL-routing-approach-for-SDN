 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 2001 -u -b 8710.263k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 2003 -u -b 6908.038k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 2004 -u -b 4773.892k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 2005 -u -b 2755.405k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 2006 -u -b 6284.158k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 2007 -u -b 894.826k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 2011 -u -b 5221.969k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 2012 -u -b 1054.409k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 2013 -u -b 1342.605k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 2014 -u -b 9206.468k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 2015 -u -b 15.766k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 2017 -u -b 7676.285k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 2018 -u -b 9271.312k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 2019 -u -b 2892.798k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 2020 -u -b 86.536k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 2021 -u -b 6123.383k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 2022 -u -b 4332.011k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 2023 -u -b 3574.509k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 2024 -u -b 789.364k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 2025 -u -b 846.341k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 2027 -u -b 1707.165k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 2029 -u -b 3348.456k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 2030 -u -b 4205.896k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 2031 -u -b 648.212k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 2032 -u -b 4639.466k -w 256k -t 30 &
sleep 0.4