 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 11002 -u -b 5221.969k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 11003 -u -b 5103.439k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 11005 -u -b 2035.605k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 11006 -u -b 4642.536k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 11007 -u -b 661.069k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 11009 -u -b 1234.032k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 11012 -u -b 778.964k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 11013 -u -b 991.874k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 11014 -u -b 6801.445k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 11015 -u -b 11.647k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 11016 -u -b 942.086k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 11017 -u -b 5670.995k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 11018 -u -b 6849.350k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 11019 -u -b 2137.107k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 11020 -u -b 63.930k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 11021 -u -b 4523.761k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 11022 -u -b 3200.352k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 11024 -u -b 583.157k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 11025 -u -b 625.250k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 11026 -u -b 1179.714k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 11028 -u -b 3262.174k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 11029 -u -b 2473.732k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 11030 -u -b 3107.182k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 11031 -u -b 478.878k -w 256k -t 30 &
sleep 0.4