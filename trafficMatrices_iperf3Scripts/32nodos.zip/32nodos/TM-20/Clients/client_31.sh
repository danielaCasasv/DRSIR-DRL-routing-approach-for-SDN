 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 31001 -u -b 798.770k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 31002 -u -b 648.212k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 31003 -u -b 633.498k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 31004 -u -b 437.787k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 31005 -u -b 252.683k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 31006 -u -b 576.286k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 31008 -u -b 158.179k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 31009 -u -b 153.182k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 31010 -u -b 722.881k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 31011 -u -b 478.878k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 31013 -u -b 123.123k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 31014 -u -b 844.275k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 31016 -u -b 116.943k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 31018 -u -b 850.221k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 31019 -u -b 265.283k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 31020 -u -b 7.936k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 31021 -u -b 561.542k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 31022 -u -b 397.265k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 31023 -u -b 327.799k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 31025 -u -b 77.613k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 31026 -u -b 146.440k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 31027 -u -b 156.555k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 31028 -u -b 404.939k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 31029 -u -b 307.068k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 31032 -u -b 425.460k -w 256k -t 30 &
sleep 0.4