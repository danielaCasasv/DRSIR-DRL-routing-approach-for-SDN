 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 23002 -u -b 4357.448k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 23003 -u -b 4258.541k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 23004 -u -b 2942.922k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 23006 -u -b 3873.943k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 23007 -u -b 551.626k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 23008 -u -b 1063.321k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 23009 -u -b 1029.733k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 23010 -u -b 4859.394k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 23011 -u -b 3219.144k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 23013 -u -b 827.665k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 23015 -u -b 9.719k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 23017 -u -b 4732.136k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 23018 -u -b 5715.409k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 23019 -u -b 1783.299k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 23021 -u -b 3774.831k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 23022 -u -b 2670.519k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 23024 -u -b 486.612k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 23025 -u -b 521.737k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 23026 -u -b 984.407k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 23028 -u -b 2722.106k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 23029 -u -b 2064.195k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 23031 -u -b 399.598k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 23032 -u -b 2860.053k -w 256k -t 30 &
sleep 0.4