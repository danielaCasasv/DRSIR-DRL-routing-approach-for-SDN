 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 9001 -u -b 2509.224k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 9004 -u -b 1375.247k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 9005 -u -b 793.768k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 9007 -u -b 257.779k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 9008 -u -b 496.897k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 9012 -u -b 303.751k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 9014 -u -b 2652.169k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 9016 -u -b 367.359k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 9018 -u -b 2670.849k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 9019 -u -b 833.348k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 9020 -u -b 24.929k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 9022 -u -b 1247.951k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 9025 -u -b 243.811k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 9026 -u -b 460.020k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 9027 -u -b 491.794k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 9028 -u -b 1272.058k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 9029 -u -b 964.612k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 9030 -u -b 1211.620k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 9031 -u -b 186.735k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 9032 -u -b 1336.522k -w 256k -t 30 &
sleep 0.4