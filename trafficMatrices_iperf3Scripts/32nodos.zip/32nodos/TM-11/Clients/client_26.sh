 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 26001 -u -b 2398.776k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 26002 -u -b 1946.635k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 26003 -u -b 1902.450k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 26005 -u -b 758.829k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 26006 -u -b 1730.635k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 26008 -u -b 475.025k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 26009 -u -b 460.020k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 26010 -u -b 2170.873k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 26011 -u -b 1438.112k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 26012 -u -b 290.381k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 26013 -u -b 369.749k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 26014 -u -b 2535.429k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 26015 -u -b 4.342k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 26017 -u -b 2114.022k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 26018 -u -b 2553.287k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 26019 -u -b 796.666k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 26021 -u -b 1686.359k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 26022 -u -b 1193.021k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 26023 -u -b 984.407k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 26028 -u -b 1216.067k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 26029 -u -b 922.153k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 26030 -u -b 1158.289k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 26032 -u -b 1277.693k -w 256k -t 30 &
sleep 0.4