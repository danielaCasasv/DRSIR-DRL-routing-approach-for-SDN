 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 21002 -u -b 7464.614k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 21003 -u -b 7295.179k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 21004 -u -b 5041.431k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 21005 -u -b 2909.823k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 21007 -u -b 944.974k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 21008 -u -b 1821.544k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 21009 -u -b 1764.004k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 21011 -u -b 5514.619k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 21013 -u -b 1417.848k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 21014 -u -b 9722.417k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 21015 -u -b 16.649k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 21016 -u -b 1346.677k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 21017 -u -b 8106.479k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 21020 -u -b 91.385k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 21024 -u -b 833.601k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 21025 -u -b 893.772k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 21026 -u -b 1686.359k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 21028 -u -b 4663.159k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 21030 -u -b 4441.602k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 21032 -u -b 4899.471k -w 256k -t 30 &
sleep 0.4