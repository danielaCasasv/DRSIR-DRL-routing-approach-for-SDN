 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 24001 -u -b 1185.764k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 24003 -u -b 940.419k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 24004 -u -b 649.889k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 24007 -u -b 121.816k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 24008 -u -b 234.815k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 24009 -u -b 227.397k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 24010 -u -b 1073.107k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 24011 -u -b 710.888k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 24012 -u -b 143.541k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 24013 -u -b 182.774k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 24015 -u -b 2.146k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 24016 -u -b 173.600k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 24017 -u -b 1045.004k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 24018 -u -b 1262.142k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 24019 -u -b 393.808k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 24022 -u -b 589.734k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 24023 -u -b 486.612k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 24026 -u -b 217.388k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 24027 -u -b 232.403k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 24028 -u -b 601.126k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 24030 -u -b 572.566k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 24032 -u -b 631.589k -w 256k -t 30 &
sleep 0.4