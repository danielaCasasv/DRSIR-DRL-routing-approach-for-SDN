 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 27001 -u -b 2564.463k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 27002 -u -b 2081.092k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 27003 -u -b 2033.855k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 27004 -u -b 1405.522k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 27006 -u -b 1850.173k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 27007 -u -b 263.453k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 27010 -u -b 2320.819k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 27011 -u -b 1537.445k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 27012 -u -b 310.437k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 27015 -u -b 4.642k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 27016 -u -b 375.446k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 27018 -u -b 2729.646k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 27019 -u -b 851.693k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 27020 -u -b 25.478k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 27021 -u -b 1802.838k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 27022 -u -b 1275.424k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 27023 -u -b 1052.402k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 27029 -u -b 985.847k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 27030 -u -b 1238.294k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 27031 -u -b 190.846k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 27032 -u -b 1365.945k -w 256k -t 30 &
sleep 0.4