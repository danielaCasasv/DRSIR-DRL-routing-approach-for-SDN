 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.3 -p 17003 -u -b 9145.250k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 17004 -u -b 6319.947k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 17005 -u -b 3647.760k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 17006 -u -b 8319.322k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 17008 -u -b 2283.491k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 17009 -u -b 2211.359k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 17010 -u -b 10435.587k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 17011 -u -b 6913.137k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 17012 -u -b 1395.886k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 17013 -u -b 1777.417k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 17014 -u -b 12188.040k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 17015 -u -b 20.872k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 17018 -u -b 12273.885k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 17019 -u -b 3829.648k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 17021 -u -b 8106.479k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 17022 -u -b 5734.960k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 17024 -u -b 1045.004k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 17025 -u -b 1120.434k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 17026 -u -b 2114.022k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 17029 -u -b 4432.874k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 17031 -u -b 858.139k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 17032 -u -b 6141.986k -w 256k -t 30 &
sleep 0.4