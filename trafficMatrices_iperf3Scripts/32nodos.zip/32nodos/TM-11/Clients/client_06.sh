 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 6001 -u -b 9439.915k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 6002 -u -b 7660.604k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 6003 -u -b 7486.720k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 6005 -u -b 2986.223k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 6007 -u -b 969.785k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 6008 -u -b 1869.370k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 6009 -u -b 1810.319k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 6010 -u -b 8543.048k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 6012 -u -b 1142.736k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 6013 -u -b 1455.075k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 6014 -u -b 9977.687k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 6016 -u -b 1382.035k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 6017 -u -b 8319.322k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 6018 -u -b 10047.963k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 6019 -u -b 3135.125k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 6020 -u -b 93.785k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 6021 -u -b 6636.335k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 6022 -u -b 4694.901k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 6025 -u -b 917.238k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 6026 -u -b 1730.635k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 6027 -u -b 1850.173k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 6028 -u -b 4785.594k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 6029 -u -b 3628.953k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 6030 -u -b 4558.220k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 6031 -u -b 702.512k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 6032 -u -b 5028.111k -w 256k -t 30 &
sleep 0.4