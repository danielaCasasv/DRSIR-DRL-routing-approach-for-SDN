 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 18001 -u -b 13927.149k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 18002 -u -b 11302.047k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 18003 -u -b 11045.508k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 18007 -u -b 1430.769k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 18008 -u -b 2757.969k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 18010 -u -b 12603.959k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 18011 -u -b 8349.593k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 18012 -u -b 1685.932k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 18013 -u -b 2146.740k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 18014 -u -b 14720.549k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 18015 -u -b 25.209k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 18017 -u -b 12273.885k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 18019 -u -b 4625.397k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 18020 -u -b 138.365k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 18021 -u -b 9790.895k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 18024 -u -b 1262.142k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 18026 -u -b 2553.287k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 18029 -u -b 5353.965k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 18030 -u -b 6724.956k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 18032 -u -b 7418.208k -w 256k -t 30 &
sleep 0.4