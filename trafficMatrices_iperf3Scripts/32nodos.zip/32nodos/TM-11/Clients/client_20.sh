 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 20001 -u -b 129.992k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 20002 -u -b 105.490k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 20004 -u -b 71.246k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 20006 -u -b 93.785k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 20007 -u -b 13.354k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 20008 -u -b 25.742k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 20009 -u -b 24.929k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 20011 -u -b 77.933k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 20012 -u -b 15.736k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 20014 -u -b 137.397k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 20016 -u -b 19.031k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 20018 -u -b 138.365k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 20019 -u -b 43.172k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 20023 -u -b 53.346k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 20024 -u -b 11.780k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 20026 -u -b 23.832k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 20027 -u -b 25.478k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 20028 -u -b 65.900k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 20029 -u -b 49.972k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 20031 -u -b 9.674k -w 256k -t 30 &
sleep 0.4