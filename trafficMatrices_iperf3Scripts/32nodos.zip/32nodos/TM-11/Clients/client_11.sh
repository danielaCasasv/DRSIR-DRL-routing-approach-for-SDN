 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 11002 -u -b 6365.760k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 11003 -u -b 6221.267k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 11005 -u -b 2481.473k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 11006 -u -b 5659.410k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 11007 -u -b 805.866k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 11009 -u -b 1504.328k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 11012 -u -b 949.583k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 11013 -u -b 1209.129k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 11014 -u -b 8291.195k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 11015 -u -b 14.198k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 11016 -u -b 1148.435k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 11017 -u -b 6913.137k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 11018 -u -b 8349.593k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 11019 -u -b 2605.206k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 11020 -u -b 77.933k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 11021 -u -b 5514.619k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 11022 -u -b 3901.339k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 11024 -u -b 710.888k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 11025 -u -b 762.201k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 11026 -u -b 1438.112k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 11028 -u -b 3976.702k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 11029 -u -b 3015.565k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 11030 -u -b 3787.761k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 11031 -u -b 583.769k -w 256k -t 30 &
sleep 0.4