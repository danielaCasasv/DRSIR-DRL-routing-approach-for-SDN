 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 13002 -u -b 1636.682k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 13003 -u -b 1599.532k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 13004 -u -b 1105.378k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 13005 -u -b 638.004k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 13006 -u -b 1455.075k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 13007 -u -b 207.194k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 13008 -u -b 399.389k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 13010 -u -b 1825.216k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 13011 -u -b 1209.129k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 13012 -u -b 244.145k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 13014 -u -b 2131.725k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 13015 -u -b 3.651k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 13016 -u -b 295.271k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 13017 -u -b 1777.417k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 13018 -u -b 2146.740k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 13019 -u -b 669.817k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 13022 -u -b 1003.062k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 13023 -u -b 827.665k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 13024 -u -b 182.774k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 13026 -u -b 369.749k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 13027 -u -b 395.288k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 13030 -u -b 973.860k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 13031 -u -b 150.091k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 13032 -u -b 1074.252k -w 256k -t 30 &
sleep 0.4