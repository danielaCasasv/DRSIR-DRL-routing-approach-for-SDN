 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 25001 -u -b 1271.354k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 25002 -u -b 1031.719k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 25003 -u -b 1008.300k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 25005 -u -b 402.180k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 25007 -u -b 130.609k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 25008 -u -b 251.764k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 25009 -u -b 243.811k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 25010 -u -b 1150.565k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 25011 -u -b 762.201k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 25012 -u -b 153.902k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 25013 -u -b 195.967k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 25015 -u -b 2.301k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 25016 -u -b 186.130k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 25018 -u -b 1353.245k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 25019 -u -b 422.234k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 25020 -u -b 12.631k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 25021 -u -b 893.772k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 25022 -u -b 632.302k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 25023 -u -b 521.737k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 25024 -u -b 115.216k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 25026 -u -b 233.079k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 25027 -u -b 249.178k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 25028 -u -b 644.517k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 25029 -u -b 488.742k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 25030 -u -b 613.894k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 25031 -u -b 94.613k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 25032 -u -b 677.178k -w 256k -t 30 &
sleep 0.4