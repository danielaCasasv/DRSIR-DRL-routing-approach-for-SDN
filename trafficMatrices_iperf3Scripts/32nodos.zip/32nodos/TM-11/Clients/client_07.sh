 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 7001 -u -b 1344.187k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 7002 -u -b 1090.824k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 7004 -u -b 736.717k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 7006 -u -b 969.785k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 7009 -u -b 257.779k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 7011 -u -b 805.866k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 7012 -u -b 162.719k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 7013 -u -b 207.194k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 7015 -u -b 2.433k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 7016 -u -b 196.793k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 7018 -u -b 1430.769k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 7019 -u -b 446.423k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 7020 -u -b 13.354k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 7021 -u -b 944.974k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 7025 -u -b 130.609k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 7027 -u -b 263.453k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 7028 -u -b 681.440k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 7029 -u -b 516.741k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 7030 -u -b 649.063k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 7032 -u -b 715.973k -w 256k -t 30 &
sleep 0.4