 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 5002 -u -b 3358.933k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 5003 -u -b 3282.690k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 5004 -u -b 2268.547k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 5006 -u -b 2986.223k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 5007 -u -b 425.220k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 5008 -u -b 819.660k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 5009 -u -b 793.768k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 5010 -u -b 3745.857k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 5012 -u -b 501.054k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 5013 -u -b 638.004k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 5014 -u -b 4374.901k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 5015 -u -b 7.492k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 5017 -u -b 3647.760k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 5018 -u -b 4405.715k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 5019 -u -b 1374.654k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 5020 -u -b 41.122k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 5024 -u -b 375.105k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 5025 -u -b 402.180k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 5026 -u -b 758.829k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 5027 -u -b 811.242k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 5028 -u -b 2098.332k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 5029 -u -b 1591.182k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 5030 -u -b 1998.636k -w 256k -t 30 &
sleep 0.4