 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 30001 -u -b 6317.998k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 30004 -u -b 3462.748k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 30007 -u -b 649.063k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 30008 -u -b 1251.142k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 30009 -u -b 1211.620k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 30011 -u -b 3787.761k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 30012 -u -b 764.816k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 30013 -u -b 973.860k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 30016 -u -b 924.976k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 30017 -u -b 5568.001k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 30019 -u -b 2098.294k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 30020 -u -b 62.769k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 30021 -u -b 4441.602k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 30023 -u -b 2592.773k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 30024 -u -b 572.566k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 30027 -u -b 1238.294k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 30028 -u -b 3202.928k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 30032 -u -b 3365.242k -w 256k -t 30 &
sleep 0.4