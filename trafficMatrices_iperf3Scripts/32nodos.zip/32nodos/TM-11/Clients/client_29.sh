 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 29001 -u -b 5029.972k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 29002 -u -b 4081.882k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 29003 -u -b 3989.230k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 29004 -u -b 2756.810k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 29005 -u -b 1591.182k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 29006 -u -b 3628.953k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 29008 -u -b 996.077k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 29010 -u -b 4552.085k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 29011 -u -b 3015.565k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 29013 -u -b 775.323k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 29016 -u -b 736.405k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 29017 -u -b 4432.874k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 29018 -u -b 5353.965k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 29020 -u -b 49.972k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 29022 -u -b 2501.635k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 29024 -u -b 455.839k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 29025 -u -b 488.742k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 29026 -u -b 922.153k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 29027 -u -b 985.847k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 29030 -u -b 2428.806k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 29031 -u -b 374.327k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 29032 -u -b 2679.183k -w 256k -t 30 &
sleep 0.4