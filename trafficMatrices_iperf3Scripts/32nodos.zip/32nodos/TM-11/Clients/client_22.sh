 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 22001 -u -b 6507.446k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 22002 -u -b 5280.870k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 22003 -u -b 5161.002k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 22004 -u -b 3566.580k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 22006 -u -b 4694.901k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 22007 -u -b 668.525k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 22008 -u -b 1288.658k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 22010 -u -b 5889.187k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 22013 -u -b 1003.062k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 22014 -u -b 6878.162k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 22015 -u -b 11.779k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 22016 -u -b 952.712k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 22017 -u -b 5734.960k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 22018 -u -b 6926.607k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 22019 -u -b 2161.212k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 22021 -u -b 4574.786k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 22023 -u -b 2670.519k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 22024 -u -b 589.734k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 22025 -u -b 632.302k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 22026 -u -b 1193.021k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 22030 -u -b 3142.229k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 22031 -u -b 484.280k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 22032 -u -b 3466.150k -w 256k -t 30 &
sleep 0.4