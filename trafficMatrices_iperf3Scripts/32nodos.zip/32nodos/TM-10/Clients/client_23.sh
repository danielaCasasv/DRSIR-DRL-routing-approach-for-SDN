 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 23002 -u -b 4407.509k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 23003 -u -b 4307.465k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 23004 -u -b 2976.731k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 23006 -u -b 3918.449k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 23007 -u -b 557.963k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 23008 -u -b 1075.537k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 23009 -u -b 1041.563k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 23010 -u -b 4915.221k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 23011 -u -b 3256.127k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 23013 -u -b 837.173k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 23015 -u -b 9.831k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 23017 -u -b 4786.501k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 23018 -u -b 5781.071k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 23019 -u -b 1803.786k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 23021 -u -b 3818.199k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 23022 -u -b 2701.199k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 23024 -u -b 492.203k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 23025 -u -b 527.731k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 23026 -u -b 995.717k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 23028 -u -b 2753.379k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 23029 -u -b 2087.909k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 23031 -u -b 404.188k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 23032 -u -b 2892.911k -w 256k -t 30 &
sleep 0.4