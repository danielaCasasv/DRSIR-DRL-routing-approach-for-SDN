 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 14001 -u -b 13988.625k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 14002 -u -b 11351.936k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 14004 -u -b 7666.839k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 14005 -u -b 4425.162k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 14006 -u -b 10092.316k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 14007 -u -b 1437.085k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 14011 -u -b 8386.449k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 14013 -u -b 2156.216k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 14015 -u -b 25.320k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 14016 -u -b 2047.981k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 14017 -u -b 12328.063k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 14018 -u -b 14889.667k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 14019 -u -b 4645.814k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 14020 -u -b 138.976k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 14021 -u -b 9834.114k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 14022 -u -b 6957.182k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 14023 -u -b 5740.637k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 14024 -u -b 1267.713k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 14025 -u -b 1359.218k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 14028 -u -b 7091.576k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 14029 -u -b 5377.598k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 14030 -u -b 6754.641k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 14031 -u -b 1041.024k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 14032 -u -b 7450.952k -w 256k -t 30 &
sleep 0.4