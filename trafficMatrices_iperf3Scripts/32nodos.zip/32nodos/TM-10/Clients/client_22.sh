 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 22001 -u -b 6582.207k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 22002 -u -b 5341.540k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 22003 -u -b 5220.295k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 22004 -u -b 3607.554k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 22006 -u -b 4748.838k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 22007 -u -b 676.206k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 22008 -u -b 1303.463k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 22010 -u -b 5956.845k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 22013 -u -b 1014.586k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 22014 -u -b 6957.182k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 22015 -u -b 11.914k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 22016 -u -b 963.657k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 22017 -u -b 5800.847k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 22018 -u -b 7006.183k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 22019 -u -b 2186.041k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 22021 -u -b 4627.344k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 22023 -u -b 2701.199k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 22024 -u -b 596.510k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 22025 -u -b 639.566k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 22026 -u -b 1206.727k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 22030 -u -b 3178.328k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 22031 -u -b 489.843k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 22032 -u -b 3505.971k -w 256k -t 30 &
sleep 0.4