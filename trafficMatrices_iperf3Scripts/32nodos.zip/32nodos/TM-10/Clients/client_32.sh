 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 32001 -u -b 7049.365k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 32002 -u -b 5720.644k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 32003 -u -b 5590.794k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 32004 -u -b 3863.593k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 32005 -u -b 2229.997k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 32006 -u -b 5085.877k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 32007 -u -b 724.198k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 32008 -u -b 1395.973k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 32009 -u -b 1351.877k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 32010 -u -b 6379.619k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 32012 -u -b 853.351k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 32013 -u -b 1086.594k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 32014 -u -b 7450.952k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 32015 -u -b 12.760k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 32016 -u -b 1032.051k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 32018 -u -b 7503.432k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 32020 -u -b 70.035k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 32022 -u -b 3505.971k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 32023 -u -b 2892.911k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 32026 -u -b 1292.372k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 32029 -u -b 2709.963k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 32031 -u -b 524.609k -w 256k -t 30 &
sleep 0.4