 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 25001 -u -b 1285.960k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 25002 -u -b 1043.571k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 25003 -u -b 1019.884k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 25005 -u -b 406.801k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 25007 -u -b 132.110k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 25008 -u -b 254.656k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 25009 -u -b 246.612k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 25010 -u -b 1163.783k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 25011 -u -b 770.957k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 25012 -u -b 155.670k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 25013 -u -b 198.219k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 25015 -u -b 2.328k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 25016 -u -b 188.269k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 25018 -u -b 1368.791k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 25019 -u -b 427.085k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 25020 -u -b 12.776k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 25021 -u -b 904.040k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 25022 -u -b 639.566k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 25023 -u -b 527.731k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 25024 -u -b 116.539k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 25026 -u -b 235.757k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 25027 -u -b 252.041k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 25028 -u -b 651.921k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 25029 -u -b 494.357k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 25030 -u -b 620.947k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 25031 -u -b 95.700k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 25032 -u -b 684.958k -w 256k -t 30 &
sleep 0.4