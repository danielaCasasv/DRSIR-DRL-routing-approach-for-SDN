 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 16001 -u -b 1937.600k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 16002 -u -b 1572.386k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 16006 -u -b 1397.913k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 16007 -u -b 199.054k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 16008 -u -b 383.700k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 16010 -u -b 1753.513k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 16011 -u -b 1161.629k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 16014 -u -b 2047.981k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 16015 -u -b 3.507k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 16017 -u -b 1707.592k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 16020 -u -b 19.250k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 16022 -u -b 963.657k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 16025 -u -b 188.269k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 16027 -u -b 379.759k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 16028 -u -b 982.272k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 16029 -u -b 744.865k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 16030 -u -b 935.603k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 16031 -u -b 144.195k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 16032 -u -b 1032.051k -w 256k -t 30 &
sleep 0.4