 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 19001 -u -b 4395.416k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 19003 -u -b 3485.969k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 19004 -u -b 2409.025k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 19007 -u -b 451.552k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 19008 -u -b 870.417k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 19009 -u -b 842.921k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 19011 -u -b 2635.136k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 19014 -u -b 4645.814k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 19015 -u -b 7.956k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 19016 -u -b 643.504k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 19017 -u -b 3873.645k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 19020 -u -b 43.668k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 19021 -u -b 3090.012k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 19023 -u -b 1803.786k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 19024 -u -b 398.333k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 19025 -u -b 427.085k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 19026 -u -b 805.819k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 19027 -u -b 861.478k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 19028 -u -b 2228.270k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 19029 -u -b 1689.714k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 19030 -u -b 2122.400k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 19031 -u -b 327.104k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 19032 -u -b 2341.191k -w 256k -t 30 &
sleep 0.4