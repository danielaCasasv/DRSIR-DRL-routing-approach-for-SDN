 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 15001 -u -b 23.955k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 15002 -u -b 19.440k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 15003 -u -b 18.999k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 15004 -u -b 13.129k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 15005 -u -b 7.578k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 15006 -u -b 17.283k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 15007 -u -b 2.461k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 15009 -u -b 4.594k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 15010 -u -b 21.679k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 15011 -u -b 14.362k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 15013 -u -b 3.692k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 15014 -u -b 25.320k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 15016 -u -b 3.507k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 15017 -u -b 21.112k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 15018 -u -b 25.498k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 15019 -u -b 7.956k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 15020 -u -b 0.238k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 15021 -u -b 16.841k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 15022 -u -b 11.914k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 15023 -u -b 9.831k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 15024 -u -b 2.171k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 15025 -u -b 2.328k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 15026 -u -b 4.392k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 15028 -u -b 12.144k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 15030 -u -b 11.567k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 15031 -u -b 1.783k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 15032 -u -b 12.760k -w 256k -t 30 &
sleep 0.4