 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 31001 -u -b 984.915k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 31002 -u -b 799.270k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 31003 -u -b 781.128k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 31004 -u -b 539.809k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 31005 -u -b 311.568k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 31006 -u -b 710.583k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 31008 -u -b 195.041k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 31009 -u -b 188.880k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 31010 -u -b 891.340k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 31011 -u -b 590.475k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 31013 -u -b 151.815k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 31014 -u -b 1041.024k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 31016 -u -b 144.195k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 31018 -u -b 1048.356k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 31019 -u -b 327.104k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 31020 -u -b 9.785k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 31021 -u -b 692.403k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 31022 -u -b 489.843k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 31023 -u -b 404.188k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 31025 -u -b 95.700k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 31026 -u -b 180.566k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 31027 -u -b 193.038k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 31028 -u -b 499.306k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 31029 -u -b 378.627k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 31032 -u -b 524.609k -w 256k -t 30 &
sleep 0.4