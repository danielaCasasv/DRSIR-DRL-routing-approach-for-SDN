 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 24001 -u -b 1199.386k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 24003 -u -b 951.223k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 24004 -u -b 657.356k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 24007 -u -b 123.216k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 24008 -u -b 237.512k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 24009 -u -b 230.010k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 24010 -u -b 1085.435k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 24011 -u -b 719.055k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 24012 -u -b 145.190k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 24013 -u -b 184.874k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 24015 -u -b 2.171k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 24016 -u -b 175.594k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 24017 -u -b 1057.009k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 24018 -u -b 1276.642k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 24019 -u -b 398.333k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 24022 -u -b 596.510k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 24023 -u -b 492.203k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 24026 -u -b 219.885k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 24027 -u -b 235.073k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 24028 -u -b 608.032k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 24030 -u -b 579.144k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 24032 -u -b 638.845k -w 256k -t 30 &
sleep 0.4