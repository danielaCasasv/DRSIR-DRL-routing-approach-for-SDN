 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 18001 -u -b 9391.434k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 18002 -u -b 7621.261k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 18003 -u -b 7448.270k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 18007 -u -b 964.804k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 18008 -u -b 1859.769k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 18010 -u -b 8499.174k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 18011 -u -b 5630.345k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 18012 -u -b 1136.867k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 18013 -u -b 1447.602k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 18014 -u -b 9926.445k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 18015 -u -b 16.999k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 18017 -u -b 8276.596k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 18019 -u -b 3119.024k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 18020 -u -b 93.303k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 18021 -u -b 6602.252k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 18024 -u -b 851.094k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 18026 -u -b 1721.747k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 18029 -u -b 3610.316k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 18030 -u -b 4534.811k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 18032 -u -b 5002.288k -w 256k -t 30 &
sleep 0.4