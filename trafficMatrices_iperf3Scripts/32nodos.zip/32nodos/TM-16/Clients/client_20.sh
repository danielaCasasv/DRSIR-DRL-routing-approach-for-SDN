 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 20001 -u -b 87.657k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 20002 -u -b 71.135k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 20004 -u -b 48.043k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 20006 -u -b 63.242k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 20007 -u -b 9.005k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 20008 -u -b 17.359k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 20009 -u -b 16.810k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 20011 -u -b 52.552k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 20012 -u -b 10.611k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 20014 -u -b 92.651k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 20016 -u -b 12.833k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 20018 -u -b 93.303k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 20019 -u -b 29.112k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 20023 -u -b 35.973k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 20024 -u -b 7.944k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 20026 -u -b 16.070k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 20027 -u -b 17.180k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 20028 -u -b 44.438k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 20029 -u -b 33.698k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 20031 -u -b 6.523k -w 256k -t 30 &
sleep 0.4