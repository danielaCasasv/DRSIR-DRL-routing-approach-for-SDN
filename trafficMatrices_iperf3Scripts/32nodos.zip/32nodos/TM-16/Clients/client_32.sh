 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 32001 -u -b 4699.577k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 32002 -u -b 3813.762k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 32003 -u -b 3727.196k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 32004 -u -b 2575.728k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 32005 -u -b 1486.664k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 32006 -u -b 3390.584k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 32007 -u -b 482.799k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 32008 -u -b 930.649k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 32009 -u -b 901.251k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 32010 -u -b 4253.080k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 32012 -u -b 568.901k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 32013 -u -b 724.396k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 32014 -u -b 4967.302k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 32015 -u -b 8.506k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 32016 -u -b 688.034k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 32018 -u -b 5002.288k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 32020 -u -b 46.690k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 32022 -u -b 2337.314k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 32023 -u -b 1928.607k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 32026 -u -b 861.581k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 32029 -u -b 1806.642k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 32031 -u -b 349.739k -w 256k -t 30 &
sleep 0.4