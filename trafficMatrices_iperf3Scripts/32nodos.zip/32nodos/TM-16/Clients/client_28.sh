 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 28001 -u -b 4472.905k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 28004 -u -b 2451.495k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 28005 -u -b 1414.959k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 28007 -u -b 459.512k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 28008 -u -b 885.762k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 28011 -u -b 2681.592k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 28012 -u -b 541.461k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 28013 -u -b 689.456k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 28014 -u -b 4727.717k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 28015 -u -b 8.096k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 28016 -u -b 654.848k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 28019 -u -b 1485.513k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 28020 -u -b 44.438k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 28023 -u -b 1835.586k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 28024 -u -b 405.355k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 28025 -u -b 434.614k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 28026 -u -b 820.025k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 28027 -u -b 876.665k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 28029 -u -b 1719.503k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 28030 -u -b 2159.817k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 28031 -u -b 332.870k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 28032 -u -b 2382.465k -w 256k -t 30 &
sleep 0.4