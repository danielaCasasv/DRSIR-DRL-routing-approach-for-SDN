 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 19001 -u -b 2930.278k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 19003 -u -b 2323.979k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 19004 -u -b 1606.017k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 19007 -u -b 301.034k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 19008 -u -b 580.278k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 19009 -u -b 561.948k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 19011 -u -b 1756.758k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 19014 -u -b 3097.209k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 19015 -u -b 5.304k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 19016 -u -b 429.002k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 19017 -u -b 2582.430k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 19020 -u -b 29.112k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 19021 -u -b 2060.008k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 19023 -u -b 1202.524k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 19024 -u -b 265.555k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 19025 -u -b 284.723k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 19026 -u -b 537.213k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 19027 -u -b 574.319k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 19028 -u -b 1485.513k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 19029 -u -b 1126.476k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 19030 -u -b 1414.933k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 19031 -u -b 218.069k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 19032 -u -b 1560.794k -w 256k -t 30 &
sleep 0.4