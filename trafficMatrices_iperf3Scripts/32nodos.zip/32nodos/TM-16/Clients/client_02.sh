 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 2001 -u -b 7160.064k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 2003 -u -b 5678.588k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 2004 -u -b 3924.264k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 2005 -u -b 2265.015k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 2006 -u -b 5165.742k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 2007 -u -b 735.570k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 2011 -u -b 4292.595k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 2012 -u -b 866.752k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 2013 -u -b 1103.657k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 2014 -u -b 7567.957k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 2015 -u -b 12.960k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 2017 -u -b 6310.107k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 2018 -u -b 7621.261k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 2019 -u -b 2377.955k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 2020 -u -b 71.135k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 2021 -u -b 5033.581k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 2022 -u -b 3561.026k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 2023 -u -b 2938.339k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 2024 -u -b 648.877k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 2025 -u -b 695.714k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 2027 -u -b 1403.334k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 2029 -u -b 2752.518k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 2030 -u -b 3457.356k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 2031 -u -b 532.847k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 2032 -u -b 3813.762k -w 256k -t 30 &
sleep 0.4