 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 26001 -u -b 1617.556k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 26002 -u -b 1312.666k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 26003 -u -b 1282.871k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 26005 -u -b 511.698k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 26006 -u -b 1167.012k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 26008 -u -b 320.322k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 26009 -u -b 310.203k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 26010 -u -b 1463.876k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 26011 -u -b 969.756k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 26012 -u -b 195.811k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 26013 -u -b 249.331k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 26014 -u -b 1709.705k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 26015 -u -b 2.928k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 26017 -u -b 1425.540k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 26018 -u -b 1721.747k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 26019 -u -b 537.213k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 26021 -u -b 1137.155k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 26022 -u -b 804.485k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 26023 -u -b 663.811k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 26028 -u -b 820.025k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 26029 -u -b 621.832k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 26030 -u -b 781.064k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 26032 -u -b 861.581k -w 256k -t 30 &
sleep 0.4