 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 25001 -u -b 857.306k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 25002 -u -b 695.714k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 25003 -u -b 679.923k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 25005 -u -b 271.200k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 25007 -u -b 88.073k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 25008 -u -b 169.771k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 25009 -u -b 164.408k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 25010 -u -b 775.855k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 25011 -u -b 513.972k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 25012 -u -b 103.780k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 25013 -u -b 132.146k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 25015 -u -b 1.552k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 25016 -u -b 125.513k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 25018 -u -b 912.528k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 25019 -u -b 284.723k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 25020 -u -b 8.517k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 25021 -u -b 602.693k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 25022 -u -b 426.378k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 25023 -u -b 351.820k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 25024 -u -b 77.693k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 25026 -u -b 157.171k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 25027 -u -b 168.027k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 25028 -u -b 434.614k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 25029 -u -b 329.571k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 25030 -u -b 413.965k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 25031 -u -b 63.800k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 25032 -u -b 456.639k -w 256k -t 30 &
sleep 0.4