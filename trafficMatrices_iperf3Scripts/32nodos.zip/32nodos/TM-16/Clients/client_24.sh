 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 24001 -u -b 799.591k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 24003 -u -b 634.149k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 24004 -u -b 438.237k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 24007 -u -b 82.144k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 24008 -u -b 158.342k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 24009 -u -b 153.340k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 24010 -u -b 723.623k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 24011 -u -b 479.370k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 24012 -u -b 96.793k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 24013 -u -b 123.249k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 24015 -u -b 1.447k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 24016 -u -b 117.063k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 24017 -u -b 704.673k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 24018 -u -b 851.094k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 24019 -u -b 265.555k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 24022 -u -b 397.673k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 24023 -u -b 328.135k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 24026 -u -b 146.590k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 24027 -u -b 156.716k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 24028 -u -b 405.355k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 24030 -u -b 386.096k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 24032 -u -b 425.897k -w 256k -t 30 &
sleep 0.4