 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 7001 -u -b 906.420k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 7002 -u -b 735.570k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 7004 -u -b 496.788k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 7006 -u -b 653.951k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 7009 -u -b 173.827k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 7011 -u -b 543.416k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 7012 -u -b 109.725k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 7013 -u -b 139.716k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 7015 -u -b 1.641k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 7016 -u -b 132.703k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 7018 -u -b 964.804k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 7019 -u -b 301.034k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 7020 -u -b 9.005k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 7021 -u -b 637.220k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 7025 -u -b 88.073k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 7027 -u -b 177.653k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 7028 -u -b 459.512k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 7029 -u -b 348.452k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 7030 -u -b 437.680k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 7032 -u -b 482.799k -w 256k -t 30 &
sleep 0.4