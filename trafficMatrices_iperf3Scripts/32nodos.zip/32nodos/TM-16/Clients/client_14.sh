 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 14001 -u -b 9325.750k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 14002 -u -b 7567.957k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 14004 -u -b 5111.226k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 14005 -u -b 2950.108k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 14006 -u -b 6728.211k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 14007 -u -b 958.057k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 14011 -u -b 5590.966k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 14013 -u -b 1437.477k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 14015 -u -b 16.880k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 14016 -u -b 1365.321k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 14017 -u -b 8218.709k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 14018 -u -b 9926.445k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 14019 -u -b 3097.209k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 14020 -u -b 92.651k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 14021 -u -b 6556.076k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 14022 -u -b 4638.121k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 14023 -u -b 3827.092k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 14024 -u -b 845.142k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 14025 -u -b 906.145k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 14028 -u -b 4727.717k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 14029 -u -b 3585.065k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 14030 -u -b 4503.094k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 14031 -u -b 694.016k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 14032 -u -b 4967.302k -w 256k -t 30 &
sleep 0.4