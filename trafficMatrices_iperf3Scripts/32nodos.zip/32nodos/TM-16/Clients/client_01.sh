 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 1002 -u -b 7160.064k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 1003 -u -b 6997.541k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 1005 -u -b 2791.105k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 1006 -u -b 6365.577k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 1008 -u -b 1747.226k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 1009 -u -b 1692.034k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 1010 -u -b 7984.850k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 1011 -u -b 5289.627k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 1012 -u -b 1068.070k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 1014 -u -b 9325.750k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 1015 -u -b 15.970k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 1016 -u -b 1291.734k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 1017 -u -b 7775.741k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 1018 -u -b 9391.434k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 1022 -u -b 4388.138k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 1024 -u -b 799.591k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 1025 -u -b 857.306k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 1026 -u -b 1617.556k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 1028 -u -b 4472.905k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 1029 -u -b 3391.839k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 1030 -u -b 4260.388k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 1031 -u -b 656.610k -w 256k -t 30 &
sleep 0.4