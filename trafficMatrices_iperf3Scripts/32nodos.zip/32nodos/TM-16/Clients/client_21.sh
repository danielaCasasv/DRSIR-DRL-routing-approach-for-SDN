 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 21002 -u -b 5033.581k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 21003 -u -b 4919.326k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 21004 -u -b 3399.566k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 21005 -u -b 1962.169k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 21007 -u -b 637.220k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 21008 -u -b 1228.314k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 21009 -u -b 1189.513k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 21011 -u -b 3718.649k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 21013 -u -b 956.091k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 21014 -u -b 6556.076k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 21015 -u -b 11.227k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 21016 -u -b 908.099k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 21017 -u -b 5466.407k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 21020 -u -b 61.624k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 21024 -u -b 562.119k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 21025 -u -b 602.693k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 21026 -u -b 1137.155k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 21028 -u -b 3144.488k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 21030 -u -b 2995.087k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 21032 -u -b 3303.839k -w 256k -t 30 &
sleep 0.4