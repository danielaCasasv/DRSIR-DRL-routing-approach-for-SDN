 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 16001 -u -b 1291.734k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 16002 -u -b 1048.257k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 16006 -u -b 931.942k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 16007 -u -b 132.703k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 16008 -u -b 255.800k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 16010 -u -b 1169.009k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 16011 -u -b 774.419k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 16014 -u -b 1365.321k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 16015 -u -b 2.338k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 16017 -u -b 1138.395k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 16020 -u -b 12.833k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 16022 -u -b 642.438k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 16025 -u -b 125.513k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 16027 -u -b 253.173k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 16028 -u -b 654.848k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 16029 -u -b 496.577k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 16030 -u -b 623.735k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 16031 -u -b 96.130k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 16032 -u -b 688.034k -w 256k -t 30 &
sleep 0.4