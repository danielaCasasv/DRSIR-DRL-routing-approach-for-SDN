 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 7001 -u -b 1298.911k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 7002 -u -b 1054.082k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 7004 -u -b 711.903k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 7006 -u -b 937.120k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 7009 -u -b 249.096k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 7011 -u -b 778.722k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 7012 -u -b 157.238k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 7013 -u -b 200.215k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 7015 -u -b 2.351k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 7016 -u -b 190.165k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 7018 -u -b 1382.577k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 7019 -u -b 431.386k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 7020 -u -b 12.905k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 7021 -u -b 913.145k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 7025 -u -b 126.210k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 7027 -u -b 254.580k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 7028 -u -b 658.487k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 7029 -u -b 499.336k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 7030 -u -b 627.201k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 7032 -u -b 691.857k -w 256k -t 30 &
sleep 0.4