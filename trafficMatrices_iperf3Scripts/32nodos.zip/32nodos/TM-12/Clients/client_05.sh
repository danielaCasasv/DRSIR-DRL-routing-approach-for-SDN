 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 5002 -u -b 3245.795k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 5003 -u -b 3172.120k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 5004 -u -b 2192.136k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 5006 -u -b 2885.639k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 5007 -u -b 410.898k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 5008 -u -b 792.051k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 5009 -u -b 767.032k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 5010 -u -b 3619.687k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 5012 -u -b 484.177k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 5013 -u -b 616.515k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 5014 -u -b 4227.543k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 5015 -u -b 7.240k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 5017 -u -b 3524.894k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 5018 -u -b 4257.319k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 5019 -u -b 1328.351k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 5020 -u -b 39.737k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 5024 -u -b 362.470k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 5025 -u -b 388.634k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 5026 -u -b 733.270k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 5027 -u -b 783.918k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 5028 -u -b 2027.654k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 5029 -u -b 1537.586k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 5030 -u -b 1931.316k -w 256k -t 30 &
sleep 0.4