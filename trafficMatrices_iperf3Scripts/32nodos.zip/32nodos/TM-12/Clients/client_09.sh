 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 9001 -u -b 2424.706k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 9004 -u -b 1328.925k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 9005 -u -b 767.032k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 9007 -u -b 249.096k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 9008 -u -b 480.160k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 9012 -u -b 293.519k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 9014 -u -b 2562.836k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 9016 -u -b 354.985k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 9018 -u -b 2580.887k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 9019 -u -b 805.278k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 9020 -u -b 24.089k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 9022 -u -b 1205.917k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 9025 -u -b 235.599k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 9026 -u -b 444.525k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 9027 -u -b 475.229k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 9028 -u -b 1229.212k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 9029 -u -b 932.121k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 9030 -u -b 1170.810k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 9031 -u -b 180.445k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 9032 -u -b 1291.504k -w 256k -t 30 &
sleep 0.4