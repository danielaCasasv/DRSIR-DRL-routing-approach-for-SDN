 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 12001 -u -b 1530.558k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 12005 -u -b 484.177k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 12006 -u -b 1104.245k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 12008 -u -b 303.094k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 12009 -u -b 293.519k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 12011 -u -b 917.599k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 12013 -u -b 235.921k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 12014 -u -b 1617.751k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 12015 -u -b 2.770k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 12016 -u -b 224.079k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 12017 -u -b 1348.868k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 12018 -u -b 1629.145k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 12020 -u -b 15.206k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 12021 -u -b 1075.994k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 12022 -u -b 761.216k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 12024 -u -b 138.706k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 12025 -u -b 148.718k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 12028 -u -b 775.921k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 12029 -u -b 588.387k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 12030 -u -b 739.055k -w 256k -t 30 &
sleep 0.4