 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.3 -p 17003 -u -b 8837.213k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 17004 -u -b 6107.074k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 17005 -u -b 3524.894k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 17006 -u -b 8039.104k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 17008 -u -b 2206.577k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 17009 -u -b 2136.874k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 17010 -u -b 10084.088k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 17011 -u -b 6680.284k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 17012 -u -b 1348.868k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 17013 -u -b 1717.548k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 17014 -u -b 11777.514k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 17015 -u -b 20.169k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 17018 -u -b 11860.467k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 17019 -u -b 3700.655k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 17021 -u -b 7833.431k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 17022 -u -b 5541.791k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 17024 -u -b 1009.805k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 17025 -u -b 1082.694k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 17026 -u -b 2042.816k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 17029 -u -b 4283.563k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 17031 -u -b 829.235k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 17032 -u -b 5935.108k -w 256k -t 30 &
sleep 0.4