 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 8001 -u -b 2503.797k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 8002 -u -b 2031.861k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 8005 -u -b 792.051k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 8006 -u -b 1806.405k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 8007 -u -b 257.221k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 8009 -u -b 480.160k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 8010 -u -b 2265.917k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 8012 -u -b 303.094k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 8013 -u -b 385.937k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 8015 -u -b 4.532k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 8016 -u -b 366.564k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 8017 -u -b 2206.577k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 8019 -u -b 831.545k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 8020 -u -b 24.875k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 8021 -u -b 1760.189k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 8022 -u -b 1245.253k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 8023 -u -b 1027.506k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 8026 -u -b 459.025k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 8027 -u -b 490.731k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 8028 -u -b 1269.308k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 8029 -u -b 962.526k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 8030 -u -b 1209.000k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 8031 -u -b 186.331k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 8032 -u -b 1333.632k -w 256k -t 30 &
sleep 0.4