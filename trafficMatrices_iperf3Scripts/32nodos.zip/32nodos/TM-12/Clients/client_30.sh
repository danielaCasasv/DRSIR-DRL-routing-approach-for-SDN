 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 30001 -u -b 6105.191k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 30004 -u -b 3346.113k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 30007 -u -b 627.201k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 30008 -u -b 1209.000k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 30009 -u -b 1170.810k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 30011 -u -b 3660.179k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 30012 -u -b 739.055k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 30013 -u -b 941.058k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 30016 -u -b 893.820k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 30017 -u -b 5380.456k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 30019 -u -b 2027.618k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 30020 -u -b 60.655k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 30021 -u -b 4291.997k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 30023 -u -b 2505.442k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 30024 -u -b 553.280k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 30027 -u -b 1196.585k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 30028 -u -b 3095.045k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 30032 -u -b 3251.891k -w 256k -t 30 &
sleep 0.4