 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 25001 -u -b 1228.531k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 25002 -u -b 996.967k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 25003 -u -b 974.338k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 25005 -u -b 388.634k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 25007 -u -b 126.210k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 25008 -u -b 243.284k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 25009 -u -b 235.599k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 25010 -u -b 1111.811k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 25011 -u -b 736.528k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 25012 -u -b 148.718k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 25013 -u -b 189.367k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 25015 -u -b 2.224k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 25016 -u -b 179.861k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 25018 -u -b 1307.664k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 25019 -u -b 408.012k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 25020 -u -b 12.205k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 25021 -u -b 863.667k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 25022 -u -b 611.004k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 25023 -u -b 504.163k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 25024 -u -b 111.335k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 25026 -u -b 225.229k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 25027 -u -b 240.785k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 25028 -u -b 622.807k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 25029 -u -b 472.280k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 25030 -u -b 593.217k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 25031 -u -b 91.426k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 25032 -u -b 654.369k -w 256k -t 30 &
sleep 0.4