 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 18001 -u -b 13458.045k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 18002 -u -b 10921.364k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 18003 -u -b 10673.465k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 18007 -u -b 1382.577k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 18008 -u -b 2665.073k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 18010 -u -b 12179.424k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 18011 -u -b 8068.356k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 18012 -u -b 1629.145k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 18013 -u -b 2074.432k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 18014 -u -b 14224.721k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 18015 -u -b 24.360k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 18017 -u -b 11860.467k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 18019 -u -b 4469.601k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 18020 -u -b 133.705k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 18021 -u -b 9461.112k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 18024 -u -b 1219.629k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 18026 -u -b 2467.286k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 18029 -u -b 5173.629k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 18030 -u -b 6498.441k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 18032 -u -b 7168.342k -w 256k -t 30 &
sleep 0.4