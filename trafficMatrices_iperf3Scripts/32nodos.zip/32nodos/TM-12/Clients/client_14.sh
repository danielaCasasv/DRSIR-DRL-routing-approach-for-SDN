 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 14001 -u -b 13363.918k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 14002 -u -b 10844.979k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 14004 -u -b 7324.452k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 14005 -u -b 4227.543k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 14006 -u -b 9641.612k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 14007 -u -b 1372.907k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 14011 -u -b 8011.925k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 14013 -u -b 2059.923k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 14015 -u -b 24.189k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 14016 -u -b 1956.522k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 14017 -u -b 11777.514k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 14018 -u -b 14224.721k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 14019 -u -b 4438.340k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 14020 -u -b 132.770k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 14021 -u -b 9394.940k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 14022 -u -b 6646.487k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 14023 -u -b 5484.271k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 14024 -u -b 1211.099k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 14025 -u -b 1298.518k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 14028 -u -b 6774.879k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 14029 -u -b 5137.444k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 14030 -u -b 6452.991k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 14031 -u -b 994.533k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 14032 -u -b 7118.206k -w 256k -t 30 &
sleep 0.4