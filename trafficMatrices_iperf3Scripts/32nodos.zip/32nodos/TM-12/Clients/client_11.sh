 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 11002 -u -b 6151.344k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 11003 -u -b 6011.717k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 11005 -u -b 2397.890k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 11006 -u -b 5468.786k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 11007 -u -b 778.722k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 11009 -u -b 1453.658k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 11012 -u -b 917.599k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 11013 -u -b 1168.402k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 11014 -u -b 8011.925k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 11015 -u -b 13.720k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 11016 -u -b 1109.752k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 11017 -u -b 6680.284k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 11018 -u -b 8068.356k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 11019 -u -b 2517.456k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 11020 -u -b 75.308k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 11021 -u -b 5328.872k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 11022 -u -b 3769.931k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 11024 -u -b 686.943k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 11025 -u -b 736.528k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 11026 -u -b 1389.673k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 11028 -u -b 3842.756k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 11029 -u -b 2913.992k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 11030 -u -b 3660.179k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 11031 -u -b 564.106k -w 256k -t 30 &
sleep 0.4