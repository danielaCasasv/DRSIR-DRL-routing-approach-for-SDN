 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 1002 -u -b 10260.462k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 1003 -u -b 10027.565k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 1005 -u -b 3999.689k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 1006 -u -b 9121.953k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 1008 -u -b 2503.797k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 1009 -u -b 2424.706k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 1010 -u -b 11442.391k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 1011 -u -b 7580.103k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 1012 -u -b 1530.558k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 1014 -u -b 13363.918k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 1015 -u -b 22.885k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 1016 -u -b 1851.071k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 1017 -u -b 11142.736k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 1018 -u -b 13458.045k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 1022 -u -b 6288.258k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 1024 -u -b 1145.824k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 1025 -u -b 1228.531k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 1026 -u -b 2317.979k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 1028 -u -b 6409.730k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 1029 -u -b 4860.549k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 1030 -u -b 6105.191k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 1031 -u -b 940.931k -w 256k -t 30 &
sleep 0.4