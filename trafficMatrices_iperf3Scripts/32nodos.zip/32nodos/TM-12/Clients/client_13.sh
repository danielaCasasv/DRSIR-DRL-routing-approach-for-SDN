 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 13002 -u -b 1581.554k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 13003 -u -b 1545.655k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 13004 -u -b 1068.146k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 13005 -u -b 616.515k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 13006 -u -b 1406.064k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 13007 -u -b 200.215k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 13008 -u -b 385.937k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 13010 -u -b 1763.737k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 13011 -u -b 1168.402k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 13012 -u -b 235.921k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 13014 -u -b 2059.923k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 13015 -u -b 3.528k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 13016 -u -b 285.325k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 13017 -u -b 1717.548k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 13018 -u -b 2074.432k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 13019 -u -b 647.256k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 13022 -u -b 969.276k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 13023 -u -b 799.787k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 13024 -u -b 176.618k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 13026 -u -b 357.295k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 13027 -u -b 381.974k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 13030 -u -b 941.058k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 13031 -u -b 145.036k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 13032 -u -b 1038.068k -w 256k -t 30 &
sleep 0.4