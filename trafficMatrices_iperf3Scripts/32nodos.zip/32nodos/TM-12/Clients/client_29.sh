 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 29001 -u -b 4860.549k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 29002 -u -b 3944.393k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 29003 -u -b 3854.862k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 29004 -u -b 2663.954k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 29005 -u -b 1537.586k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 29006 -u -b 3506.720k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 29008 -u -b 962.526k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 29010 -u -b 4398.758k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 29011 -u -b 2913.992k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 29013 -u -b 749.208k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 29016 -u -b 711.601k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 29017 -u -b 4283.563k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 29018 -u -b 5173.629k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 29020 -u -b 48.289k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 29022 -u -b 2417.373k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 29024 -u -b 440.485k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 29025 -u -b 472.280k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 29026 -u -b 891.092k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 29027 -u -b 952.641k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 29030 -u -b 2346.997k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 29031 -u -b 361.719k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 29032 -u -b 2588.941k -w 256k -t 30 &
sleep 0.4