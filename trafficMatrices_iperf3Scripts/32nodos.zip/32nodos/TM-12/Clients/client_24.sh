 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 24001 -u -b 1145.824k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 24003 -u -b 908.743k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 24004 -u -b 627.999k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 24007 -u -b 117.713k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 24008 -u -b 226.905k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 24009 -u -b 219.738k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 24010 -u -b 1036.961k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 24011 -u -b 686.943k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 24012 -u -b 138.706k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 24013 -u -b 176.618k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 24015 -u -b 2.074k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 24016 -u -b 167.752k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 24017 -u -b 1009.805k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 24018 -u -b 1219.629k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 24019 -u -b 380.544k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 24022 -u -b 569.870k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 24023 -u -b 470.222k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 24026 -u -b 210.066k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 24027 -u -b 224.575k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 24028 -u -b 580.879k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 24030 -u -b 553.280k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 24032 -u -b 610.316k -w 256k -t 30 &
sleep 0.4