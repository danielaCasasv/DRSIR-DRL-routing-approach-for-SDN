 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 22001 -u -b 4936.655k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 22002 -u -b 4006.155k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 22003 -u -b 3915.221k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 22004 -u -b 2705.666k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 22006 -u -b 3561.629k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 22007 -u -b 507.154k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 22008 -u -b 977.597k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 22010 -u -b 4467.634k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 22013 -u -b 760.939k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 22014 -u -b 5217.886k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 22015 -u -b 8.936k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 22016 -u -b 722.743k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 22017 -u -b 4350.635k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 22018 -u -b 5254.638k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 22019 -u -b 1639.531k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 22021 -u -b 3470.508k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 22023 -u -b 2025.900k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 22024 -u -b 447.382k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 22025 -u -b 479.675k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 22026 -u -b 905.045k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 22030 -u -b 2383.746k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 22031 -u -b 367.382k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 22032 -u -b 2629.478k -w 256k -t 30 &
sleep 0.4