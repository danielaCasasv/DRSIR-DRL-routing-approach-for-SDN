 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 8001 -u -b 1965.630k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 8002 -u -b 1595.132k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 8005 -u -b 621.807k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 8006 -u -b 1418.135k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 8007 -u -b 201.934k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 8009 -u -b 376.954k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 8010 -u -b 1778.879k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 8012 -u -b 237.947k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 8013 -u -b 302.983k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 8015 -u -b 3.558k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 8016 -u -b 287.775k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 8017 -u -b 1732.294k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 8019 -u -b 652.813k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 8020 -u -b 19.528k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 8021 -u -b 1381.853k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 8022 -u -b 977.597k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 8023 -u -b 806.653k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 8026 -u -b 360.362k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 8027 -u -b 385.253k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 8028 -u -b 996.482k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 8029 -u -b 755.640k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 8030 -u -b 949.137k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 8031 -u -b 146.281k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 8032 -u -b 1046.980k -w 256k -t 30 &
sleep 0.4