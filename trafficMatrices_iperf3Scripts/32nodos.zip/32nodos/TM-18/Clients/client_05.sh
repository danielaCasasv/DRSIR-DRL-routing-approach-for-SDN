 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 5002 -u -b 2548.142k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 5003 -u -b 2490.303k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 5004 -u -b 1720.957k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 5006 -u -b 2265.398k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 5007 -u -b 322.579k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 5008 -u -b 621.807k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 5009 -u -b 602.165k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 5010 -u -b 2841.669k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 5012 -u -b 380.107k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 5013 -u -b 484.001k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 5014 -u -b 3318.872k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 5015 -u -b 5.683k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 5017 -u -b 2767.251k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 5018 -u -b 3342.248k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 5019 -u -b 1042.835k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 5020 -u -b 31.196k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 5024 -u -b 284.560k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 5025 -u -b 305.100k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 5026 -u -b 575.660k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 5027 -u -b 615.422k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 5028 -u -b 1591.829k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 5029 -u -b 1207.096k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 5030 -u -b 1516.198k -w 256k -t 30 &
sleep 0.4