 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 11002 -u -b 4829.170k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 11003 -u -b 4719.555k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 11005 -u -b 1882.486k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 11006 -u -b 4293.321k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 11007 -u -b 611.343k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 11009 -u -b 1141.208k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 11012 -u -b 720.369k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 11013 -u -b 917.265k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 11014 -u -b 6289.837k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 11015 -u -b 10.771k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 11016 -u -b 871.221k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 11017 -u -b 5244.419k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 11018 -u -b 6334.138k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 11019 -u -b 1976.352k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 11020 -u -b 59.121k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 11021 -u -b 4183.481k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 11022 -u -b 2959.620k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 11024 -u -b 539.291k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 11025 -u -b 578.218k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 11026 -u -b 1090.976k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 11028 -u -b 3016.791k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 11029 -u -b 2287.657k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 11030 -u -b 2873.458k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 11031 -u -b 442.857k -w 256k -t 30 &
sleep 0.4