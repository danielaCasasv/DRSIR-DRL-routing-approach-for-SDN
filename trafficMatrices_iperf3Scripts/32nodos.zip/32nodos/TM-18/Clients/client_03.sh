 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 3001 -u -b 7872.234k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 3002 -u -b 6388.411k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 3008 -u -b 1558.925k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 3009 -u -b 1509.681k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 3010 -u -b 7124.309k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 3011 -u -b 4719.555k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 3012 -u -b 952.962k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 3014 -u -b 8320.698k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 3015 -u -b 14.249k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 3016 -u -b 1152.521k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 3017 -u -b 6937.736k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 3018 -u -b 8379.304k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 3019 -u -b 2614.477k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 3021 -u -b 5534.242k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 3022 -u -b 3915.221k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 3023 -u -b 3230.599k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 3024 -u -b 713.418k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 3026 -u -b 1443.230k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 3027 -u -b 1542.915k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 3028 -u -b 3990.853k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 3030 -u -b 3801.239k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 3031 -u -b 585.846k -w 256k -t 30 &
sleep 0.4