 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 30001 -u -b 4792.937k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 30004 -u -b 2626.897k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 30007 -u -b 492.390k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 30008 -u -b 949.137k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 30009 -u -b 919.155k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 30011 -u -b 2873.458k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 30012 -u -b 580.202k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 30013 -u -b 738.786k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 30016 -u -b 701.702k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 30017 -u -b 4223.977k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 30019 -u -b 1591.800k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 30020 -u -b 47.617k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 30021 -u -b 3369.472k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 30023 -u -b 1966.920k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 30024 -u -b 434.358k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 30027 -u -b 939.390k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 30028 -u -b 2429.794k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 30032 -u -b 2552.928k -w 256k -t 30 &
sleep 0.4