 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 2001 -u -b 8055.071k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 2003 -u -b 6388.411k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 2004 -u -b 4414.797k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 2005 -u -b 2548.142k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 2006 -u -b 5811.460k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 2007 -u -b 827.517k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 2011 -u -b 4829.170k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 2012 -u -b 975.095k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 2013 -u -b 1241.614k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 2014 -u -b 8513.952k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 2015 -u -b 14.580k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 2017 -u -b 7098.870k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 2018 -u -b 8573.918k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 2019 -u -b 2675.200k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 2020 -u -b 80.027k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 2021 -u -b 5662.779k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 2022 -u -b 4006.155k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 2023 -u -b 3305.632k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 2024 -u -b 729.987k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 2025 -u -b 782.679k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 2027 -u -b 1578.751k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 2029 -u -b 3096.583k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 2030 -u -b 3889.525k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 2031 -u -b 599.453k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 2032 -u -b 4290.483k -w 256k -t 30 &
sleep 0.4