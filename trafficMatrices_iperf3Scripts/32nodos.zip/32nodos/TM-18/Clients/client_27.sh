 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 27001 -u -b 1945.444k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 27002 -u -b 1578.751k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 27003 -u -b 1542.915k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 27004 -u -b 1066.252k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 27006 -u -b 1403.571k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 27007 -u -b 199.860k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 27010 -u -b 1760.611k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 27011 -u -b 1166.331k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 27012 -u -b 235.503k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 27015 -u -b 3.521k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 27016 -u -b 284.819k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 27018 -u -b 2070.754k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 27019 -u -b 646.109k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 27020 -u -b 19.328k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 27021 -u -b 1367.662k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 27022 -u -b 967.558k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 27023 -u -b 798.369k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 27029 -u -b 747.880k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 27030 -u -b 939.390k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 27031 -u -b 144.779k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 27032 -u -b 1036.228k -w 256k -t 30 &
sleep 0.4