 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 25001 -u -b 964.470k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 25002 -u -b 782.679k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 25003 -u -b 764.913k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 25005 -u -b 305.100k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 25007 -u -b 99.082k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 25008 -u -b 190.992k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 25009 -u -b 184.959k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 25010 -u -b 872.837k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 25011 -u -b 578.218k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 25012 -u -b 116.753k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 25013 -u -b 148.664k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 25015 -u -b 1.746k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 25016 -u -b 141.202k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 25018 -u -b 1026.594k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 25019 -u -b 320.314k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 25020 -u -b 9.582k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 25021 -u -b 678.030k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 25022 -u -b 479.675k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 25023 -u -b 395.798k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 25024 -u -b 87.405k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 25026 -u -b 176.818k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 25027 -u -b 189.031k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 25028 -u -b 488.941k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 25029 -u -b 370.768k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 25030 -u -b 465.710k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 25031 -u -b 71.775k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 25032 -u -b 513.719k -w 256k -t 30 &
sleep 0.4