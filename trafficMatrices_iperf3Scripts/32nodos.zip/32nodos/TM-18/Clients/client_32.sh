 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 32001 -u -b 5287.024k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 32002 -u -b 4290.483k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 32003 -u -b 4193.095k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 32004 -u -b 2897.695k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 32005 -u -b 1672.497k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 32006 -u -b 3814.408k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 32007 -u -b 543.149k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 32008 -u -b 1046.980k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 32009 -u -b 1013.908k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 32010 -u -b 4784.715k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 32012 -u -b 640.013k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 32013 -u -b 814.945k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 32014 -u -b 5588.214k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 32015 -u -b 9.570k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 32016 -u -b 774.038k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 32018 -u -b 5627.574k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 32020 -u -b 52.526k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 32022 -u -b 2629.478k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 32023 -u -b 2169.683k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 32026 -u -b 969.279k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 32029 -u -b 2032.472k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 32031 -u -b 393.457k -w 256k -t 30 &
sleep 0.4