 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 19001 -u -b 3296.562k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 19003 -u -b 2614.477k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 19004 -u -b 1806.769k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 19007 -u -b 338.664k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 19008 -u -b 652.813k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 19009 -u -b 632.191k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 19011 -u -b 1976.352k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 19014 -u -b 3484.361k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 19015 -u -b 5.967k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 19016 -u -b 482.628k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 19017 -u -b 2905.234k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 19020 -u -b 32.751k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 19021 -u -b 2317.509k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 19023 -u -b 1352.840k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 19024 -u -b 298.749k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 19025 -u -b 320.314k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 19026 -u -b 604.364k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 19027 -u -b 646.109k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 19028 -u -b 1671.202k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 19029 -u -b 1267.286k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 19030 -u -b 1591.800k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 19031 -u -b 245.328k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 19032 -u -b 1755.893k -w 256k -t 30 &
sleep 0.4