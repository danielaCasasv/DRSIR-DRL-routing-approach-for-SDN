 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 9001 -u -b 1903.538k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 9004 -u -b 1043.285k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 9005 -u -b 602.165k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 9007 -u -b 195.555k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 9008 -u -b 376.954k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 9012 -u -b 230.430k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 9014 -u -b 2011.979k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 9016 -u -b 278.684k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 9018 -u -b 2026.150k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 9019 -u -b 632.191k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 9020 -u -b 18.912k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 9022 -u -b 946.716k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 9025 -u -b 184.959k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 9026 -u -b 348.979k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 9027 -u -b 373.083k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 9028 -u -b 965.004k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 9029 -u -b 731.770k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 9030 -u -b 919.155k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 9031 -u -b 141.660k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 9032 -u -b 1013.908k -w 256k -t 30 &
sleep 0.4