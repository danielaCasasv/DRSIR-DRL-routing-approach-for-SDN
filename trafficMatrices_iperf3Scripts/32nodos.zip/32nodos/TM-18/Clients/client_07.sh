 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 7001 -u -b 1019.722k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 7002 -u -b 827.517k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 7004 -u -b 558.886k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 7006 -u -b 735.695k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 7009 -u -b 195.555k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 7011 -u -b 611.343k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 7012 -u -b 123.441k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 7013 -u -b 157.181k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 7015 -u -b 1.846k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 7016 -u -b 149.291k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 7018 -u -b 1085.405k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 7019 -u -b 338.664k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 7020 -u -b 10.131k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 7021 -u -b 716.873k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 7025 -u -b 99.082k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 7027 -u -b 199.860k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 7028 -u -b 516.951k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 7029 -u -b 392.008k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 7030 -u -b 492.390k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 7032 -u -b 543.149k -w 256k -t 30 &
sleep 0.4