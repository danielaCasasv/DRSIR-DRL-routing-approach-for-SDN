 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 29001 -u -b 3815.819k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 29002 -u -b 3096.583k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 29003 -u -b 3026.295k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 29004 -u -b 2091.362k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 29005 -u -b 1207.096k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 29006 -u -b 2752.984k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 29008 -u -b 755.640k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 29010 -u -b 3453.286k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 29011 -u -b 2287.657k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 29013 -u -b 588.173k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 29016 -u -b 558.649k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 29017 -u -b 3362.851k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 29018 -u -b 4061.606k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 29020 -u -b 37.910k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 29022 -u -b 1897.781k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 29024 -u -b 345.807k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 29025 -u -b 370.768k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 29026 -u -b 699.560k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 29027 -u -b 747.880k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 29030 -u -b 1842.532k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 29031 -u -b 283.971k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 29032 -u -b 2032.472k -w 256k -t 30 &
sleep 0.4