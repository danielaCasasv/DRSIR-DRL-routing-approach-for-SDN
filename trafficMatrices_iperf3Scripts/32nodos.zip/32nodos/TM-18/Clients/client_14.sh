 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 14001 -u -b 10491.469k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 14002 -u -b 8513.952k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 14004 -u -b 5750.130k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 14005 -u -b 3318.872k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 14006 -u -b 7569.237k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 14007 -u -b 1077.814k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 14011 -u -b 6289.837k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 14013 -u -b 1617.162k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 14015 -u -b 18.990k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 14016 -u -b 1535.986k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 14017 -u -b 9246.047k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 14018 -u -b 11167.250k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 14019 -u -b 3484.361k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 14020 -u -b 104.232k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 14021 -u -b 7375.585k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 14022 -u -b 5217.886k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 14023 -u -b 4305.478k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 14024 -u -b 950.785k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 14025 -u -b 1019.413k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 14028 -u -b 5318.682k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 14029 -u -b 4033.198k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 14030 -u -b 5065.981k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 14031 -u -b 780.768k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 14032 -u -b 5588.214k -w 256k -t 30 &
sleep 0.4