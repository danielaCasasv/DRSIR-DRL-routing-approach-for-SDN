 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 16001 -u -b 1453.200k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 16002 -u -b 1179.289k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 16006 -u -b 1048.435k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 16007 -u -b 149.291k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 16008 -u -b 287.775k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 16010 -u -b 1315.135k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 16011 -u -b 871.221k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 16014 -u -b 1535.986k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 16015 -u -b 2.630k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 16017 -u -b 1280.694k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 16020 -u -b 14.437k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 16022 -u -b 722.743k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 16025 -u -b 141.202k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 16027 -u -b 284.819k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 16028 -u -b 736.704k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 16029 -u -b 558.649k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 16030 -u -b 701.702k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 16031 -u -b 108.146k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 16032 -u -b 774.038k -w 256k -t 30 &
sleep 0.4