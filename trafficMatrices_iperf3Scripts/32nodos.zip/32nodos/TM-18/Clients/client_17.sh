 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.3 -p 17003 -u -b 6937.736k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 17004 -u -b 4794.415k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 17005 -u -b 2767.251k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 17006 -u -b 6311.174k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 17008 -u -b 1732.294k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 17009 -u -b 1677.573k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 17010 -u -b 7916.607k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 17011 -u -b 5244.419k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 17012 -u -b 1058.942k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 17013 -u -b 1348.377k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 17014 -u -b 9246.047k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 17015 -u -b 15.834k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 17018 -u -b 9311.170k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 17019 -u -b 2905.234k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 17021 -u -b 6149.708k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 17022 -u -b 4350.635k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 17024 -u -b 792.757k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 17025 -u -b 849.979k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 17026 -u -b 1603.732k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 17029 -u -b 3362.851k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 17031 -u -b 650.998k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 17032 -u -b 4659.412k -w 256k -t 30 &
sleep 0.4