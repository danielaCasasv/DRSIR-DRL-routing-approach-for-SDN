 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 18001 -u -b 10565.364k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 18002 -u -b 8573.918k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 18003 -u -b 8379.304k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 18007 -u -b 1085.405k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 18008 -u -b 2092.241k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 18010 -u -b 9561.570k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 18011 -u -b 6334.138k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 18012 -u -b 1278.975k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 18013 -u -b 1628.552k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 18014 -u -b 11167.250k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 18015 -u -b 19.124k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 18017 -u -b 9311.170k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 18019 -u -b 3508.902k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 18020 -u -b 104.966k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 18021 -u -b 7427.534k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 18024 -u -b 957.481k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 18026 -u -b 1936.966k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 18029 -u -b 4061.606k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 18030 -u -b 5101.662k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 18032 -u -b 5627.574k -w 256k -t 30 &
sleep 0.4