 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 4001 -u -b 5440.212k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 4002 -u -b 4414.797k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 4003 -u -b 4314.588k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 4005 -u -b 1720.957k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 4006 -u -b 3924.928k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 4007 -u -b 558.886k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 4008 -u -b 1077.316k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 4009 -u -b 1043.285k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 4011 -u -b 3261.511k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 4015 -u -b 9.847k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 4016 -u -b 796.465k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 4017 -u -b 4794.415k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 4018 -u -b 5790.630k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 4019 -u -b 1806.769k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 4020 -u -b 54.048k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 4021 -u -b 3824.512k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 4022 -u -b 2705.666k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 4026 -u -b 997.363k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 4027 -u -b 1066.252k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 4028 -u -b 2757.932k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 4029 -u -b 2091.362k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 4030 -u -b 2626.897k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 4032 -u -b 2897.695k -w 256k -t 30 &
sleep 0.4