 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 10001 -u -b 8982.956k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 10002 -u -b 7289.776k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 10003 -u -b 7124.309k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 10006 -u -b 6480.897k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 10007 -u -b 922.840k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 10008 -u -b 1778.879k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 10009 -u -b 1722.687k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 10011 -u -b 5385.454k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 10012 -u -b 1087.419k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 10013 -u -b 1384.639k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 10014 -u -b 9494.696k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 10016 -u -b 1315.135k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 10018 -u -b 9561.570k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 10019 -u -b 2983.363k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 10021 -u -b 6315.089k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 10022 -u -b 4467.634k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 10025 -u -b 872.837k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 10027 -u -b 1760.611k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 10028 -u -b 4553.937k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 10029 -u -b 3453.286k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 10030 -u -b 4337.570k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 10031 -u -b 668.505k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 10032 -u -b 4784.715k -w 256k -t 30 &
sleep 0.4