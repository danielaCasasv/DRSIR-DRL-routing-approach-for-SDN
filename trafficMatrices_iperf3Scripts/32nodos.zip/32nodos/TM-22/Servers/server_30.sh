 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1030 -1 &
sleep 0.3
iperf3 -s -p 2030 -1 &
sleep 0.3
iperf3 -s -p 3030 -1 &
sleep 0.3
iperf3 -s -p 4030 -1 &
sleep 0.3
iperf3 -s -p 5030 -1 &
sleep 0.3
iperf3 -s -p 6030 -1 &
sleep 0.3
iperf3 -s -p 7030 -1 &
sleep 0.3
iperf3 -s -p 8030 -1 &
sleep 0.3
iperf3 -s -p 9030 -1 &
sleep 0.3
iperf3 -s -p 10030 -1 &
sleep 0.3
iperf3 -s -p 11030 -1 &
sleep 0.3
iperf3 -s -p 12030 -1 &
sleep 0.3
iperf3 -s -p 13030 -1 &
sleep 0.3
iperf3 -s -p 14030 -1 &
sleep 0.3
iperf3 -s -p 15030 -1 &
sleep 0.3
iperf3 -s -p 16030 -1 &
sleep 0.3
iperf3 -s -p 18030 -1 &
sleep 0.3
iperf3 -s -p 19030 -1 &
sleep 0.3
iperf3 -s -p 21030 -1 &
sleep 0.3
iperf3 -s -p 22030 -1 &
sleep 0.3
iperf3 -s -p 24030 -1 &
sleep 0.3
iperf3 -s -p 25030 -1 &
sleep 0.3
iperf3 -s -p 26030 -1 &
sleep 0.3
iperf3 -s -p 27030 -1 &
sleep 0.3
iperf3 -s -p 28030 -1 &
sleep 0.3
iperf3 -s -p 29030 -1 &
sleep 0.3