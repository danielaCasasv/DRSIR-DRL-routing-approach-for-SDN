 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1009 -1 &
sleep 0.3
iperf3 -s -p 3009 -1 &
sleep 0.3
iperf3 -s -p 4009 -1 &
sleep 0.3
iperf3 -s -p 5009 -1 &
sleep 0.3
iperf3 -s -p 6009 -1 &
sleep 0.3
iperf3 -s -p 7009 -1 &
sleep 0.3
iperf3 -s -p 8009 -1 &
sleep 0.3
iperf3 -s -p 10009 -1 &
sleep 0.3
iperf3 -s -p 11009 -1 &
sleep 0.3
iperf3 -s -p 12009 -1 &
sleep 0.3
iperf3 -s -p 15009 -1 &
sleep 0.3
iperf3 -s -p 17009 -1 &
sleep 0.3
iperf3 -s -p 19009 -1 &
sleep 0.3
iperf3 -s -p 20009 -1 &
sleep 0.3
iperf3 -s -p 21009 -1 &
sleep 0.3
iperf3 -s -p 23009 -1 &
sleep 0.3
iperf3 -s -p 24009 -1 &
sleep 0.3
iperf3 -s -p 25009 -1 &
sleep 0.3
iperf3 -s -p 26009 -1 &
sleep 0.3
iperf3 -s -p 30009 -1 &
sleep 0.3
iperf3 -s -p 31009 -1 &
sleep 0.3
iperf3 -s -p 32009 -1 &
sleep 0.3