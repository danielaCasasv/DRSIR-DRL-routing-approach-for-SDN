 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 2020 -1 &
sleep 0.3
iperf3 -s -p 4020 -1 &
sleep 0.3
iperf3 -s -p 5020 -1 &
sleep 0.3
iperf3 -s -p 6020 -1 &
sleep 0.3
iperf3 -s -p 7020 -1 &
sleep 0.3
iperf3 -s -p 8020 -1 &
sleep 0.3
iperf3 -s -p 9020 -1 &
sleep 0.3
iperf3 -s -p 11020 -1 &
sleep 0.3
iperf3 -s -p 12020 -1 &
sleep 0.3
iperf3 -s -p 14020 -1 &
sleep 0.3
iperf3 -s -p 15020 -1 &
sleep 0.3
iperf3 -s -p 16020 -1 &
sleep 0.3
iperf3 -s -p 18020 -1 &
sleep 0.3
iperf3 -s -p 19020 -1 &
sleep 0.3
iperf3 -s -p 21020 -1 &
sleep 0.3
iperf3 -s -p 25020 -1 &
sleep 0.3
iperf3 -s -p 27020 -1 &
sleep 0.3
iperf3 -s -p 28020 -1 &
sleep 0.3
iperf3 -s -p 29020 -1 &
sleep 0.3
iperf3 -s -p 30020 -1 &
sleep 0.3
iperf3 -s -p 31020 -1 &
sleep 0.3
iperf3 -s -p 32020 -1 &
sleep 0.3