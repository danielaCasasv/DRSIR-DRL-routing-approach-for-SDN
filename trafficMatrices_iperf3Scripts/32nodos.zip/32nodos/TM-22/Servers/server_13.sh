 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 2013 -1 &
sleep 0.3
iperf3 -s -p 5013 -1 &
sleep 0.3
iperf3 -s -p 6013 -1 &
sleep 0.3
iperf3 -s -p 7013 -1 &
sleep 0.3
iperf3 -s -p 8013 -1 &
sleep 0.3
iperf3 -s -p 10013 -1 &
sleep 0.3
iperf3 -s -p 11013 -1 &
sleep 0.3
iperf3 -s -p 12013 -1 &
sleep 0.3
iperf3 -s -p 14013 -1 &
sleep 0.3
iperf3 -s -p 15013 -1 &
sleep 0.3
iperf3 -s -p 17013 -1 &
sleep 0.3
iperf3 -s -p 18013 -1 &
sleep 0.3
iperf3 -s -p 21013 -1 &
sleep 0.3
iperf3 -s -p 22013 -1 &
sleep 0.3
iperf3 -s -p 23013 -1 &
sleep 0.3
iperf3 -s -p 24013 -1 &
sleep 0.3
iperf3 -s -p 25013 -1 &
sleep 0.3
iperf3 -s -p 26013 -1 &
sleep 0.3
iperf3 -s -p 28013 -1 &
sleep 0.3
iperf3 -s -p 29013 -1 &
sleep 0.3
iperf3 -s -p 30013 -1 &
sleep 0.3
iperf3 -s -p 31013 -1 &
sleep 0.3
iperf3 -s -p 32013 -1 &
sleep 0.3