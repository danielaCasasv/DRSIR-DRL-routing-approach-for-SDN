 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1010 -1 &
sleep 0.3
iperf3 -s -p 3010 -1 &
sleep 0.3
iperf3 -s -p 5010 -1 &
sleep 0.3
iperf3 -s -p 6010 -1 &
sleep 0.3
iperf3 -s -p 8010 -1 &
sleep 0.3
iperf3 -s -p 13010 -1 &
sleep 0.3
iperf3 -s -p 15010 -1 &
sleep 0.3
iperf3 -s -p 16010 -1 &
sleep 0.3
iperf3 -s -p 17010 -1 &
sleep 0.3
iperf3 -s -p 18010 -1 &
sleep 0.3
iperf3 -s -p 22010 -1 &
sleep 0.3
iperf3 -s -p 23010 -1 &
sleep 0.3
iperf3 -s -p 24010 -1 &
sleep 0.3
iperf3 -s -p 25010 -1 &
sleep 0.3
iperf3 -s -p 26010 -1 &
sleep 0.3
iperf3 -s -p 27010 -1 &
sleep 0.3
iperf3 -s -p 29010 -1 &
sleep 0.3
iperf3 -s -p 31010 -1 &
sleep 0.3
iperf3 -s -p 32010 -1 &
sleep 0.3