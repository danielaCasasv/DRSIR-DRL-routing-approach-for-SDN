 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 2004 -1 &
sleep 0.3
iperf3 -s -p 5004 -1 &
sleep 0.3
iperf3 -s -p 7004 -1 &
sleep 0.3
iperf3 -s -p 9004 -1 &
sleep 0.3
iperf3 -s -p 13004 -1 &
sleep 0.3
iperf3 -s -p 14004 -1 &
sleep 0.3
iperf3 -s -p 15004 -1 &
sleep 0.3
iperf3 -s -p 17004 -1 &
sleep 0.3
iperf3 -s -p 19004 -1 &
sleep 0.3
iperf3 -s -p 20004 -1 &
sleep 0.3
iperf3 -s -p 21004 -1 &
sleep 0.3
iperf3 -s -p 22004 -1 &
sleep 0.3
iperf3 -s -p 23004 -1 &
sleep 0.3
iperf3 -s -p 24004 -1 &
sleep 0.3
iperf3 -s -p 27004 -1 &
sleep 0.3
iperf3 -s -p 28004 -1 &
sleep 0.3
iperf3 -s -p 29004 -1 &
sleep 0.3
iperf3 -s -p 30004 -1 &
sleep 0.3
iperf3 -s -p 31004 -1 &
sleep 0.3
iperf3 -s -p 32004 -1 &
sleep 0.3