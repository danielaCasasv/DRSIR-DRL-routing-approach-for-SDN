 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1022 -1 &
sleep 0.3
iperf3 -s -p 2022 -1 &
sleep 0.3
iperf3 -s -p 3022 -1 &
sleep 0.3
iperf3 -s -p 4022 -1 &
sleep 0.3
iperf3 -s -p 6022 -1 &
sleep 0.3
iperf3 -s -p 8022 -1 &
sleep 0.3
iperf3 -s -p 9022 -1 &
sleep 0.3
iperf3 -s -p 10022 -1 &
sleep 0.3
iperf3 -s -p 11022 -1 &
sleep 0.3
iperf3 -s -p 12022 -1 &
sleep 0.3
iperf3 -s -p 13022 -1 &
sleep 0.3
iperf3 -s -p 14022 -1 &
sleep 0.3
iperf3 -s -p 15022 -1 &
sleep 0.3
iperf3 -s -p 16022 -1 &
sleep 0.3
iperf3 -s -p 17022 -1 &
sleep 0.3
iperf3 -s -p 23022 -1 &
sleep 0.3
iperf3 -s -p 24022 -1 &
sleep 0.3
iperf3 -s -p 25022 -1 &
sleep 0.3
iperf3 -s -p 26022 -1 &
sleep 0.3
iperf3 -s -p 27022 -1 &
sleep 0.3
iperf3 -s -p 29022 -1 &
sleep 0.3
iperf3 -s -p 31022 -1 &
sleep 0.3
iperf3 -s -p 32022 -1 &
sleep 0.3