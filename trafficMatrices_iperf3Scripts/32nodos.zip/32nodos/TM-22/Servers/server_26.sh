 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1026 -1 &
sleep 0.3
iperf3 -s -p 3026 -1 &
sleep 0.3
iperf3 -s -p 4026 -1 &
sleep 0.3
iperf3 -s -p 5026 -1 &
sleep 0.3
iperf3 -s -p 6026 -1 &
sleep 0.3
iperf3 -s -p 8026 -1 &
sleep 0.3
iperf3 -s -p 9026 -1 &
sleep 0.3
iperf3 -s -p 11026 -1 &
sleep 0.3
iperf3 -s -p 13026 -1 &
sleep 0.3
iperf3 -s -p 15026 -1 &
sleep 0.3
iperf3 -s -p 17026 -1 &
sleep 0.3
iperf3 -s -p 18026 -1 &
sleep 0.3
iperf3 -s -p 19026 -1 &
sleep 0.3
iperf3 -s -p 20026 -1 &
sleep 0.3
iperf3 -s -p 21026 -1 &
sleep 0.3
iperf3 -s -p 22026 -1 &
sleep 0.3
iperf3 -s -p 23026 -1 &
sleep 0.3
iperf3 -s -p 24026 -1 &
sleep 0.3
iperf3 -s -p 25026 -1 &
sleep 0.3
iperf3 -s -p 28026 -1 &
sleep 0.3
iperf3 -s -p 29026 -1 &
sleep 0.3
iperf3 -s -p 31026 -1 &
sleep 0.3
iperf3 -s -p 32026 -1 &
sleep 0.3