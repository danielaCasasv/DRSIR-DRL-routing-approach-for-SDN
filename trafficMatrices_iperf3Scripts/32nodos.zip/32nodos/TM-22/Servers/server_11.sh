 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1011 -1 &
sleep 0.3
iperf3 -s -p 2011 -1 &
sleep 0.3
iperf3 -s -p 3011 -1 &
sleep 0.3
iperf3 -s -p 4011 -1 &
sleep 0.3
iperf3 -s -p 7011 -1 &
sleep 0.3
iperf3 -s -p 10011 -1 &
sleep 0.3
iperf3 -s -p 12011 -1 &
sleep 0.3
iperf3 -s -p 13011 -1 &
sleep 0.3
iperf3 -s -p 14011 -1 &
sleep 0.3
iperf3 -s -p 15011 -1 &
sleep 0.3
iperf3 -s -p 16011 -1 &
sleep 0.3
iperf3 -s -p 17011 -1 &
sleep 0.3
iperf3 -s -p 18011 -1 &
sleep 0.3
iperf3 -s -p 19011 -1 &
sleep 0.3
iperf3 -s -p 20011 -1 &
sleep 0.3
iperf3 -s -p 21011 -1 &
sleep 0.3
iperf3 -s -p 23011 -1 &
sleep 0.3
iperf3 -s -p 24011 -1 &
sleep 0.3
iperf3 -s -p 25011 -1 &
sleep 0.3
iperf3 -s -p 26011 -1 &
sleep 0.3
iperf3 -s -p 27011 -1 &
sleep 0.3
iperf3 -s -p 28011 -1 &
sleep 0.3
iperf3 -s -p 29011 -1 &
sleep 0.3
iperf3 -s -p 30011 -1 &
sleep 0.3
iperf3 -s -p 31011 -1 &
sleep 0.3