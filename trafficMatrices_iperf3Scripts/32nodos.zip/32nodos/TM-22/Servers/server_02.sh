 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1002 -1 &
sleep 0.3
iperf3 -s -p 3002 -1 &
sleep 0.3
iperf3 -s -p 4002 -1 &
sleep 0.3
iperf3 -s -p 5002 -1 &
sleep 0.3
iperf3 -s -p 6002 -1 &
sleep 0.3
iperf3 -s -p 7002 -1 &
sleep 0.3
iperf3 -s -p 8002 -1 &
sleep 0.3
iperf3 -s -p 10002 -1 &
sleep 0.3
iperf3 -s -p 11002 -1 &
sleep 0.3
iperf3 -s -p 13002 -1 &
sleep 0.3
iperf3 -s -p 14002 -1 &
sleep 0.3
iperf3 -s -p 15002 -1 &
sleep 0.3
iperf3 -s -p 16002 -1 &
sleep 0.3
iperf3 -s -p 18002 -1 &
sleep 0.3
iperf3 -s -p 20002 -1 &
sleep 0.3
iperf3 -s -p 21002 -1 &
sleep 0.3
iperf3 -s -p 22002 -1 &
sleep 0.3
iperf3 -s -p 23002 -1 &
sleep 0.3
iperf3 -s -p 25002 -1 &
sleep 0.3
iperf3 -s -p 26002 -1 &
sleep 0.3
iperf3 -s -p 27002 -1 &
sleep 0.3
iperf3 -s -p 29002 -1 &
sleep 0.3
iperf3 -s -p 31002 -1 &
sleep 0.3
iperf3 -s -p 32002 -1 &
sleep 0.3