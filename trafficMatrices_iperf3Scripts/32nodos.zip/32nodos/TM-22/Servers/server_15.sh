 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1015 -1 &
sleep 0.3
iperf3 -s -p 2015 -1 &
sleep 0.3
iperf3 -s -p 3015 -1 &
sleep 0.3
iperf3 -s -p 4015 -1 &
sleep 0.3
iperf3 -s -p 5015 -1 &
sleep 0.3
iperf3 -s -p 7015 -1 &
sleep 0.3
iperf3 -s -p 8015 -1 &
sleep 0.3
iperf3 -s -p 11015 -1 &
sleep 0.3
iperf3 -s -p 12015 -1 &
sleep 0.3
iperf3 -s -p 13015 -1 &
sleep 0.3
iperf3 -s -p 14015 -1 &
sleep 0.3
iperf3 -s -p 16015 -1 &
sleep 0.3
iperf3 -s -p 17015 -1 &
sleep 0.3
iperf3 -s -p 18015 -1 &
sleep 0.3
iperf3 -s -p 19015 -1 &
sleep 0.3
iperf3 -s -p 21015 -1 &
sleep 0.3
iperf3 -s -p 22015 -1 &
sleep 0.3
iperf3 -s -p 23015 -1 &
sleep 0.3
iperf3 -s -p 24015 -1 &
sleep 0.3
iperf3 -s -p 25015 -1 &
sleep 0.3
iperf3 -s -p 26015 -1 &
sleep 0.3
iperf3 -s -p 27015 -1 &
sleep 0.3
iperf3 -s -p 28015 -1 &
sleep 0.3
iperf3 -s -p 32015 -1 &
sleep 0.3