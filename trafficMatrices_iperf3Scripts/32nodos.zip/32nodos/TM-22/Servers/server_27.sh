 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 2027 -1 &
sleep 0.3
iperf3 -s -p 3027 -1 &
sleep 0.3
iperf3 -s -p 4027 -1 &
sleep 0.3
iperf3 -s -p 5027 -1 &
sleep 0.3
iperf3 -s -p 6027 -1 &
sleep 0.3
iperf3 -s -p 7027 -1 &
sleep 0.3
iperf3 -s -p 8027 -1 &
sleep 0.3
iperf3 -s -p 9027 -1 &
sleep 0.3
iperf3 -s -p 10027 -1 &
sleep 0.3
iperf3 -s -p 13027 -1 &
sleep 0.3
iperf3 -s -p 16027 -1 &
sleep 0.3
iperf3 -s -p 19027 -1 &
sleep 0.3
iperf3 -s -p 20027 -1 &
sleep 0.3
iperf3 -s -p 24027 -1 &
sleep 0.3
iperf3 -s -p 25027 -1 &
sleep 0.3
iperf3 -s -p 28027 -1 &
sleep 0.3
iperf3 -s -p 29027 -1 &
sleep 0.3
iperf3 -s -p 30027 -1 &
sleep 0.3
iperf3 -s -p 31027 -1 &
sleep 0.3