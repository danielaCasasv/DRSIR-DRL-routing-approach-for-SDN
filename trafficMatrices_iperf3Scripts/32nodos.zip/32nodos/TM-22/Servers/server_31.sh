 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1031 -1 &
sleep 0.3
iperf3 -s -p 2031 -1 &
sleep 0.3
iperf3 -s -p 3031 -1 &
sleep 0.3
iperf3 -s -p 6031 -1 &
sleep 0.3
iperf3 -s -p 8031 -1 &
sleep 0.3
iperf3 -s -p 9031 -1 &
sleep 0.3
iperf3 -s -p 10031 -1 &
sleep 0.3
iperf3 -s -p 11031 -1 &
sleep 0.3
iperf3 -s -p 13031 -1 &
sleep 0.3
iperf3 -s -p 14031 -1 &
sleep 0.3
iperf3 -s -p 15031 -1 &
sleep 0.3
iperf3 -s -p 16031 -1 &
sleep 0.3
iperf3 -s -p 17031 -1 &
sleep 0.3
iperf3 -s -p 19031 -1 &
sleep 0.3
iperf3 -s -p 20031 -1 &
sleep 0.3
iperf3 -s -p 22031 -1 &
sleep 0.3
iperf3 -s -p 23031 -1 &
sleep 0.3
iperf3 -s -p 25031 -1 &
sleep 0.3
iperf3 -s -p 27031 -1 &
sleep 0.3
iperf3 -s -p 28031 -1 &
sleep 0.3
iperf3 -s -p 29031 -1 &
sleep 0.3
iperf3 -s -p 32031 -1 &
sleep 0.3