 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1025 -1 &
sleep 0.3
iperf3 -s -p 2025 -1 &
sleep 0.3
iperf3 -s -p 5025 -1 &
sleep 0.3
iperf3 -s -p 6025 -1 &
sleep 0.3
iperf3 -s -p 7025 -1 &
sleep 0.3
iperf3 -s -p 9025 -1 &
sleep 0.3
iperf3 -s -p 10025 -1 &
sleep 0.3
iperf3 -s -p 11025 -1 &
sleep 0.3
iperf3 -s -p 12025 -1 &
sleep 0.3
iperf3 -s -p 14025 -1 &
sleep 0.3
iperf3 -s -p 15025 -1 &
sleep 0.3
iperf3 -s -p 16025 -1 &
sleep 0.3
iperf3 -s -p 17025 -1 &
sleep 0.3
iperf3 -s -p 19025 -1 &
sleep 0.3
iperf3 -s -p 21025 -1 &
sleep 0.3
iperf3 -s -p 22025 -1 &
sleep 0.3
iperf3 -s -p 23025 -1 &
sleep 0.3
iperf3 -s -p 28025 -1 &
sleep 0.3
iperf3 -s -p 29025 -1 &
sleep 0.3
iperf3 -s -p 31025 -1 &
sleep 0.3