 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1018 -1 &
sleep 0.3
iperf3 -s -p 2018 -1 &
sleep 0.3
iperf3 -s -p 3018 -1 &
sleep 0.3
iperf3 -s -p 4018 -1 &
sleep 0.3
iperf3 -s -p 5018 -1 &
sleep 0.3
iperf3 -s -p 6018 -1 &
sleep 0.3
iperf3 -s -p 7018 -1 &
sleep 0.3
iperf3 -s -p 9018 -1 &
sleep 0.3
iperf3 -s -p 10018 -1 &
sleep 0.3
iperf3 -s -p 11018 -1 &
sleep 0.3
iperf3 -s -p 12018 -1 &
sleep 0.3
iperf3 -s -p 13018 -1 &
sleep 0.3
iperf3 -s -p 14018 -1 &
sleep 0.3
iperf3 -s -p 15018 -1 &
sleep 0.3
iperf3 -s -p 17018 -1 &
sleep 0.3
iperf3 -s -p 20018 -1 &
sleep 0.3
iperf3 -s -p 22018 -1 &
sleep 0.3
iperf3 -s -p 23018 -1 &
sleep 0.3
iperf3 -s -p 24018 -1 &
sleep 0.3
iperf3 -s -p 25018 -1 &
sleep 0.3
iperf3 -s -p 26018 -1 &
sleep 0.3
iperf3 -s -p 27018 -1 &
sleep 0.3
iperf3 -s -p 29018 -1 &
sleep 0.3
iperf3 -s -p 31018 -1 &
sleep 0.3
iperf3 -s -p 32018 -1 &
sleep 0.3