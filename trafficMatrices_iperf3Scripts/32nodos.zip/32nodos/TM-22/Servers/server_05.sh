 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1005 -1 &
sleep 0.3
iperf3 -s -p 2005 -1 &
sleep 0.3
iperf3 -s -p 4005 -1 &
sleep 0.3
iperf3 -s -p 6005 -1 &
sleep 0.3
iperf3 -s -p 8005 -1 &
sleep 0.3
iperf3 -s -p 9005 -1 &
sleep 0.3
iperf3 -s -p 11005 -1 &
sleep 0.3
iperf3 -s -p 12005 -1 &
sleep 0.3
iperf3 -s -p 13005 -1 &
sleep 0.3
iperf3 -s -p 14005 -1 &
sleep 0.3
iperf3 -s -p 15005 -1 &
sleep 0.3
iperf3 -s -p 17005 -1 &
sleep 0.3
iperf3 -s -p 21005 -1 &
sleep 0.3
iperf3 -s -p 25005 -1 &
sleep 0.3
iperf3 -s -p 26005 -1 &
sleep 0.3
iperf3 -s -p 28005 -1 &
sleep 0.3
iperf3 -s -p 29005 -1 &
sleep 0.3
iperf3 -s -p 31005 -1 &
sleep 0.3
iperf3 -s -p 32005 -1 &
sleep 0.3