 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1003 -1 &
sleep 0.3
iperf3 -s -p 2003 -1 &
sleep 0.3
iperf3 -s -p 4003 -1 &
sleep 0.3
iperf3 -s -p 5003 -1 &
sleep 0.3
iperf3 -s -p 6003 -1 &
sleep 0.3
iperf3 -s -p 10003 -1 &
sleep 0.3
iperf3 -s -p 11003 -1 &
sleep 0.3
iperf3 -s -p 13003 -1 &
sleep 0.3
iperf3 -s -p 15003 -1 &
sleep 0.3
iperf3 -s -p 17003 -1 &
sleep 0.3
iperf3 -s -p 18003 -1 &
sleep 0.3
iperf3 -s -p 19003 -1 &
sleep 0.3
iperf3 -s -p 21003 -1 &
sleep 0.3
iperf3 -s -p 22003 -1 &
sleep 0.3
iperf3 -s -p 23003 -1 &
sleep 0.3
iperf3 -s -p 24003 -1 &
sleep 0.3
iperf3 -s -p 25003 -1 &
sleep 0.3
iperf3 -s -p 26003 -1 &
sleep 0.3
iperf3 -s -p 27003 -1 &
sleep 0.3
iperf3 -s -p 29003 -1 &
sleep 0.3
iperf3 -s -p 31003 -1 &
sleep 0.3
iperf3 -s -p 32003 -1 &
sleep 0.3