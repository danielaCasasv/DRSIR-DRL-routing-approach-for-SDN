 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1008 -1 &
sleep 0.3
iperf3 -s -p 3008 -1 &
sleep 0.3
iperf3 -s -p 4008 -1 &
sleep 0.3
iperf3 -s -p 5008 -1 &
sleep 0.3
iperf3 -s -p 6008 -1 &
sleep 0.3
iperf3 -s -p 9008 -1 &
sleep 0.3
iperf3 -s -p 10008 -1 &
sleep 0.3
iperf3 -s -p 12008 -1 &
sleep 0.3
iperf3 -s -p 13008 -1 &
sleep 0.3
iperf3 -s -p 16008 -1 &
sleep 0.3
iperf3 -s -p 17008 -1 &
sleep 0.3
iperf3 -s -p 18008 -1 &
sleep 0.3
iperf3 -s -p 19008 -1 &
sleep 0.3
iperf3 -s -p 20008 -1 &
sleep 0.3
iperf3 -s -p 21008 -1 &
sleep 0.3
iperf3 -s -p 22008 -1 &
sleep 0.3
iperf3 -s -p 23008 -1 &
sleep 0.3
iperf3 -s -p 24008 -1 &
sleep 0.3
iperf3 -s -p 25008 -1 &
sleep 0.3
iperf3 -s -p 26008 -1 &
sleep 0.3
iperf3 -s -p 28008 -1 &
sleep 0.3
iperf3 -s -p 29008 -1 &
sleep 0.3
iperf3 -s -p 30008 -1 &
sleep 0.3
iperf3 -s -p 31008 -1 &
sleep 0.3
iperf3 -s -p 32008 -1 &
sleep 0.3