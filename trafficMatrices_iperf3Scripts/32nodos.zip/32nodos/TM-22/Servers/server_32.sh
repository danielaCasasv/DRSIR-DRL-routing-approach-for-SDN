 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 2032 -1 &
sleep 0.3
iperf3 -s -p 4032 -1 &
sleep 0.3
iperf3 -s -p 6032 -1 &
sleep 0.3
iperf3 -s -p 7032 -1 &
sleep 0.3
iperf3 -s -p 8032 -1 &
sleep 0.3
iperf3 -s -p 9032 -1 &
sleep 0.3
iperf3 -s -p 10032 -1 &
sleep 0.3
iperf3 -s -p 13032 -1 &
sleep 0.3
iperf3 -s -p 14032 -1 &
sleep 0.3
iperf3 -s -p 15032 -1 &
sleep 0.3
iperf3 -s -p 16032 -1 &
sleep 0.3
iperf3 -s -p 17032 -1 &
sleep 0.3
iperf3 -s -p 18032 -1 &
sleep 0.3
iperf3 -s -p 19032 -1 &
sleep 0.3
iperf3 -s -p 21032 -1 &
sleep 0.3
iperf3 -s -p 22032 -1 &
sleep 0.3
iperf3 -s -p 23032 -1 &
sleep 0.3
iperf3 -s -p 24032 -1 &
sleep 0.3
iperf3 -s -p 25032 -1 &
sleep 0.3
iperf3 -s -p 26032 -1 &
sleep 0.3
iperf3 -s -p 27032 -1 &
sleep 0.3
iperf3 -s -p 28032 -1 &
sleep 0.3
iperf3 -s -p 29032 -1 &
sleep 0.3
iperf3 -s -p 30032 -1 &
sleep 0.3
iperf3 -s -p 31032 -1 &
sleep 0.3