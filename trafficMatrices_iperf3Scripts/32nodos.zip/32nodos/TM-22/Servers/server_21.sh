 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 2021 -1 &
sleep 0.3
iperf3 -s -p 3021 -1 &
sleep 0.3
iperf3 -s -p 4021 -1 &
sleep 0.3
iperf3 -s -p 6021 -1 &
sleep 0.3
iperf3 -s -p 7021 -1 &
sleep 0.3
iperf3 -s -p 8021 -1 &
sleep 0.3
iperf3 -s -p 10021 -1 &
sleep 0.3
iperf3 -s -p 11021 -1 &
sleep 0.3
iperf3 -s -p 12021 -1 &
sleep 0.3
iperf3 -s -p 14021 -1 &
sleep 0.3
iperf3 -s -p 15021 -1 &
sleep 0.3
iperf3 -s -p 17021 -1 &
sleep 0.3
iperf3 -s -p 18021 -1 &
sleep 0.3
iperf3 -s -p 19021 -1 &
sleep 0.3
iperf3 -s -p 22021 -1 &
sleep 0.3
iperf3 -s -p 23021 -1 &
sleep 0.3
iperf3 -s -p 25021 -1 &
sleep 0.3
iperf3 -s -p 26021 -1 &
sleep 0.3
iperf3 -s -p 27021 -1 &
sleep 0.3
iperf3 -s -p 30021 -1 &
sleep 0.3
iperf3 -s -p 31021 -1 &
sleep 0.3