 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1006 -1 &
sleep 0.3
iperf3 -s -p 2006 -1 &
sleep 0.3
iperf3 -s -p 4006 -1 &
sleep 0.3
iperf3 -s -p 5006 -1 &
sleep 0.3
iperf3 -s -p 7006 -1 &
sleep 0.3
iperf3 -s -p 8006 -1 &
sleep 0.3
iperf3 -s -p 10006 -1 &
sleep 0.3
iperf3 -s -p 11006 -1 &
sleep 0.3
iperf3 -s -p 12006 -1 &
sleep 0.3
iperf3 -s -p 13006 -1 &
sleep 0.3
iperf3 -s -p 14006 -1 &
sleep 0.3
iperf3 -s -p 15006 -1 &
sleep 0.3
iperf3 -s -p 16006 -1 &
sleep 0.3
iperf3 -s -p 17006 -1 &
sleep 0.3
iperf3 -s -p 20006 -1 &
sleep 0.3
iperf3 -s -p 22006 -1 &
sleep 0.3
iperf3 -s -p 23006 -1 &
sleep 0.3
iperf3 -s -p 26006 -1 &
sleep 0.3
iperf3 -s -p 27006 -1 &
sleep 0.3
iperf3 -s -p 29006 -1 &
sleep 0.3
iperf3 -s -p 31006 -1 &
sleep 0.3
iperf3 -s -p 32006 -1 &
sleep 0.3