 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1017 -1 &
sleep 0.3
iperf3 -s -p 2017 -1 &
sleep 0.3
iperf3 -s -p 3017 -1 &
sleep 0.3
iperf3 -s -p 4017 -1 &
sleep 0.3
iperf3 -s -p 5017 -1 &
sleep 0.3
iperf3 -s -p 6017 -1 &
sleep 0.3
iperf3 -s -p 8017 -1 &
sleep 0.3
iperf3 -s -p 11017 -1 &
sleep 0.3
iperf3 -s -p 12017 -1 &
sleep 0.3
iperf3 -s -p 13017 -1 &
sleep 0.3
iperf3 -s -p 14017 -1 &
sleep 0.3
iperf3 -s -p 15017 -1 &
sleep 0.3
iperf3 -s -p 16017 -1 &
sleep 0.3
iperf3 -s -p 18017 -1 &
sleep 0.3
iperf3 -s -p 19017 -1 &
sleep 0.3
iperf3 -s -p 21017 -1 &
sleep 0.3
iperf3 -s -p 22017 -1 &
sleep 0.3
iperf3 -s -p 23017 -1 &
sleep 0.3
iperf3 -s -p 24017 -1 &
sleep 0.3
iperf3 -s -p 26017 -1 &
sleep 0.3
iperf3 -s -p 29017 -1 &
sleep 0.3
iperf3 -s -p 30017 -1 &
sleep 0.3