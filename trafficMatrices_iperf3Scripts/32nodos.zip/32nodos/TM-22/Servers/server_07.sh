 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 2007 -1 &
sleep 0.3
iperf3 -s -p 4007 -1 &
sleep 0.3
iperf3 -s -p 5007 -1 &
sleep 0.3
iperf3 -s -p 6007 -1 &
sleep 0.3
iperf3 -s -p 8007 -1 &
sleep 0.3
iperf3 -s -p 9007 -1 &
sleep 0.3
iperf3 -s -p 10007 -1 &
sleep 0.3
iperf3 -s -p 11007 -1 &
sleep 0.3
iperf3 -s -p 13007 -1 &
sleep 0.3
iperf3 -s -p 14007 -1 &
sleep 0.3
iperf3 -s -p 15007 -1 &
sleep 0.3
iperf3 -s -p 16007 -1 &
sleep 0.3
iperf3 -s -p 18007 -1 &
sleep 0.3
iperf3 -s -p 19007 -1 &
sleep 0.3
iperf3 -s -p 20007 -1 &
sleep 0.3
iperf3 -s -p 21007 -1 &
sleep 0.3
iperf3 -s -p 22007 -1 &
sleep 0.3
iperf3 -s -p 23007 -1 &
sleep 0.3
iperf3 -s -p 24007 -1 &
sleep 0.3
iperf3 -s -p 25007 -1 &
sleep 0.3
iperf3 -s -p 27007 -1 &
sleep 0.3
iperf3 -s -p 28007 -1 &
sleep 0.3
iperf3 -s -p 30007 -1 &
sleep 0.3
iperf3 -s -p 32007 -1 &
sleep 0.3