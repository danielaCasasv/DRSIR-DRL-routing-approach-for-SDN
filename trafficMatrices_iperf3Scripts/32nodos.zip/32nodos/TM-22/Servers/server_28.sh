 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1028 -1 &
sleep 0.3
iperf3 -s -p 3028 -1 &
sleep 0.3
iperf3 -s -p 4028 -1 &
sleep 0.3
iperf3 -s -p 5028 -1 &
sleep 0.3
iperf3 -s -p 6028 -1 &
sleep 0.3
iperf3 -s -p 7028 -1 &
sleep 0.3
iperf3 -s -p 8028 -1 &
sleep 0.3
iperf3 -s -p 9028 -1 &
sleep 0.3
iperf3 -s -p 10028 -1 &
sleep 0.3
iperf3 -s -p 11028 -1 &
sleep 0.3
iperf3 -s -p 12028 -1 &
sleep 0.3
iperf3 -s -p 14028 -1 &
sleep 0.3
iperf3 -s -p 15028 -1 &
sleep 0.3
iperf3 -s -p 16028 -1 &
sleep 0.3
iperf3 -s -p 19028 -1 &
sleep 0.3
iperf3 -s -p 20028 -1 &
sleep 0.3
iperf3 -s -p 21028 -1 &
sleep 0.3
iperf3 -s -p 23028 -1 &
sleep 0.3
iperf3 -s -p 24028 -1 &
sleep 0.3
iperf3 -s -p 25028 -1 &
sleep 0.3
iperf3 -s -p 26028 -1 &
sleep 0.3
iperf3 -s -p 30028 -1 &
sleep 0.3
iperf3 -s -p 31028 -1 &
sleep 0.3