 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1014 -1 &
sleep 0.3
iperf3 -s -p 2014 -1 &
sleep 0.3
iperf3 -s -p 3014 -1 &
sleep 0.3
iperf3 -s -p 5014 -1 &
sleep 0.3
iperf3 -s -p 6014 -1 &
sleep 0.3
iperf3 -s -p 9014 -1 &
sleep 0.3
iperf3 -s -p 10014 -1 &
sleep 0.3
iperf3 -s -p 11014 -1 &
sleep 0.3
iperf3 -s -p 12014 -1 &
sleep 0.3
iperf3 -s -p 13014 -1 &
sleep 0.3
iperf3 -s -p 15014 -1 &
sleep 0.3
iperf3 -s -p 16014 -1 &
sleep 0.3
iperf3 -s -p 17014 -1 &
sleep 0.3
iperf3 -s -p 18014 -1 &
sleep 0.3
iperf3 -s -p 19014 -1 &
sleep 0.3
iperf3 -s -p 20014 -1 &
sleep 0.3
iperf3 -s -p 21014 -1 &
sleep 0.3
iperf3 -s -p 22014 -1 &
sleep 0.3
iperf3 -s -p 26014 -1 &
sleep 0.3
iperf3 -s -p 28014 -1 &
sleep 0.3
iperf3 -s -p 31014 -1 &
sleep 0.3
iperf3 -s -p 32014 -1 &
sleep 0.3