 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 1024 -1 &
sleep 0.3
iperf3 -s -p 2024 -1 &
sleep 0.3
iperf3 -s -p 3024 -1 &
sleep 0.3
iperf3 -s -p 5024 -1 &
sleep 0.3
iperf3 -s -p 11024 -1 &
sleep 0.3
iperf3 -s -p 12024 -1 &
sleep 0.3
iperf3 -s -p 13024 -1 &
sleep 0.3
iperf3 -s -p 14024 -1 &
sleep 0.3
iperf3 -s -p 15024 -1 &
sleep 0.3
iperf3 -s -p 17024 -1 &
sleep 0.3
iperf3 -s -p 18024 -1 &
sleep 0.3
iperf3 -s -p 19024 -1 &
sleep 0.3
iperf3 -s -p 20024 -1 &
sleep 0.3
iperf3 -s -p 21024 -1 &
sleep 0.3
iperf3 -s -p 22024 -1 &
sleep 0.3
iperf3 -s -p 23024 -1 &
sleep 0.3
iperf3 -s -p 25024 -1 &
sleep 0.3
iperf3 -s -p 28024 -1 &
sleep 0.3
iperf3 -s -p 29024 -1 &
sleep 0.3
iperf3 -s -p 30024 -1 &
sleep 0.3