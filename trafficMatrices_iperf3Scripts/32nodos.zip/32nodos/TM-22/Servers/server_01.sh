 #!/bin/bash 
echo Initializing server listening...
        
iperf3 -s -p 2001 -1 &
sleep 0.3
iperf3 -s -p 3001 -1 &
sleep 0.3
iperf3 -s -p 4001 -1 &
sleep 0.3
iperf3 -s -p 6001 -1 &
sleep 0.3
iperf3 -s -p 7001 -1 &
sleep 0.3
iperf3 -s -p 8001 -1 &
sleep 0.3
iperf3 -s -p 9001 -1 &
sleep 0.3
iperf3 -s -p 10001 -1 &
sleep 0.3
iperf3 -s -p 12001 -1 &
sleep 0.3
iperf3 -s -p 14001 -1 &
sleep 0.3
iperf3 -s -p 15001 -1 &
sleep 0.3
iperf3 -s -p 16001 -1 &
sleep 0.3
iperf3 -s -p 18001 -1 &
sleep 0.3
iperf3 -s -p 19001 -1 &
sleep 0.3
iperf3 -s -p 20001 -1 &
sleep 0.3
iperf3 -s -p 22001 -1 &
sleep 0.3
iperf3 -s -p 24001 -1 &
sleep 0.3
iperf3 -s -p 25001 -1 &
sleep 0.3
iperf3 -s -p 26001 -1 &
sleep 0.3
iperf3 -s -p 27001 -1 &
sleep 0.3
iperf3 -s -p 28001 -1 &
sleep 0.3
iperf3 -s -p 29001 -1 &
sleep 0.3
iperf3 -s -p 30001 -1 &
sleep 0.3
iperf3 -s -p 31001 -1 &
sleep 0.3
iperf3 -s -p 32001 -1 &
sleep 0.3