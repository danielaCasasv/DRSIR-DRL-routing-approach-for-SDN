 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 31001 -u -b 820.763k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 31002 -u -b 666.059k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 31003 -u -b 650.940k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 31004 -u -b 449.841k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 31005 -u -b 259.640k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 31006 -u -b 592.152k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 31008 -u -b 162.534k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 31009 -u -b 157.400k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 31010 -u -b 742.784k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 31011 -u -b 492.063k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 31013 -u -b 126.513k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 31014 -u -b 867.520k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 31016 -u -b 120.162k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 31018 -u -b 873.630k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 31019 -u -b 272.587k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 31020 -u -b 8.154k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 31021 -u -b 577.003k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 31022 -u -b 408.203k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 31023 -u -b 336.824k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 31025 -u -b 79.750k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 31026 -u -b 150.472k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 31027 -u -b 160.865k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 31028 -u -b 416.088k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 31029 -u -b 315.523k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 31032 -u -b 437.174k -w 256k -t 30 &
sleep 0.4