 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 2001 -u -b 8950.079k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 2003 -u -b 7098.235k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 2004 -u -b 4905.330k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 2005 -u -b 2831.269k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 2006 -u -b 6457.177k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 2007 -u -b 919.463k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 2011 -u -b 5365.744k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 2012 -u -b 1083.439k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 2013 -u -b 1379.571k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 2014 -u -b 9459.947k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 2015 -u -b 16.200k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 2017 -u -b 7887.633k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 2018 -u -b 9526.576k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 2019 -u -b 2972.444k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 2020 -u -b 88.918k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 2021 -u -b 6291.976k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 2022 -u -b 4451.283k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 2023 -u -b 3672.924k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 2024 -u -b 811.097k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 2025 -u -b 869.643k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 2027 -u -b 1754.167k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 2029 -u -b 3440.648k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 2030 -u -b 4321.695k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 2031 -u -b 666.059k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 2032 -u -b 4767.203k -w 256k -t 30 &
sleep 0.4