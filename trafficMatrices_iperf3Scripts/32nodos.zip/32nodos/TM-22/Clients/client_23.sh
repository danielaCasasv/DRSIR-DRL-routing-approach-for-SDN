 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 23002 -u -b 3672.924k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 23003 -u -b 3589.554k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 23004 -u -b 2480.610k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 23006 -u -b 3265.374k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 23007 -u -b 464.969k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 23008 -u -b 896.281k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 23009 -u -b 867.969k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 23010 -u -b 4096.018k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 23011 -u -b 2713.440k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 23013 -u -b 697.645k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 23015 -u -b 8.192k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 23017 -u -b 3988.751k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 23018 -u -b 4817.559k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 23019 -u -b 1503.155k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 23021 -u -b 3181.832k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 23022 -u -b 2250.999k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 23024 -u -b 410.169k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 23025 -u -b 439.776k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 23026 -u -b 829.764k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 23028 -u -b 2294.483k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 23029 -u -b 1739.924k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 23031 -u -b 336.824k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 23032 -u -b 2410.759k -w 256k -t 30 &
sleep 0.4