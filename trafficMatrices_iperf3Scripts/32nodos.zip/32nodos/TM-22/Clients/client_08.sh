 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 8001 -u -b 2184.033k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 8002 -u -b 1772.369k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 8005 -u -b 690.897k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 8006 -u -b 1575.705k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 8007 -u -b 224.371k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 8009 -u -b 418.838k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 8010 -u -b 1976.532k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 8012 -u -b 264.385k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 8013 -u -b 336.648k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 8015 -u -b 3.953k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 8016 -u -b 319.750k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 8017 -u -b 1924.771k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 8019 -u -b 725.347k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 8020 -u -b 21.698k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 8021 -u -b 1535.392k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 8022 -u -b 1086.219k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 8023 -u -b 896.281k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 8026 -u -b 400.402k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 8027 -u -b 428.059k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 8028 -u -b 1107.202k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 8029 -u -b 839.600k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 8030 -u -b 1054.597k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 8031 -u -b 162.534k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 8032 -u -b 1163.311k -w 256k -t 30 &
sleep 0.4