 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 7001 -u -b 1133.025k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 7002 -u -b 919.463k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 7004 -u -b 620.984k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 7006 -u -b 817.439k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 7009 -u -b 217.283k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 7011 -u -b 679.270k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 7012 -u -b 137.157k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 7013 -u -b 174.645k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 7015 -u -b 2.051k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 7016 -u -b 165.879k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 7018 -u -b 1206.006k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 7019 -u -b 376.293k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 7020 -u -b 11.257k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 7021 -u -b 796.525k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 7025 -u -b 110.091k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 7027 -u -b 222.067k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 7028 -u -b 574.390k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 7029 -u -b 435.565k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 7030 -u -b 547.100k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 7032 -u -b 603.498k -w 256k -t 30 &
sleep 0.4