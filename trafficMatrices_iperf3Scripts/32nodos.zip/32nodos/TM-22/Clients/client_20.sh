 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 20001 -u -b 109.571k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 20002 -u -b 88.918k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 20004 -u -b 60.053k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 20006 -u -b 79.052k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 20007 -u -b 11.257k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 20008 -u -b 21.698k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 20009 -u -b 21.013k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 20011 -u -b 65.690k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 20012 -u -b 13.264k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 20014 -u -b 115.813k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 20016 -u -b 16.042k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 20018 -u -b 116.629k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 20019 -u -b 36.390k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 20023 -u -b 44.966k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 20024 -u -b 9.930k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 20026 -u -b 20.088k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 20027 -u -b 21.475k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 20028 -u -b 55.547k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 20029 -u -b 42.122k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 20031 -u -b 8.154k -w 256k -t 30 &
sleep 0.4