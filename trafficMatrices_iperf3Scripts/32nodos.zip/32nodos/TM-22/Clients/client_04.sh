 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 4001 -u -b 6044.680k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 4002 -u -b 4905.330k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 4003 -u -b 4793.986k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 4005 -u -b 1912.174k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 4006 -u -b 4361.031k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 4007 -u -b 620.984k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 4008 -u -b 1197.017k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 4009 -u -b 1159.205k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 4011 -u -b 3623.902k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 4015 -u -b 10.941k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 4016 -u -b 884.961k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 4017 -u -b 5327.128k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 4018 -u -b 6434.033k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 4019 -u -b 2007.521k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 4020 -u -b 60.053k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 4021 -u -b 4249.458k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 4022 -u -b 3006.295k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 4026 -u -b 1108.181k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 4027 -u -b 1184.725k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 4028 -u -b 3064.369k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 4029 -u -b 2323.735k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 4030 -u -b 2918.775k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 4032 -u -b 3219.661k -w 256k -t 30 &
sleep 0.4