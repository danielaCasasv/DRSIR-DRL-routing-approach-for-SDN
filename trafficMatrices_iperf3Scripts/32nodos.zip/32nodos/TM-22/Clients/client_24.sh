 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 24001 -u -b 999.489k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 24003 -u -b 792.686k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 24004 -u -b 547.796k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 24007 -u -b 102.680k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 24008 -u -b 197.927k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 24009 -u -b 191.675k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 24010 -u -b 904.529k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 24011 -u -b 599.213k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 24012 -u -b 120.992k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 24013 -u -b 154.062k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 24015 -u -b 1.809k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 24016 -u -b 146.328k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 24017 -u -b 880.841k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 24018 -u -b 1063.868k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 24019 -u -b 331.944k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 24022 -u -b 497.091k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.23 -p 24023 -u -b 410.169k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 24026 -u -b 183.238k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 24027 -u -b 195.894k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 24028 -u -b 506.694k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 24030 -u -b 482.620k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 24032 -u -b 532.371k -w 256k -t 30 &
sleep 0.4