 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 16001 -u -b 1614.667k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 16002 -u -b 1310.322k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 16006 -u -b 1164.927k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 16007 -u -b 165.879k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 16008 -u -b 319.750k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 16010 -u -b 1461.261k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 16011 -u -b 968.024k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 16014 -u -b 1706.651k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 16015 -u -b 2.923k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 16017 -u -b 1422.993k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 16020 -u -b 16.042k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 16022 -u -b 803.048k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 16025 -u -b 156.891k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 16027 -u -b 316.466k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 16028 -u -b 818.560k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 16029 -u -b 620.721k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 16030 -u -b 779.669k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 16031 -u -b 120.162k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 16032 -u -b 860.042k -w 256k -t 30 &
sleep 0.4