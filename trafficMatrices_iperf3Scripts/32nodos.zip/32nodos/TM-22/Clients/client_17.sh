 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.3 -p 17003 -u -b 7708.596k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 17004 -u -b 5327.128k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 17005 -u -b 3074.723k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 17006 -u -b 7012.415k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 17008 -u -b 1924.771k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 17009 -u -b 1863.970k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 17010 -u -b 8796.230k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 17011 -u -b 5827.132k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 17012 -u -b 1176.602k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 17013 -u -b 1498.197k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 17014 -u -b 10273.386k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 17015 -u -b 17.593k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 17018 -u -b 10345.745k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 17019 -u -b 3228.038k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 17021 -u -b 6833.009k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 17022 -u -b 4834.039k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 17024 -u -b 880.841k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 17025 -u -b 944.422k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 17026 -u -b 1781.924k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 17029 -u -b 3736.501k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 17031 -u -b 723.331k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 17032 -u -b 5177.124k -w 256k -t 30 &
sleep 0.4