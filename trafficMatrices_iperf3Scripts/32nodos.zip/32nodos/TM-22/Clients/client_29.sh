 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 29001 -u -b 4239.799k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.2 -p 29002 -u -b 3440.648k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 29003 -u -b 3362.550k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 29004 -u -b 2323.735k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 29005 -u -b 1341.218k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 29006 -u -b 3058.871k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 29008 -u -b 839.600k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.10 -p 29010 -u -b 3836.985k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.11 -p 29011 -u -b 2541.841k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 29013 -u -b 653.525k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 29016 -u -b 620.721k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 29017 -u -b 3736.501k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 29018 -u -b 4512.895k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 29020 -u -b 42.122k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 29022 -u -b 2108.646k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 29024 -u -b 384.230k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 29025 -u -b 411.964k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 29026 -u -b 777.289k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 29027 -u -b 830.978k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 29030 -u -b 2047.258k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 29031 -u -b 315.523k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 29032 -u -b 2258.302k -w 256k -t 30 &
sleep 0.4