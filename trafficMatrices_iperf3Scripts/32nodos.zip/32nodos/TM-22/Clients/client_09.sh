 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.1 -p 9001 -u -b 2115.042k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.4 -p 9004 -u -b 1159.205k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 9005 -u -b 669.073k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 9007 -u -b 217.283k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.8 -p 9008 -u -b 418.838k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 9012 -u -b 256.034k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 9014 -u -b 2235.532k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 9016 -u -b 309.649k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 9018 -u -b 2251.277k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 9019 -u -b 702.435k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 9020 -u -b 21.013k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 9022 -u -b 1051.907k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 9025 -u -b 205.510k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 9026 -u -b 387.754k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.27 -p 9027 -u -b 414.537k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 9028 -u -b 1072.227k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 9029 -u -b 813.078k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 9030 -u -b 1021.283k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 9031 -u -b 157.400k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.32 -p 9032 -u -b 1126.564k -w 256k -t 30 &
sleep 0.4