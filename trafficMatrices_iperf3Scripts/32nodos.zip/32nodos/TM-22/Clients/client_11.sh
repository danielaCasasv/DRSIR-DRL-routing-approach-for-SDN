 #!/bin/bash 
echo Generating traffic...
        
iperf3 -c 10.0.0.2 -p 11002 -u -b 5365.744k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.3 -p 11003 -u -b 5243.950k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.5 -p 11005 -u -b 2091.651k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.6 -p 11006 -u -b 4770.357k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.7 -p 11007 -u -b 679.270k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.9 -p 11009 -u -b 1268.008k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.12 -p 11012 -u -b 800.411k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.13 -p 11013 -u -b 1019.183k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.14 -p 11014 -u -b 6988.707k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.15 -p 11015 -u -b 11.968k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.16 -p 11016 -u -b 968.024k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.17 -p 11017 -u -b 5827.132k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.18 -p 11018 -u -b 7037.931k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.19 -p 11019 -u -b 2195.947k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.20 -p 11020 -u -b 65.690k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.21 -p 11021 -u -b 4648.312k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.22 -p 11022 -u -b 3288.466k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.24 -p 11024 -u -b 599.213k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.25 -p 11025 -u -b 642.464k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.26 -p 11026 -u -b 1212.195k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.28 -p 11028 -u -b 3351.991k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.29 -p 11029 -u -b 2541.841k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.30 -p 11030 -u -b 3192.731k -w 256k -t 30 &
sleep 0.4
iperf3 -c 10.0.0.31 -p 11031 -u -b 492.063k -w 256k -t 30 &
sleep 0.4